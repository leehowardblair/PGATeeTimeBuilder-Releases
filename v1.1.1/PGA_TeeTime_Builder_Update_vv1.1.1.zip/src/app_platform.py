"""
Small, dependency-free helpers for platform-specific behavior.

Keep operating-system details here so the main app stays shared between
Windows and macOS.
"""

from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def is_windows() -> bool:
    return sys.platform.startswith("win")


def is_macos() -> bool:
    return sys.platform == "darwin"


def is_frozen_app() -> bool:
    """True when running from a PyInstaller-built application."""
    return bool(getattr(sys, "frozen", False))


def user_data_dir(app_name: str) -> Path:
    """Return the per-user folder for settings, logs, and issue reports."""
    if is_windows():
        return Path.home() / "AppData" / "Local" / app_name

    if is_macos():
        return Path.home() / "Library" / "Application Support" / app_name

    return Path.home() / ".local" / "share" / app_name


def default_output_dir(app_name: str) -> Path:
    """Return the default location for exported tee sheets."""
    return Path.home() / "Documents" / app_name / "Finished Tee Sheets"


def macos_app_bundle_path() -> Path | None:
    """
    Return the running .app bundle when launched from a frozen macOS build.

    Returning None for source runs is deliberate: source runs should never try
    to replace a developer's project folder.
    """
    if not (is_macos() and is_frozen_app()):
        return None

    executable = Path(sys.executable).resolve()
    # .../PGA Tee Time Builder.app/Contents/MacOS/PGA Tee Time Builder
    try:
        bundle = executable.parents[2]
    except IndexError:
        return None

    return bundle if bundle.suffix == ".app" and bundle.exists() else None


def open_path(path: str | Path) -> None:
    """Open a file or folder using the operating system's normal behavior."""
    target = Path(path)

    if is_windows():
        subprocess.Popen(["explorer", str(target)])
    elif is_macos():
        subprocess.Popen(["open", str(target)])
    else:
        subprocess.Popen(["xdg-open", str(target)])


def reveal_path(path: str | Path) -> None:
    """Reveal a file in Explorer/Finder, or open its parent folder elsewhere."""
    target = Path(path)

    if is_windows():
        subprocess.Popen(["explorer", "/select,", str(target)])
    elif is_macos():
        subprocess.Popen(["open", "-R", str(target)])
    else:
        open_path(target.parent)


def apply_window_icon(window, icon_path: str | Path, photo_image=None) -> None:
    """
    Apply window icons without replacing the native macOS app-bundle icon.

    On macOS, the .app bundle's icon (set by PyInstaller) should own the Dock
    appearance. Calling Tk's iconphoto() there replaces it with the transparent
    in-app logo, so intentionally do nothing after the bundle has launched.

    On Windows and Linux, retain the existing Tk icon behavior.
    """
    if is_macos():
        return

    try:
        icon = Path(icon_path)
        if is_windows() and icon.exists():
            window.iconbitmap(str(icon))
    except Exception:
        pass

    try:
        if photo_image:
            window.iconphoto(False, photo_image)
    except Exception:
        pass


def set_windows_app_id(app_id: str) -> None:
    """Set the Windows taskbar identity without affecting macOS."""
    if not is_windows():
        return

    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def release_asset_for_current_platform(release_info: dict) -> str:
    """Choose the installer/download asset appropriate for this operating system."""
    if is_windows():
        return str(release_info.get("installer_url", "") or "")

    if is_macos():
        return str(release_info.get("mac_url", "") or "")

    return ""


def launch_update_package(package_path: str | Path) -> None:
    """
    Open a downloaded update package for source/development fallback paths.

    Installed builds use the delayed Windows installer or macOS replacement
    helpers below instead.
    """
    package = Path(package_path)

    if is_windows():
        subprocess.Popen([str(package)])
    elif is_macos():
        subprocess.Popen(["open", str(package)])
    else:
        subprocess.Popen(["xdg-open", str(package)])


def _start_detached(command: list[str]) -> None:
    """Start a helper that survives after the GUI process exits."""
    kwargs: dict = {
        "close_fds": True,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }

    if is_windows():
        creation_flags = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
        kwargs["creationflags"] = creation_flags
    else:
        kwargs["start_new_session"] = True

    subprocess.Popen(command, **kwargs)


def schedule_windows_installer_after_exit(
    installer_path: str | Path,
    process_id: int,
    log_path: str | Path | None = None,
) -> Path:
    """
    Wait for the current app process to finish, then launch the Windows
    installer. This avoids the first-launch race where the installer relaunches
    while the old PyInstaller process still owns temporary runtime files.
    """
    if not is_windows():
        raise RuntimeError("Windows installer handoff was requested on a non-Windows system.")

    installer = Path(installer_path).resolve()
    if not installer.exists():
        raise FileNotFoundError(f"Downloaded installer was not found: {installer}")

    work_dir = Path(tempfile.mkdtemp(prefix="pga_teetime_windows_update_"))
    helper = work_dir / "install_after_exit.ps1"
    log = Path(log_path) if log_path else work_dir / "windows_update.log"
    log.parent.mkdir(parents=True, exist_ok=True)

    helper.write_text(
        """param(
    [Parameter(Mandatory=$true)][int]$ParentPid,
    [Parameter(Mandatory=$true)][string]$Installer,
    [Parameter(Mandatory=$true)][string]$LogFile
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog([string]$Message) {
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$stamp] $Message"
}

try {
    Write-UpdateLog "Waiting for PGA Tee Time Builder process $ParentPid to exit."
    Wait-Process -Id $ParentPid -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 750
    Write-UpdateLog "Launching installer: $Installer"
    Start-Process -FilePath $Installer
}
catch {
    Write-UpdateLog ("Updater handoff failed: " + $_.Exception.Message)
}
""",
        encoding="utf-8",
    )

    _start_detached(
        [
            "powershell.exe",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(helper),
            "-ParentPid",
            str(int(process_id)),
            "-Installer",
            str(installer),
            "-LogFile",
            str(log),
        ]
    )

    return helper


def _mac_shell_quote(value: str | Path) -> str:
    return shlex.quote(str(value))


def schedule_macos_app_update_after_exit(
    update_zip_path: str | Path,
    process_id: int,
    log_path: str | Path,
) -> Path:
    """
    Extract a signed/notarized update ZIP and schedule a replacement of the
    running .app after this app exits.

    For applications in /Applications, macOS requests an administrator password
    only when that location requires authorization. User-writable app locations
    update without a privilege prompt.
    """
    if not is_macos():
        raise RuntimeError("macOS app update was requested on a non-macOS system.")

    target_app = macos_app_bundle_path()
    if target_app is None:
        raise RuntimeError(
            "One-click updates are available only from the installed PGA Tee Time Builder.app."
        )

    update_zip = Path(update_zip_path).resolve()
    if not update_zip.exists():
        raise FileNotFoundError(f"Downloaded macOS update ZIP was not found: {update_zip}")

    work_dir = Path(tempfile.mkdtemp(prefix="pga_teetime_macos_update_"))
    extracted_dir = work_dir / "extracted"
    extracted_dir.mkdir(parents=True, exist_ok=True)

    subprocess.run(
        ["ditto", "-x", "-k", str(update_zip), str(extracted_dir)],
        check=True,
    )

    candidates = sorted(extracted_dir.rglob(target_app.name))
    new_app = next((path for path in candidates if path.is_dir() and path.suffix == ".app"), None)
    if new_app is None:
        candidates = sorted(extracted_dir.rglob("*.app"))
        new_app = next((path for path in candidates if path.is_dir()), None)

    if new_app is None:
        raise RuntimeError("The downloaded ZIP did not contain a macOS .app bundle.")

    log = Path(log_path)
    log.parent.mkdir(parents=True, exist_ok=True)
    helper = work_dir / "install_after_exit.sh"

    helper.write_text(
        f"""#!/bin/bash
set -u

PID={int(process_id)}
NEW_APP={_mac_shell_quote(new_app)}
TARGET_APP={_mac_shell_quote(target_app)}
LOG_FILE={_mac_shell_quote(log)}

write_log() {{
    /bin/mkdir -p "$(dirname "$LOG_FILE")"
    echo "[$(/bin/date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}}

write_log "Waiting for PGA Tee Time Builder process $PID to exit."
while /bin/kill -0 "$PID" 2>/dev/null; do
    /bin/sleep 1
done
/bin/sleep 1

if ! /usr/bin/codesign --verify --deep --strict "$NEW_APP" >> "$LOG_FILE" 2>&1; then
    write_log "The downloaded app failed signature verification."
    exit 1
fi

if ! /usr/sbin/spctl --assess --type execute --verbose=4 "$NEW_APP" >> "$LOG_FILE" 2>&1; then
    write_log "The downloaded app failed Gatekeeper assessment."
    exit 1
fi

PARENT_DIR="$(/usr/bin/dirname "$TARGET_APP")"
write_log "Installing update into $TARGET_APP"

if [ -w "$PARENT_DIR" ]; then
    /bin/rm -rf "$TARGET_APP"
    /usr/bin/ditto "$NEW_APP" "$TARGET_APP"
    /usr/bin/open "$TARGET_APP"
    write_log "Update installed and relaunched without elevation."
    exit 0
fi

write_log "Administrator authorization is required to replace the app."
/usr/bin/osascript - "$NEW_APP" "$TARGET_APP" <<'APPLESCRIPT' >> "$LOG_FILE" 2>&1
on run argv
    set newApp to item 1 of argv
    set targetApp to item 2 of argv
    set installCommand to "/bin/rm -rf " & quoted form of targetApp & " && /usr/bin/ditto " & quoted form of newApp & " " & quoted form of targetApp & " && /usr/bin/open " & quoted form of targetApp
    do shell script installCommand with administrator privileges
end run
APPLESCRIPT

if [ $? -eq 0 ]; then
    write_log "Update installed and relaunched with administrator authorization."
else
    write_log "Administrator-authorized update failed or was cancelled."
fi
""",
        encoding="utf-8",
    )
    helper.chmod(0o700)

    _start_detached(["/bin/bash", str(helper)])
    return target_app
