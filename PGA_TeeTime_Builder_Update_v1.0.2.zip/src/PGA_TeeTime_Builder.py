import json
import platform
import os
import re
import subprocess
import sys
import threading
import time
import contextlib
import zipfile
import shutil
import tempfile
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

try:
    from PIL import Image, ImageTk
except Exception:
    Image = None
    ImageTk = None


APP_NAME = "PGA Tee Time Builder"
APP_VERSION = "1.0.2"
SUPPORT_EMAIL = "leeblairtv@gmail.com"

# Public distribution repository used by Check for Updates.
# Keep the source repository private; publish installers/update ZIPs here:
# https://github.com/leehowardblair/PGATeeTimeBuilder-Releases/releases
GITHUB_OWNER = "leehowardblair"
GITHUB_RELEASE_REPO = "PGATeeTimeBuilder-Releases"
GITHUB_REPO = f"{GITHUB_OWNER}/{GITHUB_RELEASE_REPO}"
GITHUB_RELEASE_API = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
GITHUB_RELEASES_PAGE = f"https://github.com/{GITHUB_REPO}/releases"
GITHUB_LATEST_RELEASE_PAGE = f"{GITHUB_RELEASES_PAGE}/latest"

APP_DIR = Path(__file__).resolve().parent

if sys.platform.startswith("win"):
    USER_DATA = Path.home() / "AppData" / "Local" / "PGA Tee Time Builder"
    DEFAULT_OUTPUT = Path.home() / "Documents" / "PGA Tee Time Builder" / "Finished Tee Sheets"
else:
    USER_DATA = Path.home() / "Library" / "Application Support" / "PGA Tee Time Builder"
    DEFAULT_OUTPUT = Path.home() / "Documents" / "PGA Tee Time Builder" / "Finished Tee Sheets"

BASE = USER_DATA
SCRIPTS = APP_DIR
CONFIG_PATH = USER_DATA / "PGA_TeeTime_GUI_Config.json"

DEFAULTS = {
    "output_root": str(DEFAULT_OUTPUT),
    "pdf_override": "",
    "espn_override": "",
    "update_url": "",
    "first_run_complete": False,
    "last_build_summary": "",
    "email_method": "default",
}

TOURNAMENTS = [
    ("3M Open", "3mopen"),
    ("American Express", "theamericanexpress"),
    ("API", "arnoldpalmerinvitationalpresentedbymastercard"),
    ("ATT Pebble Beach", "atandtpebblebeachproam"),
    ("BMW Championship", "bmwchampionship"),
    ("Byron Nelson", "thecjcupbyronnelson"),
    ("Cadillac Champ", "cadillac-championship"),
    ("Charles Schwab", "charlesschwabchallenge"),
    ("Cognizant Classic", "cognizant-classic-in-the-palm-beaches"),
    ("Farmers Open", "farmersinsuranceopen"),
    ("FedEx St. Jude", "fedexstjudechampionship"),
    ("Genesis", "thegenesisinvitational"),
    ("Genesis Scottish Open", "genesisscottishopen"),
    ("John Deere", "johndeereclassic"),
    ("Masters", "masterstournament"),
    ("Open Championship", "theopenchampionship"),
    ("PGA Champ", "pgachampionship"),
    ("Players", "theplayerschampionship"),
    ("Puerto Rico Open", "puertoricoopen"),
    ("RBC Canadian Open", "rbccanadianopen"),
    ("RBC Heritage", "rbcheritage"),
    ("Rocket Classic", "rocketclassic"),
    ("Texas Children's Houston Open", "texaschildrenshoustonopen"),
    ("the Memorial", "thememorialtournamentpresentedbyworkday"),
    ("TOUR Championship", "tourchampionship"),
    ("Travelers", "travelerschampionship"),
    ("Truist", "truistchampionship"),
    ("U.S. Open", "usopen"),
    ("Valero", "valerotexasopen"),
    ("Valspar", "valsparchampionship"),
    ("Waste Management", "wmphoenixopen"),
    ("Wyndham", "wyndhamchampionship"),
    ("Zurich", "zurichclassicofneworleans"),
]

TOURNAMENT_LABELS = [name for name, slug in TOURNAMENTS]
TOURNAMENT_SLUGS = {name: slug for name, slug in TOURNAMENTS}
ROUND_LABELS = ["1", "2", "3", "4"]
WAVE_LABELS = ["AM", "PM", "ALL"]

PGA_2026_CALENDAR = [
    ("2026-01-19", "2026-01-25", "American Express"),
    ("2026-01-26", "2026-02-01", "Farmers Open"),
    ("2026-02-02", "2026-02-08", "Waste Management"),
    ("2026-02-09", "2026-02-15", "ATT Pebble Beach"),
    ("2026-02-16", "2026-02-22", "Genesis"),
    ("2026-03-02", "2026-03-08", "API"),
    ("2026-03-16", "2026-03-22", "Players"),
    ("2026-03-23", "2026-03-29", "Valspar"),
    ("2026-03-30", "2026-04-05", "Texas Children's Houston Open"),
    ("2026-04-06", "2026-04-12", "Masters"),
    ("2026-04-13", "2026-04-19", "RBC Heritage"),
    ("2026-04-27", "2026-05-03", "Byron Nelson"),
    ("2026-05-04", "2026-05-10", "Truist"),
    ("2026-05-11", "2026-05-17", "PGA Champ"),
    ("2026-05-18", "2026-05-24", "Charles Schwab"),
    ("2026-05-25", "2026-05-31", "the Memorial"),
    ("2026-06-08", "2026-06-14", "RBC Canadian Open"),
    ("2026-06-15", "2026-06-21", "U.S. Open"),
    ("2026-06-22", "2026-06-28", "Travelers"),
    ("2026-06-29", "2026-07-05", "John Deere"),
    ("2026-07-06", "2026-07-12", "Genesis Scottish Open"),
    ("2026-07-13", "2026-07-19", "Open Championship"),
    ("2026-07-20", "2026-07-26", "3M Open"),
    ("2026-07-27", "2026-08-02", "Rocket Classic"),
    ("2026-08-03", "2026-08-09", "Wyndham"),
    ("2026-08-10", "2026-08-16", "FedEx St. Jude"),
    ("2026-08-17", "2026-08-23", "BMW Championship"),
    ("2026-08-24", "2026-08-30", "TOUR Championship"),
]



def set_windows_app_id():
    """
    Helps Windows taskbar grouping/icon use the app identity instead of python.exe/tk.
    """
    if not sys.platform.startswith("win"):
        return

    try:
        import ctypes
        app_id = "LeeBlair.PGATeeTimeBuilder.1.0.2"
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass



def current_year():
    return str(datetime.now().year)


def default_tournament_for_today():
    today = datetime.now().date()
    for start_text, end_text, tournament in PGA_2026_CALENDAR:
        start = datetime.strptime(start_text, "%Y-%m-%d").date()
        end = datetime.strptime(end_text, "%Y-%m-%d").date()
        if start <= today <= end:
            return tournament
    return "RBC Canadian Open"


def resource_path(relative_path):
    try:
        root = Path(sys._MEIPASS)
    except Exception:
        root = Path(__file__).resolve().parent.parent
    return root / relative_path



def load_logo_image(max_width=None, max_height=None, filename="logo_main.png"):
    """
    Load the logo using Pillow when available so scaled logos stay crisp.
    Falls back to Tk PhotoImage if Pillow is unavailable.
    """
    logo_path = resource_path(f"assets/{filename}")

    if not logo_path.exists():
        return None

    try:
        if Image is not None and ImageTk is not None:
            img = Image.open(logo_path).convert("RGBA")
            if max_width or max_height:
                w, h = img.size
                scale = 1.0
                if max_width and w > max_width:
                    scale = min(scale, max_width / w)
                if max_height and h > max_height:
                    scale = min(scale, max_height / h)
                if scale < 1:
                    img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
            return ImageTk.PhotoImage(img)

        img = tk.PhotoImage(file=str(logo_path))
        if max_width and img.width() > max_width:
            factor = max(1, int(img.width() / max_width))
            img = img.subsample(factor, factor)
        return img
    except Exception:
        return None




def load_header_logo_image(max_width=54, max_height=54):
    return load_logo_image(max_width=max_width, max_height=max_height, filename="logo_header.png")

    try:
        if Image is not None and ImageTk is not None:
            img = Image.open(logo_path).convert("RGBA")
            w, h = img.size
            scale = 1.0
            if max_width and w > max_width:
                scale = min(scale, max_width / w)
            if max_height and h > max_height:
                scale = min(scale, max_height / h)
            if scale < 1:
                img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

            pad = 4
            glow = Image.new("RGBA", (img.width + pad * 2, img.height + pad * 2), (255, 255, 255, 0))
            alpha = img.getchannel("A")

            # Simple white stroke/glow by pasting alpha offsets.
            for dx, dy, opacity in [
                (-1, 0, 150), (1, 0, 150), (0, -1, 150), (0, 1, 150),
                (-1, -1, 105), (1, -1, 105), (-1, 1, 105), (1, 1, 105),
                (-2, 0, 70), (2, 0, 70), (0, -2, 70), (0, 2, 70),
            ]:
                layer = Image.new("RGBA", glow.size, (255, 255, 255, 0))
                stroke_alpha = alpha.point(lambda a: int(a * (opacity / 255)))
                white = Image.new("RGBA", img.size, (255, 255, 255, 255))
                white.putalpha(stroke_alpha)
                layer.paste(white, (pad + dx, pad + dy), white)
                glow = Image.alpha_composite(glow, layer)

            glow.paste(img, (pad, pad), img)
            return ImageTk.PhotoImage(glow)

    except Exception:
        pass

    return load_logo_image(max_width=max_width, max_height=max_height)




def format_log_line_for_display(line):
    text = str(line).strip()
    low = text.lower()

    if not text:
        return text

    # Keep traceback/code paths raw so debugging still works.
    if text.startswith("Traceback") or text.startswith("  File ") or text.startswith("requests.") or text.startswith("NameError") or text.startswith("IndentationError"):
        return text

    if "looking for pga tour media tee sheet" in low:
        return "● Looking for PGA Tour Media tee sheet..."
    if "pdf candidate:" in low:
        return f"● Trying {text.split(':', 1)[-1].strip()}"
    if "trying pdf url" in low:
        return "● Finding PGA Tour Media tee-time PDF..."
    if "found pga tour media pdf" in low:
        return f"✓ Found {text.split(':', 1)[-1].strip()}"
    if "no pga tour media pdf candidate succeeded" in low:
        return "✕ No PGA Tour Media PDF candidate succeeded."
    if "pdf url failed" in low:
        return "✕ Tee-time PDF candidate failed."
    if "pdf filename patterns checked" in low:
        return "✕ Could not locate tee-time PDF. Use PDF Override if needed."
    if "saved full-field round 1 group map" in low:
        return "✓ Saved Round 1 group map."
    if "loaded round 1 group map" in low:
        return "✓ Loaded Round 1 group map."
    if "built round 2 tee-time map" in low:
        return "✓ Built Round 2 tee-time map."
    if "auto-discovered espn leaderboard" in low:
        return "✓ Found ESPN leaderboard."
    if "using known espn leaderboard fallback" in low:
        return "✓ Using ESPN leaderboard fallback."
    if "leaderboard url" in low:
        return "● Reading ESPN leaderboard..."
    if "parsed" in low and "espn leaderboard rows" in low:
        return "✓ Parsed ESPN leaderboard rows."
    if "matched leaderboard scores" in low:
        return "✓ Matched leaderboard scores."
    if low.startswith("parsed ") and "tee-time groups" in low:
        return "✓ Parsed tee-time groups."
    if "saved openpyxl" in low or "saved " in low and ".xlsx" in low:
        return "✓ Saved finished workbook."
    if "opening:" in low:
        return "● Opening finished workbook..."
    if low == "done." or low == "done":
        return "✓ Done."
    if "error" in low or "failed" in low:
        return "✕ " + text

    return text



def load_config():
    cfg = DEFAULTS.copy()
    try:
        if CONFIG_PATH.exists():
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
    except Exception:
        pass

    cfg["pdf_override"] = ""
    cfg["espn_override"] = ""
    return cfg


def save_config(cfg):
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as exc:
        messagebox.showwarning("Settings Not Saved", str(exc))



class RoundedButton(tk.Canvas):
    def __init__(
        self,
        master,
        text,
        command=None,
        bg="#2F9D65",
        hover_bg="#37B573",
        pressed_bg="#25804F",
        disabled_bg="#25804F",
        fg="white",
        disabled_fg="#d9efe3",
        radius=18,
        height=52,
        font=("Segoe UI", 12, "bold"),
        cursor="hand2",
        **kwargs
    ):
        super().__init__(
            master,
            height=height,
            highlightthickness=0,
            bd=0,
            bg=master.cget("bg") if hasattr(master, "cget") else "#141821",
            cursor=cursor,
            **kwargs
        )

        self.button_text = text
        self.command = command
        self.normal_bg = bg
        self.hover_bg = hover_bg
        self.pressed_bg = pressed_bg
        self.disabled_bg = disabled_bg
        self.fg = fg
        self.disabled_fg = disabled_fg
        self.radius = radius
        self.button_height = height
        self.button_font = font
        self.state = "normal"
        self.current_bg = self.normal_bg
        self.current_fg = self.fg
        self._is_hover = False
        self._is_pressed = False

        self.bind("<Configure>", lambda event: self._draw())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

        self._draw()

    def _rounded_rect(self, x1, y1, x2, y2, radius, fill):
        radius = max(0, min(radius, int((y2 - y1) / 2), int((x2 - x1) / 2)))

        # Center rectangles.
        self.create_rectangle(x1 + radius, y1, x2 - radius, y2, fill=fill, outline=fill, tags="button")
        self.create_rectangle(x1, y1 + radius, x2, y2 - radius, fill=fill, outline=fill, tags="button")

        # Corners.
        self.create_oval(x1, y1, x1 + radius * 2, y1 + radius * 2, fill=fill, outline=fill, tags="button")
        self.create_oval(x2 - radius * 2, y1, x2, y1 + radius * 2, fill=fill, outline=fill, tags="button")
        self.create_oval(x1, y2 - radius * 2, x1 + radius * 2, y2, fill=fill, outline=fill, tags="button")
        self.create_oval(x2 - radius * 2, y2 - radius * 2, x2, y2, fill=fill, outline=fill, tags="button")

    def _draw(self):
        self.delete("button")
        width = max(self.winfo_width(), 1)
        height = max(self.winfo_height(), self.button_height)

        fill = self.disabled_bg if self.state == "disabled" else self.current_bg
        text_fill = self.disabled_fg if self.state == "disabled" else self.current_fg

        # Soft shadow.
        self._rounded_rect(3, 4, width - 3, height - 1, self.radius, "#0b111a")
        self._rounded_rect(0, 0, width - 6, height - 6, self.radius, fill)

        # Small highlight line for a more polished "broadcast software" feel.
        self.create_line(
            self.radius,
            2,
            max(width - self.radius - 6, self.radius),
            2,
            fill="#63C98D" if self.state != "disabled" else "#3a7c58",
            tags="button"
        )

        self.create_text(
            (width - 6) / 2,
            (height - 6) / 2,
            text=self.button_text,
            fill=text_fill,
            font=self.button_font,
            tags="button"
        )

    def _on_enter(self, event=None):
        if self.state == "disabled":
            return
        self._is_hover = True
        self.current_bg = self.hover_bg
        self._draw()

    def _on_leave(self, event=None):
        if self.state == "disabled":
            return
        self._is_hover = False
        self._is_pressed = False
        self.current_bg = self.normal_bg
        self._draw()

    def _on_press(self, event=None):
        if self.state == "disabled":
            return
        self._is_pressed = True
        self.current_bg = self.pressed_bg
        self._draw()

    def _on_release(self, event=None):
        if self.state == "disabled":
            return

        was_pressed = self._is_pressed
        self._is_pressed = False
        self.current_bg = self.hover_bg if self._is_hover else self.normal_bg
        self._draw()

        if was_pressed and self.command:
            self.command()

    def configure(self, cnf=None, **kwargs):
        if cnf:
            kwargs.update(cnf)

        if "text" in kwargs:
            self.button_text = kwargs.pop("text")

        if "state" in kwargs:
            self.state = kwargs.pop("state")

        if "bg" in kwargs:
            self.normal_bg = kwargs.pop("bg")
            if self.state != "disabled":
                self.current_bg = self.normal_bg

        if "cursor" in kwargs:
            super().configure(cursor=kwargs.pop("cursor"))

        if "command" in kwargs:
            self.command = kwargs.pop("command")

        if kwargs:
            super().configure(**kwargs)

        self._draw()

    config = configure


class SplashWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("560x500")
        self.resizable(False, False)
        self.configure(bg="#ffffff")
        self.overrideredirect(True)
        self.logo_image = None
        self.status_rows = {}

        container = tk.Frame(self, bg="#ffffff")
        container.pack(fill="both", expand=True, padx=34, pady=26)

        self.logo_image = load_logo_image(max_width=380, max_height=220, filename="logo_splash.png")
        if self.logo_image:
            tk.Label(container, image=self.logo_image, bg="#ffffff").pack(pady=(4, 8))
        else:
            self.fallback_logo(container)

        tk.Label(
            container,
            text=f"Version {APP_VERSION}",
            bg="#ffffff",
            fg="#697386",
            font=("Segoe UI", 9)
        ).pack(pady=(0, 12))

        self.status = tk.StringVar(value="Initializing...")
        tk.Label(
            container,
            textvariable=self.status,
            bg="#ffffff",
            fg="#111827",
            font=("Segoe UI", 10, "bold")
        ).pack(pady=(0, 10))

        checklist = tk.Frame(container, bg="#ffffff")
        checklist.pack(fill="x", padx=44, pady=(0, 8))

        for key, label in [
            ("config", "Loading configuration"),
            ("internet", "Checking internet connection"),
            ("updates", "Checking for updates"),
            ("schedule", "Loading PGA Tour schedule"),
            ("app", "Loading application"),
        ]:
            row = tk.Label(
                checklist,
                text=f"○ {label}...",
                bg="#ffffff",
                fg="#697386",
                anchor="w",
                font=("Segoe UI", 9)
            )
            row.pack(fill="x", pady=2)
            self.status_rows[key] = row

        tk.Label(
            container,
            text="© 2026 Lee Blair",
            bg="#ffffff",
            fg="#9aa4b2",
            font=("Segoe UI", 8)
        ).pack(side="bottom", pady=(10, 8))

        self.center()

    def fallback_logo(self, container):
        tk.Label(container, text="PGA", bg="#ffffff", fg="#1c2d63", font=("Segoe UI", 36, "bold")).pack(pady=(55, 0))
        tk.Label(container, text="TEE TIME BUILDER", bg="#ffffff", fg="#1aa66a", font=("Segoe UI", 18, "bold")).pack()

    def center(self):
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def set_status(self, text):
        self.status.set(text)
        self.update_idletasks()

    def set_step(self, key, state, label=None):
        if key not in self.status_rows:
            return

        icons = {
            "pending": "○",
            "working": "●",
            "done": "✓",
            "warning": "⚠",
            "error": "✕",
        }

        colors = {
            "pending": "#697386",
            "working": "#1f6feb",
            "done": "#2F9D65",
            "warning": "#b7791f",
            "error": "#c2410c",
        }

        current = self.status_rows[key].cget("text")
        base = label or current[2:].replace("...", "")
        icon = icons.get(state, "○")
        suffix = "..." if state == "working" else ""
        self.status_rows[key].config(
            text=f"{icon} {base}{suffix}",
            fg=colors.get(state, "#697386")
        )
        self.update_idletasks()





class StreamToLogger:
    def __init__(self, app):
        self.app = app
        self.buffer = ""

    def write(self, text):
        if not text:
            return
        self.buffer += str(text)
        while "\n" in self.buffer:
            line, self.buffer = self.buffer.split("\n", 1)
            if line.strip():
                self.app.log(line.rstrip())

    def flush(self):
        if self.buffer.strip():
            self.app.log(self.buffer.rstrip())
            self.buffer = ""



class SettingsWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Settings")
        self.geometry("940x430")
        self.resizable(True, True)

        try:
            self.parent.set_child_window_icon(self)
        except Exception:
            pass

        self.output_root = tk.StringVar(value=parent.config_data.get("output_root", str(DEFAULT_OUTPUT)))
        self.pdf_override = tk.StringVar(value=parent.config_data.get("pdf_override", ""))
        self.espn_override = tk.StringVar(value=parent.config_data.get("espn_override", ""))
        self.update_url = tk.StringVar(value=parent.config_data.get("update_url", ""))
        self.email_method = tk.StringVar(value=parent.config_data.get("email_method", "default"))

        self.build()

    def build(self):
        pad = {"padx": 10, "pady": 8}

        ttk.Label(self, text="Output Folder").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.output_root, width=82).grid(row=0, column=1, sticky="ew", **pad)
        ttk.Button(self, text="Browse", command=self.browse_output).grid(row=0, column=2, **pad)

        ttk.Label(self, text="PDF URL Override").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.pdf_override, width=82).grid(row=1, column=1, sticky="ew", **pad)
        ttk.Button(self, text="Clear", command=lambda: self.pdf_override.set("")).grid(row=1, column=2, **pad)

        ttk.Label(self, text="ESPN Leaderboard Override").grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.espn_override, width=82).grid(row=2, column=1, sticky="ew", **pad)
        ttk.Button(self, text="Clear", command=lambda: self.espn_override.set("")).grid(row=2, column=2, **pad)

        ttk.Label(self, text="Update JSON URL / GitHub API Override").grid(row=3, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.update_url, width=82).grid(row=3, column=1, sticky="ew", **pad)
        ttk.Button(self, text="Clear", command=lambda: self.update_url.set("")).grid(row=3, column=2, **pad)

        ttk.Label(self, text="Email Method").grid(row=4, column=0, sticky="w", **pad)
        ttk.Combobox(
            self,
            textvariable=self.email_method,
            values=["default", "gmail_web"],
            state="readonly",
            width=24
        ).grid(row=4, column=1, sticky="w", **pad)

        ttk.Label(
            self,
            text="Email Method: default uses your system mail app. gmail_web opens Gmail in your browser. Attachments still must be added manually.",
            foreground="#666666"
        ).grid(row=5, column=0, columnspan=3, sticky="w", padx=10, pady=(8, 0))

        ttk.Label(
            self,
            text="Overrides are optional. Leave blank unless auto-discovery picks the wrong source.",
            foreground="#666666"
        ).grid(row=6, column=0, columnspan=3, sticky="w", padx=10, pady=(8, 0))

        ttk.Button(self, text="Save Settings", command=self.save).grid(row=7, column=0, columnspan=3, sticky="ew", padx=10, pady=16)

        self.grid_columnconfigure(1, weight=1)

    def browse_output(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.output_root.set(path)

    def save(self):
        self.parent.config_data.update({
            "output_root": self.output_root.get(),
            "pdf_override": self.pdf_override.get().strip(),
            "espn_override": self.espn_override.get().strip(),
            "update_url": self.update_url.get().strip(),
            "email_method": self.email_method.get().strip() or "default",
            "first_run_complete": True,
        })
        save_config(self.parent.config_data)
        self.parent.refresh_settings_label()
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.withdraw()

        self.config_data = load_config()
        self.ensure_first_run_output_folder()
        self.splash = SplashWindow(self)
        self.after(250, self.finish_startup)

        self.title(f"{APP_NAME} v{APP_VERSION}")
        try:
            icon_path = resource_path("assets/icon.ico")
            if icon_path.exists():
                self.iconbitmap(str(icon_path))
        except Exception:
            pass

        try:
            self.app_icon_image = load_logo_image(max_width=64, max_height=64)
            if self.app_icon_image:
                self.iconphoto(True, self.app_icon_image)
        except Exception:
            pass

        self.geometry("980x690")
        self.minsize(900, 620)

        self.year_var = tk.StringVar(value=current_year())
        self.tour_var = tk.StringVar(value="PGA Tour")
        self.tournament_var = tk.StringVar(value=default_tournament_for_today())
        self.round_var = tk.StringVar(value="1")
        self.wave_var = tk.StringVar(value="AM")

        self.build_ui()

    def finish_startup(self):
        threading.Thread(target=self.startup_thread, daemon=True).start()

    def startup_thread(self):
        started = time.time()
        self.perform_startup_checks()

        minimum_seconds = 5.0
        elapsed = time.time() - started
        remaining_ms = max(0, int((minimum_seconds - elapsed) * 1000))

        self.after(remaining_ms, self.show_main_window)

    def show_main_window(self):
        try:
            self.splash.destroy()
        except Exception:
            pass

        self.deiconify()
        self.after(300, self.show_first_run_wizard)

        if getattr(self, "startup_warning", ""):
            self.after(700, lambda: messagebox.showwarning("Internet Required", self.startup_warning))

        if getattr(self, "startup_update_available", False):
            self.after(900, self.prompt_startup_update)



    def prompt_startup_update(self):
        info = getattr(self, "startup_release_info", None)
        if not info:
            return

        latest_version = info.get("latest_version", "")
        release_notes = info.get("release_notes", [])
        notes_text = "\n".join(f"• {n}" for n in release_notes[:6]) if isinstance(release_notes, list) else str(release_notes)

        message = (
            f"PGA Tee Time Builder {latest_version} is available.\n\n"
            f"Installed: {APP_VERSION}\n\n"
            f"{notes_text}\n\n"
            "Install now?"
        )

        if messagebox.askyesno(f"PGA Tee Time Builder {latest_version} Available", message):
            self.install_app_update(info)


    def set_child_window_icon(self, window):
        try:
            icon_path = resource_path("assets/icon.ico")
            if icon_path.exists():
                window.iconbitmap(str(icon_path))
        except Exception:
            pass

        try:
            if hasattr(self, "app_icon_image") and self.app_icon_image:
                window.iconphoto(False, self.app_icon_image)
        except Exception:
            pass



    def open_file_or_folder(self, path):
        try:
            path = Path(path)
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", str(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Open Failed", f"Could not open:\n\n{path}\n\n{exc}")

    def reveal_file(self, path):
        try:
            path = Path(path)
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", str(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", str(path)])
            else:
                self.open_file_or_folder(path.parent)
        except Exception:
            try:
                self.open_file_or_folder(Path(path).parent)
            except Exception:
                pass

    def compose_email(self, subject, body):
        method = self.config_data.get("email_method", "default")

        if method == "gmail_web":
            url = (
                "https://mail.google.com/mail/?view=cm&fs=1"
                f"&su={urllib.parse.quote(subject)}"
                f"&body={urllib.parse.quote(body)}"
            )
            webbrowser.open(url)
            return

        mailto = (
            "mailto:"
            f"?subject={urllib.parse.quote(subject)}"
            f"&body={urllib.parse.quote(body)}"
        )
        webbrowser.open(mailto)


    def compose_email_then_reveal(self, subject, body, reveal_path=None):
        """
        Opens the configured email composer first, then reveals the file/folder shortly after.
        This keeps Gmail/default mail from being buried behind Explorer as often.
        """
        self.compose_email(subject, body)

        if reveal_path:
            self.after(1200, lambda: self.reveal_file(reveal_path))


    def find_latest_tee_sheet_from_log(self):
        text = self.log_box.get("1.0", tk.END) + "\n" + getattr(self, "last_raw_output", "")

        candidates = []

        # Match common logged Windows/macOS paths ending in .xlsx.
        for match in re.finditer(r"([A-Za-z]:\\[^\\n\\r]+?\\.xlsx|/[^\\n\\r]+?\\.xlsx)", text):
            path_text = match.group(1).strip().strip('"').strip("'")
            path = Path(path_text)
            if path.exists():
                candidates.append(path)

        if candidates:
            return candidates[-1]

        output_root = Path(self.config_data.get("output_root", str(DEFAULT_OUTPUT)))
        if output_root.exists():
            files = sorted(output_root.rglob("*.xlsx"), key=lambda p: p.stat().st_mtime, reverse=True)
            if files:
                return files[0]

        return None


    def round_display_label(self):
        mapping = {
            "1": "Opening Round",
            "2": "Second Round",
            "3": "Third Round",
            "4": "Final Round",
        }
        return mapping.get(self.round_var.get(), f"Round {self.round_var.get()}")

    def wave_display_label(self):
        value = self.wave_var.get()
        if value == "ALL":
            return "All Players"
        return f"{value} Wave"

    def get_output_folder_from_sheet(self, tee_sheet):
        if tee_sheet:
            return tee_sheet.parent
        return Path(self.config_data.get("output_root", str(DEFAULT_OUTPUT)))

    def update_run_checks_from_logs(self):
        text = (self.log_box.get("1.0", tk.END) + "\n" + getattr(self, "last_raw_output", "")).lower()

        checks = getattr(self, "run_checks", {})
        if not checks:
            checks = {}

        checks["Internet Connected"] = True
        checks["PGA Tour Media Downloaded"] = (
            "found pga tour media pdf" in text
            or "parsed tee-time groups" in text
            or ("parsed " in text and "tee-time groups" in text)
        )
        checks["Leaderboard Downloaded"] = (
            "found espn leaderboard" in text
            or "parsed espn leaderboard rows" in text
            or "matched leaderboard scores" in text
            or self.round_var.get() == "1"
        )
        checks["Tee Sheet Created"] = (
            "saved finished workbook" in text
            or "saved openpyxl" in text
            or (".xlsx" in text and "saved" in text)
        )

        self.run_checks = checks
        return checks

    def append_run_summary(self, tee_sheet=None):
        checks = self.update_run_checks_from_logs()

        elapsed = ""
        if hasattr(self, "run_started_at"):
            seconds = (datetime.now() - self.run_started_at).total_seconds()
            elapsed = f"{seconds:.1f} seconds"

        if tee_sheet is None:
            tee_sheet = self.find_latest_tee_sheet_from_log()

        self.log("─" * 72)
        self.log("Run Summary")
        self.log("")
        for label in ["Internet Connected", "PGA Tour Media Downloaded", "Leaderboard Downloaded", "Tee Sheet Created"]:
            self.log(f"{'✓' if checks.get(label) else '⚠'} {label}")

        if tee_sheet:
            self.log("")
            self.log("Output")
            self.log(str(tee_sheet))

        if elapsed:
            self.log("")
            self.log("Elapsed Time")
            self.log(elapsed)

        self.log("─" * 72)

    def write_last_run_summary_file(self, report_dir, tee_sheet=None):
        if tee_sheet is None:
            tee_sheet = self.find_latest_tee_sheet_from_log()

        checks = self.update_run_checks_from_logs()
        elapsed = ""
        if hasattr(self, "run_started_at"):
            elapsed = f"{(datetime.now() - self.run_started_at).total_seconds():.1f} seconds"

        lines = [
            "PGA Tee Time Builder - Last Run Summary",
            "",
            f"App Version: {APP_VERSION}",
            f"Created: {datetime.now().isoformat(timespec='seconds')}",
            f"Tournament: {self.tournament_var.get()}",
            f"Round: {self.round_var.get()}",
            f"Wave: {self.wave_var.get()}",
            "",
            "Checks:",
        ]

        for label, value in checks.items():
            lines.append(f"{'PASS' if value else 'WARN'} - {label}")

        if tee_sheet:
            lines.extend(["", "Output:", str(tee_sheet)])

        if elapsed:
            lines.extend(["", "Elapsed Time:", elapsed])

        (report_dir / "last_run_summary.txt").write_text("\n".join(lines), encoding="utf-8")

    def write_system_information_file(self, report_dir):
        lines = [
            "PGA Tee Time Builder - System Information",
            "",
            f"App Version: {APP_VERSION}",
            f"Python: {sys.version}",
            f"Platform: {platform.platform()}",
            f"Machine: {platform.machine()}",
            f"Executable: {sys.executable}",
            f"App Directory: {APP_DIR}",
            f"User Data: {USER_DATA}",
            f"Output Root: {self.config_data.get('output_root', '')}",
            f"GitHub Repo: {GITHUB_REPO}",
        ]
        (report_dir / "system_information.txt").write_text("\n".join(lines), encoding="utf-8")

    def write_config_snapshot_file(self, report_dir):
        safe_config = dict(self.config_data)
        (report_dir / "config.json").write_text(json.dumps(safe_config, indent=2), encoding="utf-8")


    def show_completion_dialog(self):
        tee_sheet = self.find_latest_tee_sheet_from_log()
        output_folder = self.get_output_folder_from_sheet(tee_sheet)
        self.append_run_summary(tee_sheet)

        dialog = tk.Toplevel(self)
        dialog.title("Tee Sheet Complete")
        dialog.geometry("640x570")
        dialog.minsize(600, 530)
        dialog.resizable(True, True)
        dialog.configure(bg="#ffffff")
        self.set_child_window_icon(dialog)
        dialog.transient(self)
        dialog.grab_set()

        frame = tk.Frame(dialog, bg="#ffffff")
        frame.pack(fill="both", expand=True, padx=30, pady=24)

        header = tk.Frame(frame, bg="#ffffff")
        header.pack(fill="x", pady=(0, 8))

        logo_ref = {"image": load_header_logo_image(max_width=54, max_height=54)}
        if logo_ref["image"]:
            tk.Label(header, image=logo_ref["image"], bg="#ffffff").pack(side="left", padx=(0, 12))
        dialog.logo_ref = logo_ref

        title_box = tk.Frame(header, bg="#ffffff")
        title_box.pack(side="left", fill="x", expand=True)

        tk.Label(
            title_box,
            text="✓ Tee Sheet Ready",
            bg="#ffffff",
            fg="#2F9D65",
            font=("Segoe UI", 21, "bold")
        ).pack(anchor="w")

        tk.Label(
            title_box,
            text=f"{self.tournament_var.get()}",
            bg="#ffffff",
            fg="#111827",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(2, 0))

        tk.Label(
            title_box,
            text=f"{self.round_display_label()} • {self.wave_display_label()}",
            bg="#ffffff",
            fg="#697386",
            font=("Segoe UI", 10)
        ).pack(anchor="w")

        tk.Frame(frame, height=1, bg="#e5e7eb").pack(fill="x", pady=(14, 14))

        tk.Label(
            frame,
            text="Saved Successfully",
            bg="#ffffff",
            fg="#111827",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w")

        if tee_sheet:
            tk.Label(
                frame,
                text=tee_sheet.name,
                bg="#ffffff",
                fg="#111827",
                font=("Segoe UI", 10),
                wraplength=560,
                justify="left"
            ).pack(anchor="w", pady=(4, 2))

        tk.Label(
            frame,
            text="Output Folder",
            bg="#ffffff",
            fg="#697386",
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", pady=(12, 0))

        tk.Label(
            frame,
            text=str(output_folder),
            bg="#ffffff",
            fg="#697386",
            font=("Segoe UI", 9),
            wraplength=560,
            justify="left"
        ).pack(anchor="w", pady=(2, 14))

        button_frame = tk.Frame(frame, bg="#ffffff")
        button_frame.pack(fill="x", pady=(6, 0))

        def open_sheet():
            if tee_sheet:
                self.open_file_or_folder(tee_sheet)
            dialog.destroy()

        def open_folder():
            self.open_file_or_folder(output_folder)
            dialog.destroy()

        def email_sheet():
            subject = f"PGA Tee Sheet - {self.tournament_var.get()} {self.round_display_label()}"
            body = "Tee sheet is ready.\n\n"

            if tee_sheet:
                body += (
                    f"Tournament: {self.tournament_var.get()}\n"
                    f"Round: {self.round_display_label()}\n"
                    f"Wave: {self.wave_display_label()}\n\n"
                    "Please attach this file:\n"
                    f"{tee_sheet}\n\n"
                    "The app will open the file location to make attaching it easier."
                )
                self.compose_email_then_reveal(subject, body, tee_sheet)
            else:
                body += "The tee sheet was created successfully."
                self.compose_email(subject, body)

            dialog.destroy()

        ttk.Button(button_frame, text="Open Tee Sheet", command=open_sheet).pack(fill="x", pady=5)
        ttk.Button(button_frame, text="Open Output Folder", command=open_folder).pack(fill="x", pady=5)
        ttk.Button(button_frame, text="Email Tee Sheet", command=email_sheet).pack(fill="x", pady=5)

        tk.Frame(frame, height=1, bg="#e5e7eb").pack(fill="x", pady=(18, 12))

        ttk.Button(frame, text="Close", command=dialog.destroy).pack(fill="x")


    def show_about(self):
        about = tk.Toplevel(self)
        about.title("About PGA Tee Time Builder")
        self.set_child_window_icon(about)
        about.geometry("470x490")
        about.resizable(False, False)
        about.configure(bg="#ffffff")
        logo_ref = {"image": None}

        frame = tk.Frame(about, bg="#ffffff")
        frame.pack(fill="both", expand=True, padx=28, pady=24)

        logo_ref["image"] = load_logo_image(max_width=300, max_height=215, filename="logo_main.png")
        if logo_ref["image"]:
            tk.Label(frame, image=logo_ref["image"], bg="#ffffff").pack(pady=(8, 10))

        about.logo_ref = logo_ref

        tk.Label(frame, text=f"Version {APP_VERSION}", bg="#ffffff", fg="#697386", font=("Segoe UI", 10)).pack(pady=(2, 12))
        tk.Label(frame, text="Built by Lee Blair", bg="#ffffff", fg="#111827", font=("Segoe UI", 11, "bold")).pack()
        tk.Label(frame, text="© 2026 Lee Blair. All Rights Reserved.", bg="#ffffff", fg="#697386", font=("Segoe UI", 9)).pack(pady=(4, 14))
        tk.Label(frame, text=f"GitHub: {GITHUB_REPO}", bg="#ffffff", fg="#1aa66a", font=("Segoe UI", 9)).pack(pady=(0, 18))
        ttk.Button(frame, text="Close", command=about.destroy).pack(side="bottom", fill="x", padx=90, pady=(14, 8))


    def ensure_first_run_output_folder(self):
        output_root = Path(self.config_data.get("output_root", str(DEFAULT_OUTPUT)))

        if output_root.exists():
            return

        output_root.mkdir(parents=True, exist_ok=True)



    def show_first_run_wizard(self):
        if self.config_data.get("first_run_complete"):
            return

        welcome = tk.Toplevel(self)
        welcome.title("Welcome to PGA Tee Time Builder")
        welcome.geometry("560x360")
        welcome.resizable(False, False)
        welcome.configure(bg="#ffffff")
        self.set_child_window_icon(welcome)
        welcome.transient(self)
        welcome.grab_set()

        logo_ref = {"image": load_logo_image(max_width=300, max_height=120, filename="logo_main.png")}

        frame = tk.Frame(welcome, bg="#ffffff")
        frame.pack(fill="both", expand=True, padx=28, pady=24)

        if logo_ref["image"]:
            tk.Label(frame, image=logo_ref["image"], bg="#ffffff").pack(pady=(0, 14))

        welcome.logo_ref = logo_ref

        tk.Label(
            frame,
            text="Where would you like to save finished tee sheets?",
            bg="#ffffff",
            fg="#111827",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(4, 10))

        folder_var = tk.StringVar(value=self.config_data.get("output_root", str(DEFAULT_OUTPUT)))

        row = tk.Frame(frame, bg="#ffffff")
        row.pack(fill="x", pady=(0, 16))

        tk.Entry(row, textvariable=folder_var).pack(side="left", fill="x", expand=True)

        def browse():
            path = filedialog.askdirectory(title="Select output folder")
            if path:
                folder_var.set(path)

        ttk.Button(row, text="Browse", command=browse).pack(side="left", padx=(8, 0))

        def save_and_close():
            self.config_data["output_root"] = folder_var.get()
            self.config_data["first_run_complete"] = True
            save_config(self.config_data)
            self.refresh_settings_label()
            welcome.destroy()

        ttk.Button(frame, text="Save and Continue", command=save_and_close).pack(fill="x", pady=(10, 0))


    def build_ui(self):
        self.configure(bg="#141821")

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("TFrame", background="#141821")
        style.configure("Card.TFrame", background="#1f2633", relief="flat")
        style.configure("TLabel", background="#141821", foreground="#e8edf7", font=("Segoe UI", 10))
        style.configure("Header.TLabel", background="#0E1726", foreground="#ffffff", font=("Segoe UI Semibold", 20, "bold"))
        style.configure("HeaderSub.TLabel", background="#0E1726", foreground="#C5CCD5", font=("Segoe UI", 10))
        style.configure("Sub.TLabel", background="#141821", foreground="#9ca8bd", font=("Segoe UI", 10))
        style.configure("Card.TLabel", background="#1f2633", foreground="#e8edf7", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Run.TButton", font=("Segoe UI", 13, "bold"), padding=12)
        style.configure("TCombobox", padding=6)

        header = tk.Canvas(self, height=104, highlightthickness=0, bd=0)
        header.pack(fill="x")
        self.header_canvas = header

        def draw_header_gradient(event=None):
            header.delete("gradient")
            width = max(header.winfo_width(), 1)
            height = max(header.winfo_height(), 1)

            # Dark Broadcast gradient: mostly navy, subtle green at far right.
            c1 = (14, 23, 38)    # #0E1726
            c2 = (22, 43, 58)    # #162B3A
            c3 = (33, 68, 56)    # #214438

            for x in range(width):
                t = x / max(width - 1, 1)
                if t < 0.82:
                    local = t / 0.82
                    r = int(c1[0] + (c2[0] - c1[0]) * local)
                    g = int(c1[1] + (c2[1] - c1[1]) * local)
                    b = int(c1[2] + (c2[2] - c1[2]) * local)
                else:
                    local = (t - 0.82) / 0.18
                    r = int(c2[0] + (c3[0] - c2[0]) * local)
                    g = int(c2[1] + (c3[1] - c2[1]) * local)
                    b = int(c2[2] + (c3[2] - c2[2]) * local)
                color = f"#{r:02x}{g:02x}{b:02x}"
                header.create_line(x, 0, x, height, fill=color, tags="gradient")

            header.create_line(0, 0, width, 0, fill="#263449", tags="gradient")
            header.create_line(0, height - 1, width, height - 1, fill="#050a12", tags="gradient")
            header.lower("gradient")

        header.bind("<Configure>", draw_header_gradient)

        title_row = tk.Frame(header, bg="#0E1726")
        header.create_window(18, 18, anchor="nw", window=title_row)

        self.header_logo_image = load_header_logo_image(max_width=54, max_height=54)
        if self.header_logo_image:
            tk.Label(title_row, image=self.header_logo_image, bg="#0E1726").pack(side="left", padx=(0, 12))

        title_text_frame = tk.Frame(title_row, bg="#0E1726")
        title_text_frame.pack(side="left", anchor="center")

        ttk.Label(title_text_frame, text="PGA Tee Time Builder", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            title_text_frame,
            text="Build formatted tee sheets from PGA Tour Media",
            style="HeaderSub.TLabel"
        ).pack(anchor="w", pady=(2, 0))

        action_row = tk.Frame(header, bg="#162B3A")
        action_window_id = header.create_window(960, 20, anchor="ne", window=action_row)

        ttk.Button(action_row, text="⚙ Settings", command=self.open_settings).pack(side="right")
        ttk.Button(action_row, text="About", command=self.show_about).pack(side="right", padx=(0, 8))
        ttk.Button(action_row, text="Report Issue", command=self.report_parser_issue).pack(side="right", padx=(0, 8))
        ttk.Button(action_row, text="Check for Updates", command=self.check_for_updates).pack(side="right", padx=(0, 8))

        def place_actions(event=None):
            try:
                header.coords(action_window_id, max(header.winfo_width() - 18, 18), 20)
            except Exception:
                pass

        header.bind("<Configure>", lambda e: (draw_header_gradient(e), place_actions(e)))

        card = ttk.Frame(self, style="Card.TFrame", padding=18)
        card.pack(fill="x", padx=18, pady=(0, 14))

        for c in range(6):
            card.grid_columnconfigure(c, weight=1)

        self.add_combo(card, "YEAR", self.year_var, [str(y) for y in range(int(current_year()) - 1, int(current_year()) + 3)], 0, 0)
        self.add_combo(card, "TOUR", self.tour_var, ["PGA Tour"], 0, 1)
        self.add_combo(card, "TOURNAMENT", self.tournament_var, TOURNAMENT_LABELS, 0, 2, colspan=2)
        self.add_combo(card, "ROUND", self.round_var, ROUND_LABELS, 0, 4)
        self.add_combo(card, "WAVE", self.wave_var, WAVE_LABELS, 0, 5)

        self.settings_label = ttk.Label(self, text="", style="Sub.TLabel")
        self.settings_label.pack(fill="x", padx=24, pady=(0, 8))
        self.refresh_settings_label()

        self.run_button = RoundedButton(
            self,
            text="🏌 BUILD TEE SHEET",
            command=self.run,
            bg="#2F9D65",
            hover_bg="#37B573",
            pressed_bg="#25804F",
            disabled_bg="#25804F",
            fg="white",
            disabled_fg="#d9efe3",
            radius=18,
            height=54,
            font=("Segoe UI", 12, "bold"),
        )
        self.run_button.pack(fill="x", padx=18, pady=(0, 6))

        self.status_message = tk.StringVar(value="● Ready")
        self.status_label = ttk.Label(self, textvariable=self.status_message, style="Sub.TLabel")
        self.status_label.pack(fill="x", padx=24, pady=(0, 4))

        self.last_build_var = tk.StringVar(value=self.config_data.get("last_build_summary", "Last Build: None yet"))
        self.last_build_label = ttk.Label(self, textvariable=self.last_build_var, style="Sub.TLabel")
        self.last_build_label.pack(fill="x", padx=24, pady=(0, 10))

        log_frame = ttk.Frame(self, padding=(18, 0, 18, 18))
        log_frame.pack(fill="both", expand=True)

        self.log_box = scrolledtext.ScrolledText(
            log_frame,
            height=20,
            bg="#0d1117",
            fg="#d6deeb",
            insertbackground="#ffffff",
            font=("Consolas", 10),
            wrap=tk.WORD
        )
        self.log_box.pack(fill="both", expand=True)

        self.last_raw_output = ""
        self.log("● Ready.")
        self.log("Choose year / tournament / round / wave, then run.")

    def add_combo(self, parent, label, var, values, row, col, colspan=1):
        ttk.Label(parent, text=label, style="Card.TLabel").grid(row=row, column=col, columnspan=colspan, sticky="w", padx=6, pady=(0, 6))
        combo = ttk.Combobox(parent, textvariable=var, values=values, state="readonly")
        combo.grid(row=row + 1, column=col, columnspan=colspan, sticky="ew", padx=6)

    def refresh_settings_label(self):
        override_bits = []
        if self.config_data.get("pdf_override", "").strip():
            override_bits.append("PDF override ON")
        if self.config_data.get("espn_override", "").strip():
            override_bits.append("ESPN override ON")
        suffix = "     " + " | ".join(override_bits) if override_bits else ""

        self.settings_label.config(
            text=f"Output: {self.config_data.get('output_root', '')}{suffix}"
        )

    def open_settings(self):
        SettingsWindow(self)

    def log(self, text):
        ts = datetime.now().strftime("%H:%M:%S")
        display_text = format_log_line_for_display(text)
        self.log_box.insert(tk.END, f"[{ts}] {display_text}\n")
        self.log_box.see(tk.END)
        self.update_idletasks()

    def log_status(self, text):
        self.status_message.set(text)
        self.log(text)

    def version_tuple(self, version_text):
        """
        Compare only the numeric part of versions.

        Examples:
        - 1.0.2-dev -> (1, 0, 2)
        - v1.0.2    -> (1, 0, 2)
        - 1.0.2-rc1 -> (1, 0, 2)
        """
        cleaned = str(version_text).strip().lstrip("vV")
        cleaned = re.split(r"[-+_ ]", cleaned, maxsplit=1)[0]

        parts = []
        for part in cleaned.split("."):
            match = re.match(r"(\d+)", part)
            parts.append(int(match.group(1)) if match else 0)

        while len(parts) < 3:
            parts.append(0)

        return tuple(parts[:3])

    def is_release_newer(self, latest_version):
        """
        Return True only if the GitHub release numeric version is newer.

        This prevents a dev build like 1.0.2-dev from being told to
        update backwards to the public 1.0.1 release.
        """
        return self.version_tuple(latest_version) > self.version_tuple(APP_VERSION)



    def get_latest_release_info(self, timeout=8):
        update_url = self.config_data.get("update_url", "").strip() or GITHUB_RELEASE_API

        with urllib.request.urlopen(update_url, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))

        latest_version = str(data.get("version") or data.get("tag_name") or "").strip().lstrip("v")
        release_notes = data.get("notes", [])
        release_url = data.get("html_url") or GITHUB_LATEST_RELEASE_PAGE

        if not release_notes and data.get("body"):
            release_notes = []
            for line in str(data.get("body", "")).splitlines():
                clean = line.strip()
                if not clean:
                    continue
                if clean.startswith("#") or clean in {"---", "***", "___"}:
                    continue
                clean = clean.strip("-• ").strip()
                if clean:
                    release_notes.append(clean)

        update_zip_url = ""
        installer_url = ""
        mac_url = ""

        for asset in data.get("assets", []):
            asset_name = asset.get("name", "").lower()
            asset_url = asset.get("browser_download_url", "")

            if asset_name.endswith(".zip") and (
                "pga_teetime_builder_update" in asset_name
                or "pga_tee_time_builder_update" in asset_name
                or "update" in asset_name
            ):
                update_zip_url = asset_url

            if asset_name.endswith(".exe") and ("setup" in asset_name or "installer" in asset_name):
                installer_url = asset_url

            if asset_name.endswith((".zip", ".dmg")) and ("mac" in asset_name or "macos" in asset_name):
                mac_url = asset_url

        return {
            "latest_version": latest_version,
            "release_notes": release_notes,
            "release_url": release_url,
            "update_zip_url": update_zip_url,
            "installer_url": installer_url,
            "mac_url": mac_url,
            "raw": data,
        }

    def is_online(self, timeout=4):
        checks = [
            GITHUB_RELEASE_API,
            "https://www.espn.com/",
            "https://pgatourmedia.pgatourhq.com/",
        ]

        for url in checks:
            try:
                req = urllib.request.Request(url, method="HEAD")
                with urllib.request.urlopen(req, timeout=timeout):
                    return True
            except Exception:
                try:
                    with urllib.request.urlopen(url, timeout=timeout):
                        return True
                except Exception:
                    pass

        return False

    def get_installer_asset_for_platform(self, release_info):
        if sys.platform.startswith("win"):
            return release_info.get("installer_url", "")
        if sys.platform == "darwin":
            return release_info.get("mac_url", "")
        return ""

    def perform_startup_checks(self):
        self.startup_online = False
        self.startup_update_available = False
        self.startup_release_info = None
        self.startup_warning = ""

        try:
            self.splash.set_status("Initializing...")
            self.splash.set_step("config", "working", "Loading configuration")
            time.sleep(0.35)
            self.splash.set_step("config", "done", "Configuration loaded")

            self.splash.set_status("Checking internet connection...")
            self.splash.set_step("internet", "working", "Checking internet connection")
            self.startup_online = self.is_online(timeout=3)

            if not self.startup_online:
                self.splash.set_step("internet", "warning", "No internet connection")
                self.splash.set_step("updates", "warning", "Update check skipped")
                self.splash.set_step("schedule", "warning", "Online schedule unavailable")
                self.splash.set_step("app", "done", "Application ready")
                self.splash.set_status("Internet required")
                self.startup_warning = (
                    "Internet connection is required to download PGA Tour Media tee sheets "
                    "and ESPN leaderboard data."
                )
                return

            self.splash.set_step("internet", "done", "Internet connected")

            self.splash.set_status("Checking for updates...")
            self.splash.set_step("updates", "working", "Checking for updates")
            info = self.get_latest_release_info(timeout=6)
            self.startup_release_info = info

            latest_version = info.get("latest_version", "")
            if latest_version and self.is_release_newer(latest_version):
                self.startup_update_available = True
                self.splash.set_step("updates", "warning", f"Update {latest_version} available")
                self.splash.set_status(f"Update {latest_version} available")
            else:
                self.splash.set_step("updates", "done", "No updates available")
                self.splash.set_status("✓ Up to date")

            self.splash.set_step("schedule", "working", "Loading PGA Tour schedule")
            time.sleep(0.35)
            self.splash.set_step("schedule", "done", "PGA Tour schedule loaded")

            self.splash.set_step("app", "working", "Loading application")
            time.sleep(0.35)
            self.splash.set_step("app", "done", "Application ready")
            self.splash.set_status("Ready")

        except Exception:
            self.splash.set_step("updates", "warning", "Update check unavailable")
            self.splash.set_step("schedule", "done", "PGA Tour schedule loaded")
            self.splash.set_step("app", "done", "Application ready")
            self.splash.set_status("Ready")


    def check_for_updates(self):
        try:
            self.log("● Checking GitHub for updates...")

            if not self.is_online(timeout=4):
                messagebox.showwarning(
                    "Internet Required",
                    "Internet connection is required to check for updates."
                )
                self.log("✕ No internet connection.")
                return

            try:
                info = self.get_latest_release_info(timeout=10)
            except urllib.error.HTTPError as exc:
                if exc.code == 404:
                    messagebox.showinfo(
                        "No GitHub Release Found",
                        f"I could not find a published GitHub release in:\n\n{GITHUB_REPO}\n\n"
                        "Make sure the public Releases repo has a published, non-prerelease latest release."
                    )
                    self.log("● No published GitHub release found yet.")
                    return
                raise

            latest_version = info.get("latest_version", "")
            if not latest_version:
                raise RuntimeError("Could not find a version number in the latest GitHub release.")

            if not self.is_release_newer(latest_version):
                self.log("✓ App is up to date.")
                messagebox.showinfo(
                    "No Update Available",
                    f"No newer release is available.\n\nInstalled: {APP_VERSION}\nLatest public release: {latest_version}"
                )
                return

            release_notes = info.get("release_notes", [])
            notes_text = "\n".join(f"• {n}" for n in release_notes[:8]) if isinstance(release_notes, list) else str(release_notes)

            message = (
                f"PGA Tee Time Builder {latest_version} Available\n\n"
                f"You're currently running:\n{APP_VERSION}\n\n"
                f"Highlights\n{notes_text}\n\n"
                "Install now?"
            )

            if messagebox.askyesno(f"PGA Tee Time Builder {latest_version} Available", message):
                self.install_app_update(info)

        except Exception as exc:
            messagebox.showerror("Update Check Failed", f"Could not check for updates.\n\n{exc}")

    def install_app_update(self, release_info):
        try:
            download_url = self.get_installer_asset_for_platform(release_info)
            latest_version = release_info.get("latest_version", "")
            release_url = release_info.get("release_url") or GITHUB_LATEST_RELEASE_PAGE

            if not download_url:
                if messagebox.askyesno(
                    "Installer Not Found",
                    "I found an update, but could not find an installer asset for this platform.\n\n"
                    "Open the GitHub Release page instead?"
                ):
                    webbrowser.open(release_url)
                return

            self.log(f"● Downloading installer for {latest_version}...")
            temp_dir = Path(tempfile.mkdtemp(prefix="pga_teetime_installer_"))

            filename = download_url.split("/")[-1] or f"PGA_TeeTime_Builder_Setup_v{latest_version}.exe"
            installer_path = temp_dir / filename

            urllib.request.urlretrieve(download_url, installer_path)
            self.log(f"✓ Downloaded installer: {installer_path}")

            if sys.platform.startswith("win"):
                messagebox.showinfo(
                    "Installer Ready",
                    "The update installer has been downloaded.\n\n"
                    "The app will now close and launch the installer."
                )
                subprocess.Popen([str(installer_path)])
                self.after(500, self.destroy)
                return

            if sys.platform == "darwin":
                messagebox.showinfo(
                    "Mac Update Downloaded",
                    f"The Mac update was downloaded here:\n\n{installer_path}\n\n"
                    "Open it to update the app."
                )
                subprocess.Popen(["open", str(installer_path)])
                return

            webbrowser.open(release_url)

        except Exception as exc:
            messagebox.showerror("Update Failed", f"The update could not be installed.\n\n{exc}")

    def install_update_zip(self, download_url, latest_version):
        try:
            self.log(f"● Downloading update {latest_version}...")
            temp_dir = Path(tempfile.mkdtemp(prefix="pga_teetime_update_"))
            zip_path = temp_dir / "update.zip"

            urllib.request.urlretrieve(download_url, zip_path)

            extract_dir = temp_dir / "extract"
            extract_dir.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(extract_dir)

            candidate_dirs = [
                extract_dir / "src",
                extract_dir / "Scripts",
                extract_dir / "PGATeeTimeData" / "Scripts",
                extract_dir,
            ]

            copied = []

            for candidate in candidate_dirs:
                if not candidate.exists():
                    continue

                for pattern in ["*.py", "*.bat", "*.command"]:
                    for file in candidate.glob(pattern):
                        dest = SCRIPTS / file.name
                        shutil.copy2(file, dest)
                        copied.append(dest.name)

            if not copied:
                raise RuntimeError("No updateable script files were found in the update ZIP.")

            self.log(f"✓ Update {latest_version} installed.")
            messagebox.showinfo(
                "Update Installed",
                f"Update {latest_version} installed.\n\n"
                "Please close and reopen the app.\n\n"
                f"Files updated:\n" + "\n".join(copied)
            )

        except Exception as exc:
            messagebox.showerror("Update Failed", f"The update could not be installed.\n\n{exc}")

    def explain_failure(self, log_text):
        text = log_text.lower()

        if "404 client error" in text and ("tee times.pdf" in text or "roundinfo" in text):
            return (
                "I could not find the PGA Tour Media tee-time PDF.\n\n"
                "This usually means PGA used a different file name this week or the PDF is not posted yet.\n\n"
                "Fix: open Settings and paste the pgatourmedia.pgatourhq.com tee-time PDF link into PDF URL Override."
            )

        if "no tee-time groups were parsed" in text:
            return (
                "The PDF was found, but I could not read any tee-time groups from it.\n\n"
                "This usually means PGA changed the PDF layout. Send the log and a screenshot of the PDF."
            )

        if "espn" in text and ("leaderboard" in text or "score" in text) and ("error" in text or "failed" in text):
            return (
                "I had trouble finding or reading the ESPN leaderboard for scores.\n\n"
                "Fix: open Settings and paste the ESPN tournament leaderboard link into ESPN Leaderboard Override."
            )

        return "The tee sheet update failed.\n\nCheck the log window for details, or send the log for troubleshooting."


    def ask_issue_description(self):
        dialog = tk.Toplevel(self)
        dialog.title("Report Issue")
        dialog.geometry("560x420")
        dialog.resizable(True, True)
        dialog.configure(bg="#ffffff")
        self.set_child_window_icon(dialog)
        dialog.transient(self)
        dialog.grab_set()

        result = {"text": "", "cancelled": True}

        frame = tk.Frame(dialog, bg="#ffffff")
        frame.pack(fill="both", expand=True, padx=18, pady=18)

        tk.Label(
            frame,
            text="Tell me what happened:",
            bg="#ffffff",
            fg="#111827",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w", pady=(0, 8))

        text_box = tk.Text(frame, height=12, wrap=tk.WORD, font=("Segoe UI", 10))
        text_box.pack(fill="both", expand=True)

        button_row = tk.Frame(frame, bg="#ffffff")
        button_row.pack(fill="x", pady=(12, 0))

        def submit():
            result["text"] = text_box.get("1.0", tk.END).strip()
            result["cancelled"] = False
            dialog.destroy()

        def cancel():
            dialog.destroy()

        ttk.Button(button_row, text="Cancel", command=cancel).pack(side="right", padx=(8, 0))
        ttk.Button(button_row, text="Create Report", command=submit).pack(side="right")

        self.wait_window(dialog)
        return None if result["cancelled"] else result["text"]


    def report_parser_issue(self):
        try:
            issue_description = self.ask_issue_description()
            if issue_description is None:
                return

            reports_dir = SCRIPTS / "Data" / "IssueReports"
            reports_dir.mkdir(parents=True, exist_ok=True)

            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_dir = reports_dir / f"issue_report_{stamp}"
            report_dir.mkdir(parents=True, exist_ok=True)

            log_text = self.log_box.get("1.0", tk.END)
            raw_log_text = getattr(self, "last_raw_output", "")
            report = {
                "app_version": APP_VERSION,
                "created": datetime.now().isoformat(timespec="seconds"),
                "year": self.year_var.get(),
                "tour": self.tour_var.get(),
                "tournament": self.tournament_var.get(),
                "round": self.round_var.get(),
                "wave": self.wave_var.get(),
                "script_path": self.config_data.get("script_path", ""),
                "output_root": self.config_data.get("output_root", ""),
                "pdf_override_active": bool(self.config_data.get("pdf_override", "").strip()),
                "espn_override_active": bool(self.config_data.get("espn_override", "").strip()),
            }

            (report_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
            (report_dir / "issue_description.txt").write_text(issue_description, encoding="utf-8")
            (report_dir / "console_log.txt").write_text(log_text, encoding="utf-8")
            (report_dir / "raw_console_log.txt").write_text(raw_log_text, encoding="utf-8")
            self.write_system_information_file(report_dir)
            self.write_config_snapshot_file(report_dir)
            self.write_last_run_summary_file(report_dir)

            data_dir = SCRIPTS / "Data"
            for name in ["espn_missing_score_matches.txt"]:
                src = data_dir / name
                if src.exists():
                    shutil.copy2(src, report_dir / name)

            zip_path = reports_dir / f"issue_report_{stamp}.zip"
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for file in report_dir.rglob("*"):
                    zf.write(file, file.relative_to(report_dir))

            self.log(f"Created issue report: {zip_path}")

            subject = f"PGA Tee Time Builder Issue - {self.tournament_var.get()} R{self.round_var.get()} {self.wave_var.get()}"
            body = (
                "Issue report attached.\n\n"
                f"Tournament: {self.tournament_var.get()}\n"
                f"Round: {self.round_var.get()}\n"
                f"Wave: {self.wave_var.get()}\n\n"
                f"Report ZIP:\n{zip_path}\n"
            )

            # Launch email using the configured method.
            # Attachments cannot be added reliably by mailto/Gmail URLs, so we create/select the ZIP.
            self.compose_email_then_reveal(
                subject,
                body + chr(10) + "Please attach the ZIP file listed above.",
                zip_path
            )

            messagebox.showinfo(
                "Issue Report Created",
                f"I created the report ZIP here:\n\n{zip_path}\n\n"
                "Your default email app should open next. Please attach that ZIP file manually."
            )

        except Exception as exc:
            messagebox.showerror("Issue Report Failed", f"Could not create issue report.\n\n{exc}")

    def run(self):
        self.run_started_at = datetime.now()
        self.log_box.delete("1.0", tk.END)
        self.log("● Preparing run...")

        tournament_label = self.tournament_var.get()
        tournament_slug = TOURNAMENT_SLUGS[tournament_label]
        pdf_override = self.config_data.get("pdf_override", "").strip()
        espn_override = self.config_data.get("espn_override", "").strip()

        if "espn.com" in pdf_override.lower() and not espn_override:
            espn_override = pdf_override
            pdf_override = ""

        if not self.is_online(timeout=4):
            messagebox.showwarning(
                "Internet Required",
                "Internet connection is required to download PGA Tour Media tee sheets and ESPN leaderboard data."
            )
            self.log("✕ No internet connection.")
            return

        self.run_checks = {
            "Internet Connected": True,
            "PGA Tour Media Downloaded": False,
            "Leaderboard Downloaded": False,
            "Tee Sheet Created": False,
        }

        self.log("Selected inputs:")
        self.log(f"  Year: {self.year_var.get()}")
        self.log(f"  Tournament: {tournament_label} / {tournament_slug}")
        self.log(f"  Round: {self.round_var.get()}")
        self.log(f"  Wave: {self.wave_var.get()}")

        if pdf_override:
            self.log(f"  PDF Override: {pdf_override}")
        if espn_override:
            self.log(f"  ESPN Override: {espn_override}")

        self.run_button.config(
            state="disabled",
            text="BUILDING…",
            bg="#25804F",
            cursor="watch",
        )
        self.status_message.set("● Building tee sheet…")

        threading.Thread(
            target=self.run_thread,
            args=(tournament_slug, pdf_override, espn_override),
            daemon=True
        ).start()

    def run_thread(self, tournament_slug, pdf_override, espn_override):
        try:
            args = [
                "--season", self.year_var.get(),
                "--tour", "pgatour",
                "--tournament", tournament_slug,
                "--round", self.round_var.get(),
                "--wave", self.wave_var.get(),
                "--output-root", self.config_data.get("output_root", str(DEFAULT_OUTPUT)),
            ]

            if pdf_override:
                args += ["--pdf-override", pdf_override]
            if espn_override:
                args += ["--espn-override", espn_override]

            self.log("-" * 90)
            self.log("● Starting tee sheet engine...")
            self.log("-" * 90)

            captured = StreamToLogger(self)

            with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
                import import_pga_teetimes_openpyxl as engine

                # v1.0.2: completion dialog now gives user the choice to open the file,
                # so suppress automatic os.startfile calls from older exporter logic.
                original_startfile = getattr(os, "startfile", None)
                if original_startfile is not None:
                    os.startfile = lambda *a, **k: None

                try:
                    engine.main(args)
                finally:
                    if original_startfile is not None:
                        os.startfile = original_startfile

            captured.flush()
            self.last_raw_output = self.log_box.get("1.0", tk.END)

            self.log("-" * 90)
            self.log("✓ Complete.")
            self.status_message.set("✓ Tee sheet created successfully.")
            summary = f"Last Build: {self.year_var.get()} {self.tournament_var.get()} • Round {self.round_var.get()} • {self.wave_var.get()} • {datetime.now().strftime('%I:%M %p')}"
            self.config_data["last_build_summary"] = summary
            save_config(self.config_data)
            self.last_build_var.set(summary)
            self.show_completion_dialog()

        except SystemExit as exc:
            code = exc.code if isinstance(exc.code, int) else 1
            self.log("-" * 90)
            self.log(f"✕ Failed with exit code {code}.")
            self.status_message.set("✕ Tee sheet update failed.")
            messagebox.showerror(
                "Tee Sheet Update Failed",
                self.explain_failure(self.log_box.get("1.0", tk.END))
            )

        except Exception as exc:
            self.log(f"ERROR: {exc}")
            self.status_message.set("✕ Tee sheet update failed.")
            messagebox.showerror(
                "Tee Sheet Update Failed",
                self.explain_failure(self.log_box.get("1.0", tk.END) + "\\n" + str(exc))
            )

        finally:
            self.run_button.config(
                state="normal",
                text="🏌 BUILD TEE SHEET",
                bg="#2F9D65",
                cursor="hand2",
            )


if __name__ == "__main__":
    set_windows_app_id()
    USER_DATA.mkdir(parents=True, exist_ok=True)
    (USER_DATA / "Data").mkdir(parents=True, exist_ok=True)
    DEFAULT_OUTPUT.mkdir(parents=True, exist_ok=True)
    App().mainloop()
