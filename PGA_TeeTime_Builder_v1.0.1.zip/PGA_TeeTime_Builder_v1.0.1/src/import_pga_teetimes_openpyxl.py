import os
import sys
import argparse
import re
import importlib.util
from pathlib import Path
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins


APP_DIR = os.path.dirname(os.path.abspath(__file__))

if sys.platform.startswith("win"):
    USER_DATA_FOLDER = os.path.join(os.path.expanduser("~"), "AppData", "Local", "PGA Tee Time Builder")
    DEFAULT_OUTPUT_FOLDER = os.path.join(os.path.expanduser("~"), "Documents", "PGA Tee Time Builder", "Finished Tee Sheets")
else:
    USER_DATA_FOLDER = os.path.join(os.path.expanduser("~"), "Library", "Application Support", "PGA Tee Time Builder")
    DEFAULT_OUTPUT_FOLDER = os.path.join(os.path.expanduser("~"), "Documents", "PGA Tee Time Builder", "Finished Tee Sheets")

BASE_FOLDER = USER_DATA_FOLDER
SCRIPTS_FOLDER = APP_DIR
FINISHED_FOLDER = DEFAULT_OUTPUT_FOLDER
SETUP_WORKBOOK = ""
PARSER_SCRIPT = os.path.join(APP_DIR, "import_pga_teetimes_parser.py")


TOUR_DISPLAY = {
    "pgatour": "PGA TOUR",
}


def load_parser(parser_script):
    """
    Load the parser module. In source mode, this can load from a file path.
    In PyInstaller/installed mode, it falls back to the bundled module import.
    """
    try:
        if parser_script and os.path.exists(parser_script):
            import importlib.util
            spec = importlib.util.spec_from_file_location("pga_parser", parser_script)
            parser_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(parser_module)
            return parser_module
    except Exception:
        pass

    import import_pga_teetimes_parser as parser_module
    return parser_module


def clean_text(value):
    if value is None:
        return ""
    return str(value).strip()


def clean_excel_int(value, default=""):
    text = clean_text(value)

    if not text:
        return default

    try:
        num = float(text)
        if num.is_integer():
            return str(int(num))
    except Exception:
        pass

    return text


def safe_filename(text):
    text = clean_text(text).upper()
    text = re.sub(r"[^A-Z0-9]+", "_", text)
    return text.strip("_")


def read_settings_openpyxl(workbook_path):
    wb = load_workbook(workbook_path, keep_vba=True, data_only=False)

    if "Import_Settings" not in wb.sheetnames:
        raise RuntimeError(f"Could not find Import_Settings in {workbook_path}")

    ws = wb["Import_Settings"]

    season = clean_excel_int(ws["B2"].value, str(datetime.now().year))
    tour_folder = clean_text(ws["B3"].value) or "pgatour"
    tournament_slug = clean_text(ws["B4"].value)
    round_num = int(clean_excel_int(ws["B5"].value, "1"))
    wave = clean_text(ws["B6"].value).upper() or "AM"
    override_url = clean_text(ws["B7"].value)
    leaderboard_url = clean_text(ws["B8"].value)

    return season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url



def tournament_name_without_year(tournament_name, season):
    """
    Weekend PDF parsers sometimes return "2026 TOURNAMENT NAME" while
    R1/R2 returns only "TOURNAMENT NAME". Normalize once so folders/files
    are always season + tournament exactly one time.
    """
    name = clean_text(tournament_name)
    season_text = clean_text(season)

    if season_text and name.upper().startswith(f"{season_text} "):
        return name[len(season_text):].strip()

    return name


def year_tournament_display_name(tournament_name, season):
    clean_name = tournament_name_without_year(tournament_name, season)
    season_text = clean_text(season)
    return f"{season_text} {clean_name}".strip()


def year_tournament_safe_name(tournament_name, season):
    clean_name = tournament_name_without_year(tournament_name, season)
    season_text = clean_text(season)
    return f"{season_text}_{safe_filename(clean_name)}".strip("_")



def round_label(round_num):
    round_num = int(round_num)

    if round_num == 1:
        return "OPENING_ROUND"
    if round_num == 2:
        return "2ND_ROUND"
    if round_num == 3:
        return "3RD_ROUND"
    if round_num == 4:
        return "FINAL_ROUND"

    return f"ROUND_{round_num}"


def subtitle_label(round_num, wave):
    round_num = int(round_num)
    wave = clean_text(wave).upper()

    if round_num == 1:
        base = "OPENING ROUND"
    elif round_num == 2:
        base = "2ND ROUND"
    elif round_num == 3:
        base = "3RD ROUND"
    elif round_num == 4:
        base = "FINAL ROUND"
    else:
        base = f"ROUND {round_num}"

    if round_num in [1, 2] and wave in ["AM", "PM"]:
        return f"{base} ({'MORNING' if wave == 'AM' else 'AFTERNOON'})"

    return base


def display_player_name(name):
    """
    Defensive display cleanup for player names.

    Some weekend PDF rows are:
      Name Hometown, ST Score R1 R2 Total

    If a hometown fragment leaks into the name, it usually brings a comma.
    Example:
      COLLIN MORIKAWA LA CANADA,
    should display as:
      COLLIN MORIKAWA

    This intentionally does not alter known suffix names like:
      TOM PERNICE, JR.
      WES SHORT, JR.
    """
    text = clean_text(name)

    if not text:
        return ""

    upper = text.upper()

    suffixes = [
        ", JR.",
        ", SR.",
        ", II",
        ", III",
        " JR.",
        " SR.",
        " II",
        " III",
    ]

    if "," in text and not any(upper.endswith(s) for s in suffixes):
        before_comma = text.split(",", 1)[0].strip()
        words = before_comma.split()

        # If a hometown leaked in, names usually become 4+ words before comma.
        # Keep first two words by default, but preserve common 3-word player-name particles.
        if len(words) >= 4:
            particles = {"VAN", "VON", "DE", "DEL", "DA", "DI", "MC", "MAC"}
            if len(words) >= 3 and words[1].upper() in particles:
                return " ".join(words[:3])
            return " ".join(words[:2])

        return before_comma

    return text


def score_text(score):
    score = clean_text(score)

    if not score:
        return ""

    up = score.upper().replace("–", "-").replace("—", "-")

    if up in {"E", "WD", "W-D", "W/D", "WITHDREW", "WITHDRAWN", "CUT", "DQ", "ERROR"}:
        return "WD" if up in {"W-D", "W/D", "WITHDREW", "WITHDRAWN"} else up

    if re.fullmatch(r"[+-]\d+", score):
        return score

    if re.fullmatch(r"\d+", score):
        n = int(score)
        return f"+{n}" if n > 0 else "E"

    return score


def is_pure_twosome(rows):
    return bool(rows) and all(not clean_text(r[8]) for r in rows)


def side_split(rows):
    """
    Split into left/right columns with extra group on right.
    """
    left_count = len(rows) // 2
    return rows[:left_count], rows[left_count:]


def tee_split_for_two_sides(rows, round_num):
    tee1 = [r for r in rows if str(r[2]) == "1"]
    tee10 = [r for r in rows if str(r[2]) == "10"]

    if tee1 and tee10:
        # Requested convention:
        # left side = 10 Tee, right side = 1 Tee.
        return tee10, tee1, "10 TEE", "1 TEE"

    # One-tee field: use both columns.
    left, right = side_split(rows)
    header = "1 TEE" if (tee1 or not tee10) else "10 TEE"
    return left, right, header, header


def set_page_setup(ws, max_row):
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(
        left=0.15,
        right=0.15,
        top=0.20,
        bottom=0.20,
        header=0.10,
        footer=0.10,
    )
    ws.print_area = f"A1:J{max_row}"
    ws.print_options.horizontalCentered = True


def apply_base_layout(ws):
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100

    widths = {
        "A": 8,
        "B": 4,
        "C": 25,
        "D": 6,
        "E": 3,
        "F": 8,
        "G": 4,
        "H": 25,
        "I": 6,
        "J": 3,
    }

    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    # Default body rows: Excel height 12.50 ≈ 25 pixels.
    for row in range(1, 201):
        ws.row_dimensions[row].height = 12.50



def set_title(ws, season, tournament_name, round_num, wave):
    title = year_tournament_display_name(tournament_name, season).upper()

    sub = subtitle_label(round_num, wave)

    ws.merge_cells("A1:J1")
    ws.merge_cells("A2:J2")
    ws["A1"] = title
    ws["A2"] = sub

    ws["A1"].font = Font(name="Arial", size=16, bold=True)
    ws["A2"].font = Font(name="Arial", size=10, bold=True, italic=True, underline="single")

    ws["A1"].alignment = Alignment(horizontal="center", vertical="bottom")
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")

    # Tuned to visually match target pixel heights:
    # Row 1 ≈ 105 px, Row 2 ≈ 53 px, Row 3 ≈ 10 px.
    ws.row_dimensions[1].height = 52.5
    ws.row_dimensions[2].height = 26.5
    ws.row_dimensions[3].height = 5


def write_headers(ws, left_header, right_header):
    ws["C4"] = left_header
    ws["H4"] = right_header

    for cell in ["C4", "H4"]:
        ws[cell].font = Font(name="Arial", size=9, bold=True)
        ws[cell].alignment = Alignment(horizontal="center")

    # Match COM layout: medium border above and below tee-header band.
    add_top_border(ws, 3, 1, 5)
    add_top_border(ws, 3, 6, 10)
    add_bottom_border(ws, 5, 1, 5)
    add_bottom_border(ws, 5, 6, 10)


def style_written_cell(cell, bold=True, italic=False, underline=False):
    cell.font = Font(name="Arial", size=9, bold=bold, italic=italic, underline="single" if underline else None)
    cell.alignment = Alignment(horizontal="left", vertical="center", shrink_to_fit=True)


def medium_side():
    return Side(style="medium", color="000000")


def add_top_border(ws, row_num, c1, c2):
    side = medium_side()
    for col in range(c1, c2 + 1):
        cell = ws.cell(row_num, col)
        cell.border = Border(
            top=side,
            left=cell.border.left,
            right=cell.border.right,
            bottom=cell.border.bottom,
        )


def add_bottom_border(ws, row_num, c1, c2):
    side = medium_side()
    for col in range(c1, c2 + 1):
        cell = ws.cell(row_num, col)
        cell.border = Border(
            bottom=side,
            left=cell.border.left,
            right=cell.border.right,
            top=cell.border.top,
        )


def add_center_divider(ws, start_row, end_row):
    side = medium_side()
    for row in range(start_row, end_row + 1):
        cell = ws.cell(row, 6)
        cell.border = Border(
            left=side,
            right=cell.border.right,
            top=cell.border.top,
            bottom=cell.border.bottom,
        )


def write_cell(ws, row, col, value, bold=True, italic=False, underline=False, align="left", indent=0):
    cell = ws.cell(row, col)
    cell.value = value
    style_written_cell(cell, bold=bold, italic=italic, underline=underline)
    cell.alignment = Alignment(
        horizontal=align,
        vertical="center",
        shrink_to_fit=True,
        indent=indent
    )
    return cell


def write_standard_side(ws, rows, start_row, side, block_rows=4):
    if side == "left":
        time_col, group_col, name_col, score_col = 1, 1, 3, 4
        c1, c2 = 1, 5
    else:
        time_col, group_col, name_col, score_col = 6, 6, 8, 9
        c1, c2 = 6, 10

    row_num = start_row

    for r in rows:
        tee_time = clean_text(r[3])
        group_num = clean_text(r[1])
        p1, s1 = display_player_name(r[4]), score_text(r[5])
        p2, s2 = display_player_name(r[6]), score_text(r[7])
        p3, s3 = display_player_name(r[8]), score_text(r[9])

        for rr in range(row_num, row_num + block_rows):
            ws.row_dimensions[rr].height = 12.50

        add_top_border(ws, row_num, c1, c2)

        # Row 1: tee time + player 1 + score
        write_cell(ws, row_num, time_col, tee_time, bold=True, underline=True, indent=2)
        write_cell(ws, row_num, name_col, p1, bold=True)
        if s1:
            write_cell(ws, row_num, score_col, s1, bold=True, align="right")

        # Row 2: player 2
        if p2:
            write_cell(ws, row_num + 1, name_col, p2, bold=True)
        if s2:
            write_cell(ws, row_num + 1, score_col, s2, bold=True, align="right")

        # Row 3: group + player 3 if present
        write_cell(ws, row_num + 2, group_col, group_num, bold=True, italic=True, indent=2)
        if p3:
            write_cell(ws, row_num + 2, name_col, p3, bold=True)
        if s3:
            write_cell(ws, row_num + 2, score_col, s3, bold=True, align="right")

        # Row 4: blank spacer with bottom border
        add_bottom_border(ws, row_num + 3, c1, c2)

        row_num += block_rows

    return row_num


def write_twosome_side(ws, rows, start_row, side):
    if side == "left":
        time_col, group_col, name_col, score_col = 1, 1, 3, 4
        c1, c2 = 1, 5
    else:
        time_col, group_col, name_col, score_col = 6, 6, 8, 9
        c1, c2 = 6, 10

    row_num = start_row

    for r in rows:
        tee_time = clean_text(r[3])
        group_num = clean_text(r[1])
        p1, s1 = display_player_name(r[4]), score_text(r[5])
        p2, s2 = display_player_name(r[6]), score_text(r[7])

        ws.row_dimensions[row_num].height = 12.50
        ws.row_dimensions[row_num + 1].height = 12.50
        ws.row_dimensions[row_num + 2].height = 12.50
        ws.row_dimensions[row_num + 3].height = 6.5

        add_top_border(ws, row_num, c1, c2)

        # Row 1: time
        write_cell(ws, row_num, time_col, tee_time, bold=True, underline=True, indent=2)

        # Row 2: player 1
        write_cell(ws, row_num + 1, name_col, p1, bold=True)
        if s1:
            write_cell(ws, row_num + 1, score_col, s1, bold=True, align="right")

        # Row 3: group/player 2
        write_cell(ws, row_num + 2, group_col, group_num, bold=True, italic=True, indent=2)
        if p2:
            write_cell(ws, row_num + 2, name_col, p2, bold=True)
        if s2:
            write_cell(ws, row_num + 2, score_col, s2, bold=True, align="right")

        add_bottom_border(ws, row_num + 3, c1, c2)

        row_num += 4

    return row_num


def build_openpyxl_workbook(rows, season, tournament_name, round_num, wave):
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    apply_base_layout(ws)
    set_title(ws, season, tournament_name, round_num, wave)

    left_rows, right_rows, left_header, right_header = tee_split_for_two_sides(rows, round_num)
    write_headers(ws, left_header, right_header)

    start_row = 6

    if is_pure_twosome(rows) and clean_text(wave).upper() in {"ALL", "FULL", "BOTH"}:
        left_end = write_twosome_side(ws, left_rows, start_row, "left")
        right_end = write_twosome_side(ws, right_rows, start_row, "right")
    else:
        left_end = write_standard_side(ws, left_rows, start_row, "left")
        right_end = write_standard_side(ws, right_rows, start_row, "right")

    final_row = max(left_end, right_end)

    add_center_divider(ws, 3, final_row - 1)

    set_page_setup(ws, final_row + 1)

    return wb



def read_settings_from_args(args):
    season = clean_excel_int(args.season, str(datetime.now().year))
    tour_folder = clean_text(args.tour) or "pgatour"
    tournament_slug = clean_text(args.tournament)
    round_num = int(clean_excel_int(args.round, "1"))
    wave = clean_text(args.wave).upper() or "AM"
    override_url = clean_text(args.pdf_override)
    leaderboard_url = clean_text(args.espn_override)

    if not tournament_slug:
        raise RuntimeError("Tournament slug is required.")

    return season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url


def build_arg_parser():
    parser = argparse.ArgumentParser(description="PGA Tee Time Builder OpenPyXL exporter")
    parser.add_argument("--season", required=True)
    parser.add_argument("--tour", default="pgatour")
    parser.add_argument("--tournament", required=True)
    parser.add_argument("--round", required=True)
    parser.add_argument("--wave", required=True)
    parser.add_argument("--pdf-override", default="")
    parser.add_argument("--espn-override", default="")
    parser.add_argument("--output-root", default="")
    return parser



def main(argv=None):
    args = build_arg_parser().parse_args(argv)

    parser = load_parser(PARSER_SCRIPT)

    season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url = read_settings_from_args(args)

    rows, tournament_name = parser.build_rows_from_pdf(
        season,
        tour_folder,
        tournament_slug,
        round_num,
        wave,
        override_url,
        leaderboard_url
    )

    print(f"Parsed {len(rows)} tee-time groups.")

    wb = build_openpyxl_workbook(
        rows,
        season,
        tournament_name,
        round_num,
        wave
    )

    output_root = clean_text(getattr(args, "output_root", "")) or FINISHED_FOLDER
    tournament_folder_name = year_tournament_safe_name(tournament_name, season)
    tournament_folder = os.path.join(
        output_root,
        tournament_folder_name
    )
    os.makedirs(tournament_folder, exist_ok=True)

    output_filename = (
        f"{year_tournament_safe_name(tournament_name, season)}_"
        f"{round_label(round_num)}_"
        f"{clean_text(wave).upper()}.xlsx"
    )

    output_path = os.path.join(tournament_folder, output_filename)

    if os.path.exists(output_path):
        os.remove(output_path)

    wb.save(output_path)

    print(f"Saved openpyxl direct-export workbook to: {output_path}")

    try:
        print(f"Opening: {output_path}")
        if sys.platform.startswith("win"):
            os.startfile(output_path)
        elif sys.platform == "darwin":
            import subprocess
            subprocess.Popen(["open", output_path])
        else:
            import subprocess
            subprocess.Popen(["xdg-open", output_path])
    except Exception as exc:
        print(f"Could not auto-open workbook: {exc}")

    print("Done.")


if __name__ == "__main__":
    main()
