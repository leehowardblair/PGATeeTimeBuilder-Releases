import os
import re
import sys
import tempfile
import time
import subprocess
import json
import subprocess
import json
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

import requests
import pdfplumber


# Folder structure
BASE_FOLDER = r"C:\PGATeeTimeData"
SCRIPTS_FOLDER = os.path.join(BASE_FOLDER, "Scripts")
DATA_FOLDER = os.path.join(SCRIPTS_FOLDER, "Data")
FINISHED_FOLDER = os.path.join(BASE_FOLDER, "Finished Tee Sheets")
SETUP_WORKBOOK = os.path.join(BASE_FOLDER, "PGA_Pairings_PGATourMedia_SETUP.xlsm")


def ensure_project_folders():
    os.makedirs(BASE_FOLDER, exist_ok=True)
    os.makedirs(SCRIPTS_FOLDER, exist_ok=True)
    os.makedirs(DATA_FOLDER, exist_ok=True)
    os.makedirs(FINISHED_FOLDER, exist_ok=True)


def com_retry(action, description="Excel action", attempts=20, delay=0.35):
    """
    Excel can reject COM calls when it is busy recalculating, opening a workbook,
    or handling a macro-enabled workbook state.

    Error commonly looks like:
      pywintypes.com_error: (-2147418111, 'Call was rejected by callee.')

    Retry those calls instead of failing immediately.
    """
    last_exc = None

    for attempt in range(1, attempts + 1):
        try:
            return action()
        except Exception as exc:
            last_exc = exc
            msg = str(exc)

            if (
                "Call was rejected by callee" in msg
                or "-2147418111" in msg
                or "RPC_E_CALL_REJECTED" in msg
            ):
                time.sleep(delay)
                continue

            raise

    raise RuntimeError(
        f"{description} failed after {attempts} attempts: {last_exc}"
    )


def excel_wait_ready(excel, seconds=0.5):
    try:
        time.sleep(seconds)
        com_retry(lambda: excel.CalculateUntilAsyncQueriesDone(), "Wait for Excel async queries", attempts=5)
    except Exception:
        time.sleep(seconds)


TIME_PAIR_RE = re.compile(
    r"^(\d{1,2}:\d{2}\s*[AP]M)\s+"
    r"(\d{1,2}:\d{2}\s*[AP]M)\s+(.+)$",
    re.I,
)

SINGLE_TIME_RE = re.compile(
    r"^(\d{1,2}:\d{2}\s*[AP]M)\s+(.+)$",
    re.I,
)

TIME_ONLY_RE = re.compile(
    r"^(\d{1,2}:\d{2}\s*[AP]M)$",
    re.I,
)

# Round 3 / Final row format:
#   7:36 AM Lanto Griffin Jacksonville Beach, FL -2 71 67 138
#   Pierceson Coody Plano, TX -2 71 67 138
WEEKEND_SCORED_ROW_RE = re.compile(
    r"^(?:(\d{1,2}:\d{2}\s*[AP]M)\s+)?"
    r"(.+?)\s+([+-]?\d+|E)\s+(?:\d{2}\s+){2,3}\d{3}\s*$",
    re.I,
)


def clean_text(value):
    return " ".join(str(value or "").replace("\xa0", " ").split())


def clean_excel_int(value, default):
    """
    Excel COM often returns whole-number cells as floats, like 2026.0.
    PGA Tour Media URLs need 2026, not 2026.0.
    """
    if value is None or str(value).strip() == "":
        return str(default)

    try:
        return str(int(float(value)))
    except Exception:
        return clean_text(value)


def smart_player_caps(name):
    name = clean_text(name).upper()
    name = re.sub(r"\bMC([A-Z])", r"Mc\1", name)
    name = re.sub(r"\bMAC([A-Z])", r"Mac\1", name)
    return name


COMMON_MULTIWORD_NAME_PARTS = {
    "VAN",
    "VANDE",
    "VANDER",
    "VON",
    "DE",
    "DEL",
    "DELA",
    "DA",
    "DOS",
    "DU",
    "LE",
    "LA",
    "DI",
    "ST",
    "ST.",
}

COMMON_NAME_SUFFIXES = {
    "JR",
    "JR.",
    "II",
    "III",
    "IV",
    "V",
}


def is_name_particle(word):
    return clean_text(word).upper().replace(".", "") in {
        p.replace(".", "")
        for p in COMMON_MULTIWORD_NAME_PARTS
    }


def is_name_suffix(word):
    cleaned = clean_text(word).upper().replace(",", "").replace(".", "")
    return cleaned in {
        suffix.replace(".", "")
        for suffix in COMMON_NAME_SUFFIXES
    }


def split_player_line_into_three(player_line):
    """
    PGA PDF text extraction often collapses the three player columns into one line.
    A simple split by every space breaks names like Erik van Rooyen.

    This splitter:
    1. Uses real multi-space gaps if pdfplumber preserved them.
    2. Otherwise builds three player names while keeping known particles
       like van/de/du with the surname.
    3. Falls back to an even split only if needed.
    """
    player_line = clean_text(player_line)

    parts = [
        clean_text(p)
        for p in re.split(r"\s{2,}", player_line)
        if clean_text(p)
    ]

    if len(parts) >= 3:
        return parts[:3]

    words = player_line.split()

    if len(words) < 3:
        return [player_line, "", ""]

    def consume_name(start_idx):
        if start_idx >= len(words):
            return "", start_idx

        name_words = [words[start_idx]]
        idx = start_idx + 1

        # Keep initials/short first-name parts if present.
        while idx < len(words) and re.fullmatch(r"[A-Z]\.?", words[idx]):
            name_words.append(words[idx])
            idx += 1

        # Normal case: first name + last name.
        # Special case: first name + particle + last name, e.g.
        # Erik van Rooyen, Adrien Dumont de Chassart.
        if idx < len(words):
            if is_name_particle(words[idx]):
                while idx < len(words) and is_name_particle(words[idx]):
                    name_words.append(words[idx])
                    idx += 1

                    if idx < len(words):
                        name_words.append(words[idx])
                        idx += 1
            else:
                name_words.append(words[idx])
                idx += 1

                # Handle surname particles after a normal surname too,
                # e.g. Dumont de Chassart.
                while idx < len(words) and is_name_particle(words[idx]):
                    name_words.append(words[idx])
                    idx += 1

                    if idx < len(words):
                        name_words.append(words[idx])
                        idx += 1

        # Attach suffixes like Jr., II, III.
        while idx < len(words) and is_name_suffix(words[idx]):
            name_words.append(words[idx])
            idx += 1

        return " ".join(name_words), idx

    players = []
    idx = 0

    for _ in range(3):
        name, idx = consume_name(idx)
        players.append(name)

    # If anything is left over, append it to the final player name.
    if idx < len(words):
        players[-1] = clean_text(players[-1] + " " + " ".join(words[idx:]))

    non_blank_players = [clean_text(p) for p in players if clean_text(p)]

    # Keep twosomes as twosomes. Do not force a fake third player.
    if len(non_blank_players) >= 2:
        return non_blank_players[:3]

    third = max(1, len(words) // 3)

    return [
        " ".join(words[:third]),
        " ".join(words[third:third * 2]),
        " ".join(words[third * 2:])
    ]



KNOWN_MULTIWORD_PLAYERS = [
    "Tommy Armour III",
    "Notah Begay III",
    "Miguel Angel Jiménez",
    "Frank Lickliter II",
    "José María Olazábal",
    "Tom Pernice, Jr.",
    "Wes Short, Jr.",
    "Tom Pernice Jr.",
    "Wes Short Jr.",
    "Frankie Capan III",
    "Adrien Dumont de Chassart",
    "Erik van Rooyen",
    "Rasmus Neergaard-Petersen",
    "Min Woo Lee",
    "Si Woo Kim",
]


def repair_known_multiword_players(players):
    """
    Safety pass for known names that can be split incorrectly by PDF text extraction.
    """
    joined = " ".join([clean_text(p) for p in players if clean_text(p)])
    joined_key = normalize_player_name(joined) if "normalize_player_name" in globals() else joined.upper()

    repaired = []

    # Work left-to-right against the original joined text when possible.
    remaining = joined

    for known in KNOWN_MULTIWORD_PLAYERS:
        pattern = re.compile(re.escape(known), re.I)

        if pattern.search(remaining):
            remaining = pattern.sub(f"||{known}||", remaining)

    tokens = [t for t in remaining.split("||") if clean_text(t)]

    for token in tokens:
        cleaned = clean_text(token)

        if any(normalize_player_name(cleaned) == normalize_player_name(k) for k in KNOWN_MULTIWORD_PLAYERS):
            repaired.append(cleaned)
        else:
            # Split any remaining regular text back into names.
            sub = split_player_line_into_three(cleaned) if len(cleaned.split()) > 3 else [cleaned]
            repaired.extend([x for x in sub if clean_text(x)])

    if len(repaired) >= 3:
        return repaired[:3]

    return players


def normalize_score_value(score):
    """
    Standardize score display:
    - Missing score = Error
    - 0/E/e = E
    - Positive numeric scores get a leading plus sign
    - Negative scores keep their minus sign
    """
    score = clean_text(score)

    if not score:
        return "Error"

    score = score.upper()

    if score in {"WD", "W/D", "WITHDRAWN", "WITHDREW"}:
        return "WD"

    if score in {"E", "EVEN", "0", "+0", "-0"}:
        return "E"

    if re.fullmatch(r"-\d+", score):
        return score

    if re.fullmatch(r"\+\d+", score):
        return score

    if re.fullmatch(r"\d+", score):
        return f"+{score}"

    return score




def extract_pdf_score_from_info_line(line):
    """
    Weekend PGA PDFs usually put score on the hometown line, e.g.
      Jacksonville Beach, FL -2 71 67 138
      Plano, TX E 69 69 138
      Somewhere, TX 2 71 71 142

    We want the tournament score token before the round scores / total.
    """
    line = clean_text(line)

    # Score + two or three round scores + total at the end of the line.
    m = re.search(
        r"(?<![A-Z0-9])([+-]?\d+|E)\s+(?:\d{2}\s+){2,3}\d{3}\s*$",
        line,
        re.I,
    )

    if m:
        return normalize_score_value(m.group(1))

    # Fallback: use first signed score token.
    m = re.search(r"(?<![A-Z0-9])([+-]\d+|E)(?![A-Z0-9])", line, re.I)

    if m:
        return normalize_score_value(m.group(1))

    return ""


def looks_like_score_info_line(line):
    return bool(extract_pdf_score_from_info_line(line))


def looks_like_player_name_line(line):
    line = clean_text(line)

    if not line:
        return False

    upper = line.upper()

    if any(bad in upper for bad in [
        "APPROX",
        "FINISH",
        "TEE TIMES",
        "ALTERNATES",
        "ROUND",
        "GROUPINGS",
        "STARTING",
        "COLONIAL COUNTRY CLUB",
    ]):
        return False

    if TIME_ONLY_RE.match(line) or SINGLE_TIME_RE.match(line):
        return False

    if re.fullmatch(r"(TEE\s*#?\s*\d+|\d+\s+TEE|\d+(ST|ND|RD|TH)\s+TEE|NO\.\s*\d+\s+TEE)", upper):
        return False

    if looks_like_score_info_line(line):
        return False

    key_parts = normalize_player_name(line).split()

    return len(key_parts) >= 2


def parse_weekend_time_block(lines, start_index):
    """
    Parse weekend layout:
      7:36 AM
      Lanto Griffin
      Jacksonville Beach, FL -2 71 67 138
      Pierceson Coody
      Plano, TX -2 70 68 138
      Jackson Suber
      Tampa, FL -2 70 68 138

    Returns:
      tee_time, players, scores, next_index
    """
    time_line = lines[start_index]
    m = TIME_ONLY_RE.match(time_line)

    if not m:
        return None, [], [], start_index + 1

    tee_time = m.group(1)
    players = []
    scores = []

    j = start_index + 1

    while j < len(lines) and len(players) < 3:
        line = lines[j]
        upper = line.upper()

        if TIME_ONLY_RE.match(line) or SINGLE_TIME_RE.match(line):
            break

        if re.fullmatch(r"(TEE\s*#?\s*1|1\s+TEE|1ST\s+TEE|NO\.\s*1\s+TEE)", upper):
            break

        if re.fullmatch(r"(TEE\s*#?\s*10|10\s+TEE|10TH\s+TEE|NO\.\s*10\s+TEE)", upper):
            break

        if not looks_like_player_name_line(line):
            j += 1
            continue

        player_name = line
        score_value = ""

        # Next line is usually hometown + score.
        if j + 1 < len(lines):
            possible_info = lines[j + 1]

            if looks_like_score_info_line(possible_info):
                score_value = extract_pdf_score_from_info_line(possible_info)
                j += 1

        players.append(player_name)
        scores.append(score_value or "Error")

        j += 1

    return tee_time, players, scores, j

def safe_filename(text):
    text = clean_text(text).upper()
    text = re.sub(r"[^A-Z0-9]+", "_", text)
    return text.strip("_")


def group_map_path(season, tournament_name):
    """
    Year-specific cache file for carrying Round 1 group numbers into Round 2.
    Example:
      C:\\PGATeeTimeData\\Scripts\\Data\\2026_CHARLES_SCHWAB_CHALLENGE_GROUPMAP.json
    """
    safe_tournament = safe_filename(tournament_name)
    safe_season = clean_excel_int(season, "2026")

    return os.path.join(
        DATA_FOLDER,
        f"{safe_season}_{safe_tournament}_GROUPMAP.json"
    )


def save_round1_group_map(season, tournament_name, rows):
    """
    Save player -> Round 1 group number.
    rows columns:
      1 Group, 4 Player1, 6 Player2, 8 Player3
    """
    groups = {}

    for row in rows:
        try:
            group_num = row[1]
            players = [row[4], row[6], row[8]]
        except Exception:
            continue

        for player in players:
            player_key = normalize_player_name(player)

            if player_key:
                groups[player_key] = group_num

    path = group_map_path(season, tournament_name)

    payload = {
        "Tournament": tournament_name.upper(),
        "Season": clean_excel_int(season, "2026"),
        "Groups": groups,
    }

    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    print(f"Saved Round 1 group map: {path}")


def load_round1_group_map(season, tournament_name):
    path = group_map_path(season, tournament_name)

    if not os.path.exists(path):
        print(f"WARNING: Round 1 group map not found: {path}")
        return {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        groups = payload.get("Groups", {})

        print(f"Loaded Round 1 group map: {path}")

        return groups

    except Exception as exc:
        print(f"WARNING: Could not load Round 1 group map: {exc}")
        return {}


def build_player_group_map_from_groups(groups):
    """
    Build player -> group number map from the complete parsed R1/R2 tee sheet.

    Group order:
      AM wave first, PM wave second.
      Within each wave: 1 Tee groups first, then 10 Tee groups.

    This matches the actual PGA group numbering:
      Round 1 AM = 1..N
      Round 1 PM = N+1...
      Round 2 carries same group numbers from Round 1.
    """
    if not groups:
        return {}

    def group_wave(group):
        return tee_time_wave_value(group.get("tee_time_display", ""))

    am_groups = [g for g in groups if group_wave(g) != "PM"]
    pm_groups = [g for g in groups if group_wave(g) == "PM"]

    def ordered_wave(wave_groups):
        tee1 = [g for g in wave_groups if int(g.get("tee", 0)) == 1]
        tee10 = [g for g in wave_groups if int(g.get("tee", 0)) == 10]
        other = [g for g in wave_groups if int(g.get("tee", 0)) not in [1, 10]]
        return tee1 + tee10 + other

    ordered = ordered_wave(am_groups) + ordered_wave(pm_groups)

    player_map = {}

    for idx, group in enumerate(ordered, start=1):
        for player in group.get("players", []):
            key = normalize_player_name(player)
            if key:
                player_map[key] = idx

    print(
        f"Built source-of-truth player group map: "
        f"{len(am_groups)} AM groups, {len(pm_groups)} PM groups, {len(ordered)} total."
    )

    return player_map


def tee_time_wave_value(tee_time):
    """
    Return AM/PM from a raw tee time string.
    If AM/PM is missing, infer from hour:
      6-11 => AM
      12-7-ish => PM
    """
    text = clean_text(tee_time).upper()

    if "AM" in text:
        return "AM"

    if "PM" in text:
        return "PM"

    m = re.search(r"\b(\d{1,2}):(\d{2})\b", text)

    if not m:
        return ""

    hour = int(m.group(1))

    # Golf tee sheets usually have morning times in 6-11 range,
    # afternoon wave in 12-7 range.
    if 6 <= hour <= 11:
        return "AM"

    return "PM"


def build_round1_full_day_group_map(groups):
    """
    Build player -> group number for Round 1.

    Rule:
      AM wave groups are numbered first.
      PM wave groups continue after AM.
      Within each wave, 1 Tee groups are first, then 10 Tee groups.

    This fixes PM wave group numbers restarting at 1.
    """
    am_groups = []
    pm_groups = []

    for group in groups:
        wave = tee_time_wave_value(group.get("tee_time_display", ""))

        if wave == "PM":
            pm_groups.append(group)
        else:
            am_groups.append(group)

    def order_within_wave(wave_groups):
        tee1 = [g for g in wave_groups if int(g.get("tee", 0)) == 1]
        tee10 = [g for g in wave_groups if int(g.get("tee", 0)) == 10]
        other = [g for g in wave_groups if int(g.get("tee", 0)) not in [1, 10]]
        return tee1 + tee10 + other

    full_order = order_within_wave(am_groups) + order_within_wave(pm_groups)

    player_map = {}

    for idx, group in enumerate(full_order, start=1):
        for player in group.get("players", []):
            key = normalize_player_name(player)

            if key:
                player_map[key] = idx

    print(
        f"Built Round 1 full-day group map: "
        f"{len(am_groups)} AM groups, {len(pm_groups)} PM groups, "
        f"{len(full_order)} total groups."
    )

    return player_map


def lookup_group_number_from_player_map(players, player_group_map):
    """
    Find a group's number by checking any player in that group against
    the full-field Round 1 player->group map.
    """
    if not player_group_map:
        return None

    for player in players:
        key = normalize_player_name(player)

        if key and key in player_group_map:
            return player_group_map[key]

    return None


def lookup_round1_group_number(players, group_map):
    for player in players:
        player_key = normalize_player_name(player)

        if player_key and player_key in group_map:
            return group_map[player_key]

    return None


def save_round1_group_map_from_all_groups(season, tournament_name, all_groups):
    """
    Round 1 group map must include the entire field, not just the selected AM/PM wave.

    IMPORTANT:
    Do NOT sort by tee time here.

    PGA group numbers follow the actual PDF block order:
      1) Rd. 1 - 1 Tee block
      2) Rd. 1 - 10 Tee block
      3) next page/afternoon Rd. 1 - 1 Tee block
      4) next page/afternoon Rd. 1 - 10 Tee block

    Example:
      Nick Hardy = Group 1
      Mathieu Pavon = Group 34

    The parser already reads all_groups in that PDF block order, so we preserve it.
    """
    ordered = list(all_groups)

    groups = {}
    group_debug = []

    for group_num, group in enumerate(ordered, start=1):
        players = list(group.get("players", []))

        group_debug.append({
            "Group": group_num,
            "Tee": group.get("tee"),
            "Time": group.get("tee_time_display"),
            "Players": players,
        })

        for player in players:
            player_key = normalize_player_name(player)

            if player_key:
                groups[player_key] = group_num

    path = group_map_path(season, tournament_name)

    payload = {
        "Tournament": tournament_name.upper(),
        "Season": clean_excel_int(season, "2026"),
        "GroupCount": len(ordered),
        "Groups": groups,
        "GroupDebug": group_debug,
    }

    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    print(
        f"Saved full-field Round 1 group map: {path} "
        f"({len(ordered)} groups, {len(groups)} players)"
    )



def normalize_player_name(value):
    """
    Normalized key for matching tee-time player names to leaderboard names.
    Handles accents, punctuation, amateur marks, and extra spacing.
    """
    import unicodedata

    value = clean_text(value)
    value = value.replace("(a)", "").replace("(A)", "")
    value = value.replace("-a", "").replace("-A", "")

    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = value.upper()
    value = re.sub(r"[^A-Z0-9]+", " ", value)

    return " ".join(value.split())


def ensure_bs4():
    try:
        from bs4 import BeautifulSoup
        return BeautifulSoup
    except ImportError:
        print("beautifulsoup4 is missing. Attempting to install it now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
        from bs4 import BeautifulSoup
        return BeautifulSoup


def score_token_from_text(text):
    """
    ESPN rows usually read like:
      Ryan Gerard -6 -6 F 64 ...
      Séamus Power E E 17 ...
      Zac Blair +1 +1 F 71 ...
    We want the first SCORE token after the player name.
    """
    text = clean_text(text)

    m = re.search(r"(?<![A-Z0-9])([+-]\d+|E)(?=\s|[+-]|$)", text, re.I)

    if not m:
        return None

    score = m.group(1).upper()

    return normalize_score_value(score)


def extract_espn_score_for_player(player_name, leaderboard_lines):
    target = normalize_player_name(player_name)

    if not target:
        return None

    for line in leaderboard_lines:
        normalized_line = normalize_player_name(line)

        if target not in normalized_line:
            continue

        # Work from the normalized player-name location so we avoid position
        # values like T1 before the name.
        pos = normalized_line.find(target)
        rest_normalized = normalized_line[pos + len(target):]
        score = score_token_from_text(rest_normalized)

        if score:
            return score

        # Fallback: try the raw line after the visible player name.
        score = score_token_from_text(line)

        if score:
            return score

    return None




def slugify_for_match(value):
    value = normalize_player_name(value)
    return re.sub(r"[^A-Z0-9]+", "", value)


def known_espn_tournament_url(tournament_name, season):
    """
    Known ESPN leaderboard IDs for cases where auto-discovery fails.
    """
    key = normalize_player_name(tournament_name)
    season_text = str(clean_excel_int(season, ""))

    known = {
        ("2026", "THE MEMORIAL TOURNAMENT PRESENTED BY WORKDAY"): "https://www.espn.com/golf/leaderboard/_/tournamentId/401811950",
        ("2026", "THE MEMORIAL TOURNAMENT PRES BY WORKDAY"): "https://www.espn.com/golf/leaderboard/_/tournamentId/401811950",
        ("2026", "THE MEMORIAL TOURNAMENT"): "https://www.espn.com/golf/leaderboard/_/tournamentId/401811950",
        ("2026", "MEMORIAL TOURNAMENT"): "https://www.espn.com/golf/leaderboard/_/tournamentId/401811950",
        ("2026", "MEMORIAL"): "https://www.espn.com/golf/leaderboard/_/tournamentId/401811950",
    }

    for (known_season, known_name), url in known.items():
        if season_text == known_season and known_name in key:
            print(f"Using known ESPN leaderboard fallback: {url}")
            return url

    return ""


def discover_espn_leaderboard_url(tournament_name, season):
    """
    Try to find the ESPN leaderboard URL automatically from the tournament name.
    B15 can still be used as a manual override, but normally this should remove
    the need to paste an ESPN URL.
    """
    known_url = known_espn_tournament_url(tournament_name, season)
    if known_url:
        return known_url

    tournament_key = slugify_for_match(tournament_name)

    if not tournament_key:
        return ""

    candidates = [
        f"https://www.espn.com/golf/leaderboard/_/year/{season}",
        "https://www.espn.com/golf/leaderboard/_/tour/pga",
        "https://www.espn.com/golf/leaderboard",
    ]

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    for page_url in candidates:
        try:
            response = requests.get(
                page_url,
                timeout=30,
                headers=headers
            )
            response.raise_for_status()
        except Exception:
            continue

        html = response.text

        # Look for ESPN golf leaderboard links that include tournamentId.
        # Then check nearby page text for the tournament name.
        for m in re.finditer(
            r'(/golf/leaderboard/_/tournamentId/(\d+))',
            html,
            re.I
        ):
            start = max(0, m.start() - 200)
            end = min(len(html), m.end() + 200)
            nearby = html[start:end]

            nearby_key = slugify_for_match(re.sub(r"<[^>]+>", " ", nearby))

            if tournament_key in nearby_key:
                url = "https://www.espn.com" + m.group(1)
                print(f"Auto-discovered ESPN leaderboard: {url}")
                return url

        # Some ESPN pages use escaped slashes.
        for m in re.finditer(
            r'(\\/golf\\/leaderboard\\/_\\/tournamentId\\/(\\d+))',
            html,
            re.I
        ):
            raw = m.group(1).replace("\\/", "/")
            start = max(0, m.start() - 200)
            end = min(len(html), m.end() + 200)
            nearby = html[start:end]

            nearby_key = slugify_for_match(re.sub(r"<[^>]+>", " ", nearby))

            if tournament_key in nearby_key:
                url = "https://www.espn.com" + raw
                print(f"Auto-discovered ESPN leaderboard: {url}")
                return url

    # Fallback: ESPN search API sometimes exposes canonical URLs.
    search_urls = [
        (
            "https://site.web.api.espn.com/apis/search/v2"
            f"?query={requests.utils.quote(str(season) + ' ' + tournament_name + ' leaderboard golf')}"
            "&limit=10"
        ),
        (
            "https://site.api.espn.com/apis/site/v2/search"
            f"?query={requests.utils.quote(str(season) + ' ' + tournament_name + ' leaderboard golf')}"
            "&limit=10"
        ),
    ]

    for search_url in search_urls:
        try:
            response = requests.get(
                search_url,
                timeout=30,
                headers=headers
            )
            response.raise_for_status()
        except Exception:
            continue

        text = response.text

        for m in re.finditer(
            r'https?:\\/\\/www\\.espn\\.com\\/golf\\/leaderboard\\/_\\/tournamentId\\/(\\d+)',
            text,
            re.I
        ):
            url = m.group(0).replace("\\/", "/")
            print(f"Auto-discovered ESPN leaderboard: {url}")
            return url

        for m in re.finditer(
            r'https://www\.espn\.com/golf/leaderboard/_/tournamentId/(\d+)',
            text,
            re.I
        ):
            url = m.group(0)
            print(f"Auto-discovered ESPN leaderboard: {url}")
            return url

    known_url = known_espn_tournament_url(tournament_name, season)
    if known_url:
        return known_url

    print("WARNING: Could not auto-discover ESPN leaderboard URL.")
    return ""



def is_valid_leaderboard_url(url):
    url = clean_text(url)

    if not url:
        return False

    if re.fullmatch(r"\d{6,}", url):
        return True

    low = url.lower()

    # Prevent the PGA tee-time PDF preview URL from ever being used as a leaderboard.
    if "pgatourmedia.pgatourhq.com" in low:
        return False

    if low.endswith(".pdf") or "tee%20times.pdf" in low or "tee times.pdf" in low:
        return False

    # For now this score scraper is built around ESPN leaderboard pages.
    if "espn.com/golf/leaderboard" not in low:
        return False

    return True



def extract_score_from_candidate_text(candidate_text, raw_name):
    """
    Pull a tournament score from text located near a player's name.
    ESPN can expose data as HTML text, JSON blobs, or compact table text.
    """
    text = clean_text(candidate_text)

    if not text:
        return None

    name_key = normalize_player_name(raw_name)
    normalized_candidate = normalize_player_name(text)

    idx = normalized_candidate.find(name_key)

    if idx >= 0:
        search_text = normalized_candidate[idx + len(name_key):]
    else:
        search_text = normalized_candidate

    # ESPN can put WD/W-D/W/D/Withdrawn/Withdrew in the same score/status
    # field where +4 / -3 / E normally lives. Treat that as a real score value.
    m = re.search(
        r"(?<![A-Z0-9])([+-]\d+|E|WD|W-D|W/D|WITHDRAWN|WITHDREW)(?![A-Z0-9])",
        search_text,
        re.I
    )

    if not m:
        return None

    score = m.group(1).upper().replace("–", "-").replace("—", "-")

    if score in {"WD", "W-D", "W/D", "WITHDRAWN", "WITHDREW"}:
        return "WD"

    if score == "E":
        return "E"

    return score


def extract_scores_from_json_like_text(html, player_names):
    """
    ESPN often stores leaderboard data in JavaScript/JSON. Scan around each
    player name and find the nearest score token.
    """
    score_map = {}

    for player in player_names:
        key = normalize_player_name(player)

        if not key:
            continue

        search_names = {
            clean_text(player),
            clean_text(player).upper(),
            clean_text(player).title(),
        }

        found_score = None

        for search_name in search_names:
            if not search_name:
                continue

            for match in re.finditer(re.escape(search_name), html, re.I):
                start = max(0, match.start() - 500)
                end = min(len(html), match.end() + 1200)
                chunk = html[start:end]

                chunk = (
                    chunk
                    .replace("\\u002F", "/")
                    .replace("\\/", "/")
                    .replace("&amp;", "&")
                    .replace("\\\"", '"')
                )

                score = extract_score_from_candidate_text(chunk, player)

                if score:
                    found_score = score
                    break

            if found_score:
                break

        if found_score:
            score_map[key] = normalize_espn_score_value(found_score)

    return score_map


def extract_scores_from_html_tables(html, player_names):
    """
    Fallback table/text parser.
    """
    score_map = {}

    try:
        BeautifulSoup = ensure_bs4()
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        return score_map

    rows = soup.find_all(["tr", "li", "div"])

    for player in player_names:
        key = normalize_player_name(player)

        if not key:
            continue

        for row in rows:
            row_text = clean_text(row.get_text(" "))
            row_key = normalize_player_name(row_text)

            if key not in row_key:
                continue

            score = extract_score_from_candidate_text(row_text, player)

            if score:
                score_map[key] = normalize_espn_score_value(score)
                break

    page_text = clean_text(soup.get_text(" "))

    for player in player_names:
        key = normalize_player_name(player)

        if not key or key in score_map:
            continue

        normalized_page = normalize_player_name(page_text)
        pos = normalized_page.find(key)

        if pos < 0:
            continue

        chunk = normalized_page[pos:pos + 250]
        score = extract_score_from_candidate_text(chunk, player)

        if score:
            score_map[key] = normalize_espn_score_value(score)

    return score_map



def similarity_score(a, b):
    a = normalize_player_name(a)
    b = normalize_player_name(b)

    if not a or not b:
        return 0.0

    if a == b:
        return 1.0

    a_parts = a.split()
    b_parts = b.split()

    # Strong match when last name and first initial agree.
    if len(a_parts) >= 2 and len(b_parts) >= 2:
        if a_parts[-1] == b_parts[-1] and a_parts[0][0] == b_parts[0][0]:
            return 0.93

    return SequenceMatcher(None, a, b).ratio()


def extract_leaderboard_name_score_candidates(html):
    """
    Build a candidate list of (normalized/player-like name, score) from ESPN page text.
    This helps catch players where ESPN text does not line up exactly with our tee-time name.
    """
    candidates = []

    try:
        BeautifulSoup = ensure_bs4()
        soup = BeautifulSoup(html, "html.parser")
        raw_lines = [
            clean_text(line)
            for line in soup.get_text("\n").splitlines()
            if clean_text(line)
        ]
    except Exception:
        raw_lines = [
            clean_text(line)
            for line in re.sub(r"<[^>]+>", "\n", html).splitlines()
            if clean_text(line)
        ]

    # Look for line patterns like:
    # T12  Max Homa  -3 ...
    # Max Homa -3 ...
    for line in raw_lines:
        if not re.search(r"([+-]\d+| E )(?:\s|$)", f" {line} ", re.I):
            continue

        score = score_token_from_text(line)

        if not score:
            continue

        # Remove standings/rank prefixes and everything after first score.
        before_score = re.split(r"(?<![A-Z0-9])(?:[+-]\d+|E)(?![A-Z0-9])", line, maxsplit=1, flags=re.I)[0]
        before_score = re.sub(r"^T?\d+\s+", "", before_score).strip()

        # Keep plausible player-name text only.
        before_score = re.sub(r"\bUSA\b|\bENG\b|\bCAN\b|\bAUS\b|\bKOR\b|\bJPN\b", "", before_score).strip()

        name_key = normalize_player_name(before_score)

        if len(name_key.split()) >= 2:
            candidates.append((name_key, score, line))

    # JSON-ish fallback: search for displayName/fullName near score-like fields.
    for m in re.finditer(
        r'"(?:displayName|fullName|name)"\s*:\s*"([^"]{3,60})"',
        html,
        re.I
    ):
        raw_name = m.group(1)
        start = max(0, m.start() - 300)
        end = min(len(html), m.end() + 800)
        chunk = html[start:end].replace("\\u002F", "/").replace("\\/", "/").replace('\\"', '"')
        score = extract_score_from_candidate_text(chunk, raw_name)

        if score:
            name_key = normalize_player_name(raw_name)
            if len(name_key.split()) >= 2:
                candidates.append((name_key, score, raw_name))

    # Deduplicate, preserving first.
    seen = set()
    out = []

    for name_key, score, raw in candidates:
        sig = (name_key, score)

        if sig in seen:
            continue

        seen.add(sig)
        out.append((name_key, score, raw))

    return out


def add_fuzzy_score_matches(score_map, html, player_names):
    """
    For players still unmatched after exact parsing, use fuzzy name matching
    against candidate names found on the leaderboard page.
    """
    candidates = extract_leaderboard_name_score_candidates(html)

    if not candidates:
        return score_map

    for player in player_names:
        key = normalize_player_name(player)

        if not key or key in score_map:
            continue

        best = None
        best_score = 0.0

        for cand_name, score, raw in candidates:
            sim = similarity_score(key, cand_name)

            if sim > best_score:
                best = (cand_name, score, raw)
                best_score = sim

        # Keep this threshold conservative to avoid wrong scores.
        if best and best_score >= 0.86:
            score_map[key] = best[1]
            print(f"Fuzzy matched score: {player} -> {best[0]} = {best[1]} ({best_score:.2f})")

    return score_map



def extract_withdrawn_players_from_espn(html, player_names):
    """
    ESPN may include WD/CUT/STATUS text in the leaderboard payload or page text.
    This returns a set of normalized player names that appear near WD/Withdrawn.
    """
    withdrawn = set()

    if not html:
        return withdrawn

    for player in player_names:
        key = normalize_player_name(player)

        if not key:
            continue

        search_names = {
            clean_text(player),
            clean_text(player).upper(),
            clean_text(player).title(),
        }

        for search_name in search_names:
            if not search_name:
                continue

            for match in re.finditer(re.escape(search_name), html, re.I):
                start = max(0, match.start() - 800)
                end = min(len(html), match.end() + 1200)
                chunk = html[start:end]

                chunk_clean = clean_text(
                    chunk
                    .replace("\\u002F", "/")
                    .replace("\\/", "/")
                    .replace("&amp;", "&")
                    .replace('\\"', '"')
                )

                chunk_upper = chunk_clean.upper()

                if re.search(r'(?<![A-Z0-9])(WD|W/D|WITHDRAWN|WITHDREW)(?![A-Z0-9])', chunk_upper):
                    withdrawn.add(key)
                    break

            if key in withdrawn:
                break

    return withdrawn


def apply_wd_fallback(score_map, html, player_names):
    """
    If a Round 2 score isn't matched, check whether that player appears as WD.
    WD is more useful than Error for broadcast graphics.
    """
    withdrawn = extract_withdrawn_players_from_espn(html, player_names)

    if not withdrawn:
        return score_map

    for player in player_names:
        key = normalize_player_name(player)

        if not key:
            continue

        if key not in score_map and key in withdrawn:
            score_map[key] = "WD"
            print(f"WD fallback matched: {player} -> WD")

    return score_map


def fetch_leaderboard_scores(leaderboard_url, player_names):
    """
    Returns {normalized_player_name: score} from an ESPN leaderboard page.
    Uses several parsing strategies because ESPN's markup can vary.
    """
    if not leaderboard_url:
        return {}

    print(f"Leaderboard URL: {leaderboard_url}")

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    try:
        response = requests.get(
            leaderboard_url,
            timeout=30,
            headers=headers
        )
        response.raise_for_status()
    except Exception as exc:
        print(f"WARNING: Could not download leaderboard scores: {exc}")
        return {}

    html = response.text

    unique_players = {
        normalize_player_name(p)
        for p in player_names
        if normalize_player_name(p)
    }

    score_map = {}

    score_map.update(
        extract_scores_from_json_like_text(
            html,
            player_names
        )
    )

    if len(score_map) < len(unique_players):
        score_map.update(
            extract_scores_from_html_tables(
                html,
                player_names
            )
        )

    if len(score_map) < len(unique_players):
        score_map = add_fuzzy_score_matches(
            score_map,
            html,
            player_names
        )

    if len(score_map) < len(unique_players):
        score_map = apply_wd_fallback(
            score_map,
            html,
            player_names
        )

    matched = len(score_map)
    wanted = len(unique_players)

    print(f"Matched leaderboard scores for {matched} of {wanted} players.")

    if matched == 0:
        debug_path = os.path.join(
            DATA_FOLDER,
            "espn_leaderboard_debug.html"
        )

        try:
            with open(debug_path, "w", encoding="utf-8") as f:
                f.write(html)

            print(f"Saved ESPN debug HTML to: {debug_path}")
        except Exception:
            pass

    return score_map

def normalize_status_score(score):
    score = clean_text(score)
    if not score:
        return ""

    up = score.upper()
    if up in {"WD", "W/D", "WITHDREW", "WITHDRAWN"}:
        return "WD"
    if up in {"DQ", "CUT"}:
        return up
    return score


def normalize_espn_score_value(score):
    """
    Normalize ESPN leaderboard score/status text.

    ESPN can put WD/W-D/W/D/Withdrew/Withdrawn directly in the score field.
    Preserve that as WD instead of letting it become Error.
    """
    score = clean_text(score)

    if not score:
        return ""

    up = score.upper().replace("–", "-").replace("—", "-")

    if up in {"WD", "W-D", "W/D", "WITHDREW", "WITHDRAWN"}:
        return "WD"

    if up in {"DQ", "CUT", "E"}:
        return up

    if re.fullmatch(r"[+-]\d+", score):
        return score

    if re.fullmatch(r"\d+", score):
        n = int(score)
        return f"+{n}" if n > 0 else "E"

    return score


def get_player_score(player_name, score_map, round_num):
    if not clean_text(player_name):
        return ""

    if round_num == 1:
        return ""

    if not score_map:
        return "Error"

    score = score_map.get(normalize_player_name(player_name), "")

    return normalize_espn_score_value(score)


def strip_ampm(time_text):
    return re.sub(r"\s*[AP]M$", "", clean_text(time_text), flags=re.I)


def time_to_minutes(time_text):
    cleaned = clean_text(time_text).upper()
    parsed = datetime.strptime(cleaned, "%I:%M %p")
    return parsed.hour * 60 + parsed.minute


def round_label(round_num):
    if round_num == 1:
        return "OPENING_ROUND"
    if int(round_num) == 2:
        return "SECOND_ROUND"
    if round_num == 3:
        return "THIRD_ROUND"
    return "FINAL_ROUND"


def subtitle_text(round_num, wave):
    wave_clean = clean_text(wave).upper()
    wave_word = "MORNING" if wave_clean == "AM" else "AFTERNOON"
    has_wave = wave_clean not in {"ALL", "FULL", "BOTH"}

    if round_num == 1:
        return f"OPENING ROUND ({wave_word})" if has_wave else "OPENING ROUND"
    if int(round_num) == 2:
        return f"2ND ROUND ({wave_word})" if has_wave else "2ND ROUND"
    if round_num == 3:
        return "3RD ROUND"
    return "FINAL ROUND"

def build_pdf_url(season, tour_folder, tournament_slug, round_num):
    """
    PGA Tour Media usually uses:
      R1-R2 Tee Times.pdf for opening two rounds
      R3 Tee Times.pdf for third round
      R4 Tee Times.pdf for final round

    Some events have historically used R1 Tee Times.pdf / R2 Tee Times.pdf,
    so download_pdf() also has fallback handling.
    """
    if int(round_num) in [1, 2]:
        pdf_name = "R1-R2%20Tee%20Times.pdf",
        "R1%20and%20R2%20Tee%20Times.pdf",
        "R1%20%26%20R2%20Tee%20Times.pdf",
        "R1%20and%20R2%20Tee%20Times.pdf"
    else:
        pdf_name = f"R{round_num}%20Tee%20Times.pdf"

    return (
        f"https://pgatourmedia.pgatourhq.com/static-assets/page/files/"
        f"tours/{season}/{tour_folder}/{tournament_slug}/roundInfo/"
        f"{pdf_name}"
    )


def build_pdf_url_candidates(season, tour_folder, tournament_slug, round_num):
    """
    Return possible PGA Tour Media tee-time PDF URLs in preferred order.
    This is intentionally not tournament-specific.
    """
    base = (
        f"https://pgatourmedia.pgatourhq.com/static-assets/page/files/"
        f"tours/{season}/{tour_folder}/{tournament_slug}/roundInfo/"
    )

    patterns = {
        1: [
            "R1-R2%20Tee%20Times.pdf",
            "R1%20and%20R2%20Tee%20Times.pdf",
            "R1%20%26%20R2%20Tee%20Times.pdf",
            "R1%20Tee%20Times.pdf",
        ],
        2: [
            "R1-R2%20Tee%20Times.pdf",
            "R1%20and%20R2%20Tee%20Times.pdf",
            "R1%20%26%20R2%20Tee%20Times.pdf",
            "R2%20Tee%20Times.pdf",
        ],
        3: [
            "R3%20Tee%20Times.pdf",
            "Round%203%20Tee%20Times.pdf",
        ],
        4: [
            "Final%20Round%20Tee%20Times.pdf",
            "R4%20Tee%20Times.pdf",
            "Round%204%20Tee%20Times.pdf",
        ],
    }

    urls = []
    seen = set()
    for filename in patterns.get(int(round_num), [f"R{round_num}%20Tee%20Times.pdf"]):
        url = base + filename
        if url not in seen:
            seen.add(url)
            urls.append(url)

    print(f"Looking for PGA Tour Media tee sheet using {len(urls)} filename pattern(s) for Round {round_num}.")
    for url in urls:
        print(f"PDF candidate: {url.rsplit('/', 1)[-1]}")
    return urls


def download_pdf(pdf_url):
    headers = {"User-Agent": "Mozilla/5.0"}

    urls = pdf_url if isinstance(pdf_url, list) else [pdf_url]
    last_error = None

    for url in urls:
        try:
            print(f"Trying PDF URL: {url}")

            r = requests.get(url, timeout=30, headers=headers)
            r.raise_for_status()
            print(f"Found PGA Tour Media PDF: {url.rsplit('/', 1)[-1]}")

            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                tmp.write(r.content)
                return tmp.name, url

        except Exception as exc:
            last_error = exc
            print(f"PDF URL failed: {url} ({exc})")

    print("No PGA Tour Media PDF candidate succeeded.")
    raise last_error

def extract_pdf_text(pdf_path):
    text = ""

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            extracted = page.extract_text() or ""
            text += "\n" + extracted

    return text



def extract_player_from_weekend_scored_left(left_text):
    """
    Given left text like:
      Lanto Griffin Jacksonville Beach, FL
      Rasmus Neergaard-Petersen Copenhagen, Denmark
      Erik van Rooyen Johannesburg, RSA

    return only the player name at the beginning.
    """
    left_text = clean_text(left_text)

    if not left_text:
        return ""

    # Reuse the name splitter's first parsed name; it knows about particles,
    # suffixes, hyphenated names, etc.
    parts = split_player_line_into_three(left_text)
    parts = repair_known_multiword_players(parts)

    if parts:
        return clean_text(parts[0])

    return ""


def parse_weekend_scored_row(line):
    """
    Parse a Round 3 / Final PDF player row.

    Returns:
      tee_time or None,
      player_name,
      score
    """
    m = WEEKEND_SCORED_ROW_RE.match(clean_text(line))

    if not m:
        return None, "", ""

    tee_time, left_text, score = m.groups()

    player_name = extract_player_from_weekend_scored_left(left_text)
    score = normalize_score_value(score)

    return tee_time, player_name, score



def parse_two_round_tee_header(line):
    """
    Accept multiple PGA Media R1/R2 tee header styles:
      1 Tee 10 Tee
      10 Tee 1 Tee
      Tee #1 Tee #10
      Tee #10 Tee #1
      TEE #1 TEE #10
    Returns (rd1_tee, rd2_tee) or None.
    """
    text = clean_text(line).upper()
    text = text.replace("#", " ")
    text = re.sub(r"\s+", " ", text)

    nums = []

    # Prefer TEE-adjacent numbers.
    for m in re.finditer(r"(?:TEE\s+)?(1|10)(?:\s+TEE)?", text):
        try:
            nums.append(int(m.group(1)))
        except Exception:
            pass

    # Filter to exactly the meaningful tee numbers in order.
    filtered = []
    for n in nums:
        if n in [1, 10]:
            if not filtered or filtered[-1] != n:
                filtered.append(n)

    if len(filtered) >= 2:
        return filtered[0], filtered[1]

    if "TEE" in text and "1" in text and "10" in text:
        if text.find("1") < text.find("10"):
            return 1, 10
        return 10, 1

    return None



def split_known_players_from_line(player_line):
    """
    Pull known multiword player names out of a collapsed two/three-player line
    before generic word splitting.

    Example:
      Min Woo Lee Mac Meissner
    should become:
      Min Woo Lee / Mac Meissner
    not:
      Min Woo / Lee Mac
    """
    line = clean_text(player_line)
    if not line:
        return []

    known_matches = []

    try:
        known_list = KNOWN_MULTIWORD_PLAYERS
    except Exception:
        known_list = []

    for known in known_list:
        known_clean = clean_text(known)
        if not known_clean:
            continue

        m = re.search(r"(?<![A-Za-z])" + re.escape(known_clean) + r"(?![A-Za-z])", line, re.I)
        if m:
            known_matches.append((m.start(), m.end(), known_clean))

    if not known_matches:
        return []

    known_matches.sort(key=lambda x: x[0])

    players = []
    pos = 0

    for start, end, known_name in known_matches:
        before = clean_text(line[pos:start])
        if before:
            # Whatever comes before this known name may contain a normal player.
            before_parts = split_player_line_into_three(before)
            players.extend([clean_text(p) for p in before_parts if clean_text(p)])

        players.append(known_name)
        pos = end

    after = clean_text(line[pos:])
    if after:
        # For the remaining tail, a twosome tail is usually First Last.
        words = after.split()
        if len(words) == 2:
            players.append(after)
        else:
            after_parts = split_player_line_into_three(after)
            players.extend([clean_text(p) for p in after_parts if clean_text(p)])

    # Keep plausible names only.
    cleaned = []
    for p in players:
        if len(normalize_player_name(p).split()) >= 2:
            cleaned.append(p)

    return cleaned[:3]


def split_player_line_dynamic(player_line):
    """
    R1/R2 PDFs can be threesomes or twosomes.

    Signature/smaller-field events can have twosomes like:
      Brian Campbell Pierceson Coody
    which is four words and should be split 2+2, not forced into three names.

    Known multiword names are handled first, e.g.:
      Min Woo Lee Mac Meissner -> Min Woo Lee / Mac Meissner
    """
    player_line = clean_text(player_line)

    known_split = split_known_players_from_line(player_line)
    if len(known_split) >= 2:
        return known_split[:3]

    words = player_line.split()

    # Clean 2-player / 4-word case.
    if len(words) == 4:
        return [
            " ".join(words[:2]),
            " ".join(words[2:]),
        ]

    # Clean 2-player / 5+ word case where first player has suffix or particle
    # is handled by the existing known-name/particle splitter below.
    players = split_player_line_into_three(player_line)
    players = repair_known_multiword_players(players)
    players = [clean_text(p) for p in players if clean_text(p)]

    plausible = [
        p for p in players
        if len(normalize_player_name(p).split()) >= 2
    ]

    return plausible[:3]

def parse_groups_from_text(text, selected_round):
    lines = [
        clean_text(line)
        for line in text.splitlines()
        if clean_text(line)
    ]

    tournament_name = ""
    event_dates = ""

    pre_header_lines = []

    for line in lines:
        if "Groupings & Starting Times" in line or "Starting Times" in line:
            break

        if not re.match(r"^\d+\s+of\s+\d+$", line, re.I):
            pre_header_lines.append(line)

    if pre_header_lines:
        tournament_name = pre_header_lines[0]

    for line in lines:
        if re.search(r"\b20\d{2}\b", line) and (
            "Thursday" in line
            or "Friday" in line
            or "Saturday" in line
            or "Sunday" in line
        ):
            event_dates = line
            break

    groups = []

    current_rd1_tee = None
    current_rd2_tee = None
    current_single_tee = 1 if int(selected_round) >= 3 else None

    i = 0

    while i < len(lines):
        line = lines[i]
        line_upper = line.upper()

        # R1/R2 two-tee section headers, flexible variants.
        header_pair = parse_two_round_tee_header(line)

        if header_pair and int(selected_round) in [1, 2] and not TIME_PAIR_RE.match(line):
            current_rd1_tee, current_rd2_tee = header_pair
            current_single_tee = None
            i += 1
            continue

        # Weekend tee headers.
        if re.fullmatch(r"(TEE\s*#?\s*1|1\s+TEE|1ST\s+TEE|NO\.\s*1\s+TEE)", line_upper):
            current_single_tee = 1
            current_rd1_tee = None
            current_rd2_tee = None
            i += 1
            continue

        if re.fullmatch(r"(TEE\s*#?\s*10|10\s+TEE|10TH\s+TEE|NO\.\s*10\s+TEE)", line_upper):
            current_single_tee = 10
            current_rd1_tee = None
            current_rd2_tee = None
            i += 1
            continue

        # R1/R2 format:
        # 7:00 AM 11:40 AM Player Player Player
        # or twosome:
        # 7:00 AM 11:40 AM Player Player
        m_pair = TIME_PAIR_RE.match(line)

        if m_pair and int(selected_round) in [1, 2]:
            rd1_time, rd2_time, player_line = m_pair.groups()

            # If the PDF omitted or styled the header oddly, assume the first
            # block is Rd1 Tee 1 / Rd2 Tee 10 until a header says otherwise.
            if current_rd1_tee is None or current_rd2_tee is None:
                current_rd1_tee = 1
                current_rd2_tee = 10

            players = split_player_line_dynamic(player_line)

            if int(selected_round) == 1:
                tee = current_rd1_tee
                tee_time = rd1_time
            else:
                tee = current_rd2_tee
                tee_time = rd2_time

            if len(players) >= 1:
                groups.append({
                    "tee": tee,
                    "tee_time_display": strip_ampm(tee_time) or clean_text(tee_time),
                    "sort_minutes": time_to_minutes(tee_time),
                    "players": [smart_player_caps(p) for p in players[:3]],
                    "scores": [],
                })

            i += 1
            continue

        # R3/R4 weekend scored format:
        if int(selected_round) >= 3 and current_single_tee:
            first_time, first_player, first_score = parse_weekend_scored_row(line)

            if first_time and first_player:
                tee_time = first_time
                players = [first_player]
                scores = [first_score]
                j = i + 1

                while j < len(lines) and len(players) < 3:
                    next_line = lines[j]
                    next_upper = next_line.upper()
                    next_time, next_player, next_score = parse_weekend_scored_row(next_line)

                    if next_time:
                        break

                    if re.fullmatch(r"(TEE\s*#?\s*1|1\s+TEE|1ST\s+TEE|NO\.\s*1\s+TEE)", next_upper):
                        break

                    if re.fullmatch(r"(TEE\s*#?\s*10|10\s+TEE|10TH\s+TEE|NO\.\s*10\s+TEE)", next_upper):
                        break

                    if next_player:
                        players.append(next_player)
                        scores.append(next_score)

                    j += 1

                if len(players) >= 1:
                    groups.append({
                        "tee": current_single_tee,
                        "tee_time_display": strip_ampm(tee_time) or clean_text(tee_time),
                        "sort_minutes": time_to_minutes(tee_time),
                        "players": [smart_player_caps(p) for p in players[:3]],
                        "scores": [normalize_score_value(s) for s in scores[:3]],
                    })

                    i = j
                    continue

        if int(selected_round) >= 3 and TIME_ONLY_RE.match(line) and current_single_tee:
            tee_time = TIME_ONLY_RE.match(line).group(1)
            players = []
            scores = []
            j = i + 1

            while j < len(lines) and len(players) < 3:
                next_line = lines[j]
                next_time, next_player, next_score = parse_weekend_scored_row(next_line)

                if TIME_ONLY_RE.match(next_line) or next_time:
                    break

                if next_player:
                    players.append(next_player)
                    scores.append(next_score)

                j += 1

            if len(players) >= 1:
                groups.append({
                    "tee": current_single_tee,
                    "tee_time_display": strip_ampm(tee_time) or clean_text(tee_time),
                    "sort_minutes": time_to_minutes(tee_time),
                    "players": [smart_player_caps(p) for p in players[:3]],
                    "scores": [normalize_score_value(s) for s in scores[:3]],
                })

                i = j
                continue

        i += 1

    single_count = sum(
        1 for group in groups
        if len([p for p in group.get("players", []) if clean_text(p)]) == 1
    )

    if single_count:
        print(f"Parsed {single_count} single-player tee-time group(s).")

    return tournament_name, event_dates, groups

def split_wave_groups(all_groups, wave):
    ordered = sorted(all_groups, key=lambda g: (g["sort_minutes"], g["tee"]))

    if clean_text(wave).upper() in {"ALL", "FULL", "BOTH"}:
        return ordered, 0

    half = len(ordered) // 2

    if wave.upper() == "AM":
        return ordered[:half], 0

    return ordered[half:], half

def order_wave_for_layout(wave_groups):
    one_tee = sorted(
        [g for g in wave_groups if g["tee"] == 1],
        key=lambda g: g["sort_minutes"]
    )
    ten_tee = sorted(
        [g for g in wave_groups if g["tee"] == 10],
        key=lambda g: g["sort_minutes"]
    )

    return one_tee + ten_tee


def get_excel_app():
    try:
        import win32com.client
    except ImportError:
        print("pywin32 is missing. Attempting to install it now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pywin32"])
        import win32com.client

    return win32com.client.Dispatch("Excel.Application")


def get_or_open_workbook(excel, workbook_path):
    workbook_path = os.path.abspath(workbook_path)

    for wb in excel.Workbooks:
        try:
            if os.path.abspath(wb.FullName).lower() == workbook_path.lower():
                return wb
        except Exception:
            pass

    return excel.Workbooks.Open(workbook_path)


def read_settings_from_excel(workbook):
    ws = workbook.Worksheets("Import_Settings")

    season = clean_excel_int(ws.Range("B2").Value, "2026")
    tour_folder = clean_text(ws.Range("B3").Value or "pgatour").lower()
    tournament_slug = clean_text(ws.Range("B4").Value or "charlesschwabchallenge").lower()
    round_num = int(clean_excel_int(ws.Range("B5").Value, "2"))
    wave = clean_text(ws.Range("B6").Value or "AM").upper()
    override_url = clean_text(ws.Range("B7").Value or "")
    # B8 is already used in the workbook as the generated PGA PDF URL preview.
    # Optional leaderboard override moved safely out of the existing settings area.
    leaderboard_url = clean_text(ws.Range("B15").Value or "")

    return season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url



def build_round2_time_map_from_r1r2_text(text):
    """
    Build player -> Round 2 tee time map from an R1-R2 PDF.

    This is a safety layer for signature-event twosome sheets where layout
    should look like Round 1, but Round 2 must use the second time column.
    """
    lines = [
        clean_text(line)
        for line in text.splitlines()
        if clean_text(line)
    ]

    time_map = {}

    for line in lines:
        m = TIME_PAIR_RE.match(line)

        if not m:
            continue

        rd1_time, rd2_time, player_line = m.groups()

        if not rd2_time:
            continue

        players = split_player_line_dynamic(player_line)

        for player in players:
            key = normalize_player_name(player)

            if key:
                time_map[key] = strip_ampm(rd2_time) or clean_text(rd2_time)

    return time_map


def force_round2_times_from_map(rows, round2_time_map):
    """
    If Round 2 rows have missing or incorrect tee times, use the player-based
    R1-R2 PDF map to force the second time column.
    """
    if not round2_time_map:
        return rows

    fixed = 0

    for row in rows:
        players = [row[4], row[6], row[8]]

        for player in players:
            key = normalize_player_name(player)

            if key and key in round2_time_map:
                new_time = round2_time_map[key]

                if clean_text(new_time):
                    if row[3] != new_time:
                        fixed += 1

                    row[3] = new_time
                    break

    if fixed:
        print(f"Forced Round 2 tee times from R1-R2 PDF map for {fixed} groups.")

    return rows


def row_wave_from_time_value(tee_time):
    """
    Determine AM/PM from the selected round tee time.
    """
    text = clean_text(tee_time).upper()

    if "AM" in text:
        return "AM"

    if "PM" in text:
        return "PM"

    m = re.search(r"\b(\d{1,2}):(\d{2})\b", text)

    if not m:
        return ""

    hour = int(m.group(1))

    # PGA morning waves generally use 6-11, afternoon 12-7.
    if 6 <= hour <= 11:
        return "AM"

    return "PM"


def filter_rows_by_selected_wave(rows, selected_wave):
    """
    Final safety filter after Round 2 tee times have been forced.

    This prevents Round 2 PM from accidentally including AM-wave groups
    when filtering happened before the Round 2 time column was applied.
    """
    wave_clean = clean_text(selected_wave).upper()

    if wave_clean in {"ALL", "FULL", "BOTH"}:
        return rows

    if wave_clean not in {"AM", "PM"}:
        return rows

    filtered = []

    for row in rows:
        row_wave = row_wave_from_time_value(row[3])

        if row_wave == wave_clean:
            filtered.append(row)

    if len(filtered) != len(rows):
        print(
            f"Wave safety filter: {wave_clean} kept {len(filtered)} of {len(rows)} rows "
            f"using selected-round tee times."
        )

    return filtered


def build_rows_from_pdf(season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url):
    if override_url:
        pdf_url_candidates = [override_url]
    else:
        pdf_url_candidates = build_pdf_url_candidates(
            season,
            tour_folder,
            tournament_slug,
            round_num
        )

    pdf_path, pdf_url = download_pdf(pdf_url_candidates)
    text = extract_pdf_text(pdf_path)

    round2_time_map = {}
    if int(round_num) == 2:
        round2_time_map = build_round2_time_map_from_r1r2_text(text)
        if round2_time_map:
            print(f"Built Round 2 tee-time map for {len(round2_time_map)} players.")

    tournament_name, event_dates, all_groups = parse_groups_from_text(
        text,
        selected_round=round_num
    )

    if not tournament_name:
        tournament_name = tournament_slug.replace("-", " ").replace("_", " ").title()

    if not all_groups:
        debug_path = os.path.join(
            DATA_FOLDER,
            "pga_teetimes_debug_text.txt"
        )

        try:
            with open(debug_path, "w", encoding="utf-8") as f:
                f.write(f"PDF URL: {pdf_url}\n")
                f.write(f"Round: {round_num}\n")
                f.write(f"Wave: {wave}\n\n")
                f.write(text)

            print(f"Saved PDF debug text to: {debug_path}")
        except Exception:
            pass

        raise RuntimeError(
            "No tee-time groups were parsed. "
            "The PDF layout may have changed, or the URL may not point to a tee-times PDF."
        )

    # Important: Round 1 cache must be based on the FULL FIELD,
    # not only the selected AM/PM wave being exported.
    if round_num == 1:
        save_round1_group_map_from_all_groups(
            season,
            tournament_name,
            all_groups
        )

    selected_wave_groups, wave_offset = split_wave_groups(all_groups, wave)
    ordered_groups = order_wave_for_layout(selected_wave_groups)

    all_player_names = []
    for group in ordered_groups:
        all_player_names.extend([p for p in group["players"] if clean_text(p)])

    score_map = {}

    # Rounds 3/Final have scores directly in the PGA tee-time PDF.
    # Only use ESPN/leaderboard matching for Round 2.
    if int(round_num) == 2:
        if re.fullmatch(r"\d{6,}", clean_text(leaderboard_url)):
            leaderboard_url = (
                "https://www.espn.com/golf/leaderboard/_/tournamentId/"
                + clean_text(leaderboard_url)
            )

        if leaderboard_url and not is_valid_leaderboard_url(leaderboard_url):
            print(
                "Ignoring non-leaderboard URL in optional override cell. "
                "This looks like a tee-time PDF or unsupported URL."
            )
            leaderboard_url = ""

        if not leaderboard_url:
            leaderboard_url = discover_espn_leaderboard_url(
                tournament_name,
                season
            )

        if is_valid_leaderboard_url(leaderboard_url):
            score_map = fetch_leaderboard_scores(
                leaderboard_url,
                all_player_names
            )
        else:
            print("No valid leaderboard URL found. Scores will default to Error.")

    rows = []

    round1_group_map = {}
    round1_player_group_map = {}

    if int(round_num) == 2:
        round1_group_map = load_round1_group_map(
            season,
            tournament_name
        )

    # Sheet1 formulas look up tee-side slots:
    #   1|1, 1|2, 1|3...
    #   10|1, 10|2, 10|3...
    #
    # The visible Group column is separate:
    #   Round 1: generated from original pairing order
    #   Round 2: carried over from Round 1 group map
    #   Round 3/Final: restarted from 1
    tee_slot_counts = {
        1: 0,
        10: 0,
    }

    actual_tees = {
        int(group["tee"])
        for group in ordered_groups
        if group.get("tee") is not None
    }

    wave_is_all = clean_text(wave).upper() in {"ALL", "FULL", "BOTH"}

    # Any full-field all-one-tee layout should use both visual columns.
    # This includes:
    #   - Weekend all-1-tee starts
    #   - Signature-event R1/R2 all-1-tee twosome starts
    single_tee_full_field = (
        wave_is_all
        and len(actual_tees) == 1
    )

    # If there is an odd number of groups, put the extra on the right side.
    layout_split = len(ordered_groups) // 2

    for idx, group in enumerate(ordered_groups, start=1):
        actual_tee = int(group["tee"])

        if single_tee_full_field:
            key_tee = 10 if idx <= layout_split else 1
        else:
            key_tee = actual_tee

        tee_slot_counts[key_tee] += 1
        tee_slot = tee_slot_counts[key_tee]

        players = list(group["players"])
        pdf_scores = list(group.get("scores", []))

        while len(players) < 3:
            players.append("")

        while len(pdf_scores) < 3:
            pdf_scores.append("")

        if int(round_num) in [1, 2]:
            # Source of truth: player->group map from the full R1/R2 PDF.
            # This prevents PM wave from restarting at 1 and keeps Round 2
            # group numbers carried over from Round 1.
            group_num = lookup_group_number_from_player_map(
                players,
                round1_player_group_map
            )

            # Fallback to old JSON lookup for Round 2 if needed.
            if group_num is None and int(round_num) == 2:
                group_num = lookup_round1_group_number(
                    players,
                    round1_group_map
                )

            if group_num is None:
                if int(round_num) == 2:
                    print(
                        "WARNING: Could not find Round 1 group number for "
                        f"{players[0]} / {players[1]} / {players[2]}"
                    )
                    group_num = "Error"
                else:
                    group_num = idx
        else:
            group_num = idx

        if round_num >= 3:
            score1 = "" if not clean_text(players[0]) else normalize_score_value(pdf_scores[0])
            score2 = "" if not clean_text(players[1]) else normalize_score_value(pdf_scores[1])
            score3 = "" if not clean_text(players[2]) else normalize_score_value(pdf_scores[2])
        else:
            score1 = get_player_score(players[0], score_map, round_num)
            score2 = get_player_score(players[1], score_map, round_num)
            score3 = "" if not clean_text(players[2]) else get_player_score(players[2], score_map, round_num)

        key = f"{key_tee}|{tee_slot}"

        rows.append([
            key,
            group_num,
            actual_tee,
            group["tee_time_display"],
            players[0],
            score1,
            players[1],
            score2,
            players[2],
            score3,
            round_num,
            wave,
            pdf_url,
            f"Imported from PGA Tour Media PDF - {event_dates}",
        ])

    if int(round_num) == 2:
        rows = force_round2_times_from_map(
            rows,
            round2_time_map
        )

    # Final wave filter after all selected-round tee times are known.
    # Especially important for Round 2, where the R1-R2 PDF has two time columns.
    rows = filter_rows_by_selected_wave(rows, wave)

    try:
        rows.sort(key=lambda r: (int(r[2]) if clean_text(r[2]) else 99, time_to_minutes(r[3]), clean_text(r[1])))
    except Exception:
        pass

    try:
        nums = [clean_text(row[1]) for row in rows if clean_text(row[1])]
        if nums:
            print(f"Output group numbers: first={nums[0]}, last={nums[-1]}, count={len(nums)}")
    except Exception:
        pass

    return rows, tournament_name


def ensure_api_sheet(workbook):
    try:
        return workbook.Worksheets("API_Data")
    except Exception:
        ws = workbook.Worksheets.Add()
        ws.Name = "API_Data"
        return ws


def write_api_data_excel(workbook, rows):
    ws = ensure_api_sheet(workbook)

    headers = [
        "Key",
        "Group",
        "Tee",
        "TeeTime",
        "Player1",
        "Score1",
        "Player2",
        "Score2",
        "Player3",
        "Score3",
        "Round",
        "Wave",
        "SourceURL",
        "Notes",
    ]

    ws.Range("A1:N1").Value = headers

    # Force score columns to text so Excel does not coerce +2 into 2.
    ws.Range("F:F").NumberFormat = "@"
    ws.Range("H:H").NumberFormat = "@"
    ws.Range("J:J").NumberFormat = "@"

    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    if last_row >= 2:
        ws.Range(f"A2:N{last_row}").ClearContents()

    if rows:
        ws.Range(f"A2:N{len(rows) + 1}").Value = rows

        # Re-apply score values cell-by-cell as strings to preserve leading plus signs.
        for row_idx, row_values in enumerate(rows, start=2):
            ws.Cells(row_idx, 6).Value = str(row_values[5])
            ws.Cells(row_idx, 8).Value = str(row_values[7])
            ws.Cells(row_idx, 10).Value = str(row_values[9])



def cleanup_sheet1_unused_rows(workbook, group_count=None):
    """
    Hide unused rows on Sheet1 after formulas have calculated.

    IMPORTANT:
    Do not hide rows too aggressively before export. For all-1-tee / twosome
    layouts, the source template may need more rows visible than the first
    detected used row suggests. Export cleanup trims the finished workbook later.
    """
    try:
        ws = workbook.Worksheets("Sheet1")
    except Exception:
        return

    try:
        ws.Rows.Hidden = False
    except Exception:
        pass

    try:
        used = ws.UsedRange
    except Exception:
        return

    ignored_leftover_text = {
        "COLONIAL COUNTRY CLUB",
    }

    for cell in used:
        try:
            value = cell.Value
            row_num = cell.Row
        except Exception:
            continue

        text_upper = clean_text(value).upper()

        if row_num > 10 and text_upper in ignored_leftover_text:
            try:
                cell.ClearContents()
            except Exception:
                pass

    last_needed_row = 1

    try:
        used = ws.UsedRange
    except Exception:
        return

    for cell in used:
        try:
            value = cell.Value
            row_num = cell.Row
        except Exception:
            continue

        text = clean_text(value)

        if not text:
            continue

        text_upper = text.upper()

        if text_upper in ignored_leftover_text:
            continue

        if text_upper in {"ERROR", "#N/A", "#VALUE!", "#REF!", "#NAME?"}:
            continue

        keep = False

        if re.fullmatch(r"\d{1,2}:\d{2}", text):
            keep = True

        elif re.fullmatch(r"\d+", text):
            keep = True

        elif text_upper == "E":
            keep = True

        elif re.fullmatch(r"[+-]\d+", text):
            keep = True

        elif row_num <= 10 and (
            "TEE" in text_upper
            or "ROUND" in text_upper
            or "CHALLENGE" in text_upper
            or "CHAMPIONSHIP" in text_upper
            or "OPEN" in text_upper
            or "TOURNAMENT" in text_upper
        ):
            keep = True

        elif 10 < row_num < 200 and len(text) >= 3 and any(ch.isalpha() for ch in text):
            keep = True

        if keep and row_num > last_needed_row:
            last_needed_row = row_num

    # Group-count safety buffer:
    # For 36 twosome groups split 18/18, the source template may need about
    # 4 rows per group on each side before export compaction.
    try:
        if group_count:
            group_count = int(group_count)
            side_count = (group_count + 1) // 2
            minimum_needed = 8 + (side_count * 4) + 6
            last_needed_row = max(last_needed_row, minimum_needed)
    except Exception:
        pass

    last_needed_row = min(max(last_needed_row + 1, 1), 200)

    try:
        if last_needed_row < 200:
            ws.Rows(f"{last_needed_row + 1}:200").Hidden = True

        print(
            f"Sheet1 cleanup: visible through row {last_needed_row}, "
            f"hid rows {last_needed_row + 1}:200"
        )
    except Exception as exc:
        print(f"WARNING: Could not hide unused Sheet1 rows: {exc}")



def update_title_subtitle_excel(workbook, tournament_name, round_num, wave):
    ws = workbook.Worksheets("Sheet1")
    subtitle = subtitle_text(round_num, wave)

    # Direct cells are safer than scanning text; prevents course names
    # from becoming the document title.
    try:
        ws.Range("A1").Value = tournament_name.upper()
        ws.Range("A4").Value = subtitle
        ws.Range("A4").Font.Underline = 2
    except Exception:
        pass

    # Make sure extra group slots can show, especially 25-group weekend layouts.
    try:
        ws.Rows.Hidden = False
    except Exception:
        pass

    # For ALL layouts where everyone is off Tee #1, both visual columns
    # should be labeled 1 TEE.
    if clean_text(wave).upper() in {"ALL", "FULL", "BOTH"}:
        try:
            ws.Range("C7").Value = "1 TEE"
            ws.Range("H7").Value = "1 TEE"
        except Exception:
            pass

def underline_sheet1_times_excel(workbook):
    ws = workbook.Worksheets("Sheet1")
    time_only_re = re.compile(r"^\d{1,2}:\d{2}$")

    for cell in ws.UsedRange:
        try:
            value = cell.Value
        except Exception:
            continue

        if isinstance(value, str):
            val = clean_text(value)

            if time_only_re.match(val):
                cell.Font.Underline = 2

            if any(x in val.upper() for x in [
                "OPENING ROUND",
                "2ND ROUND",
                "3RD ROUND",
                "FINAL ROUND",
            ]):
                cell.Font.Underline = 2



def compact_signature_twosome_layout_on_export(output_ws):
    """
    Export-only cleanup for all-1-tee twosome layouts.

    Desired twosome layout:
      row 1: time + player 1
      row 2: group number + player 2
      row 3: blank spacer row with bottom border
      next row: next group

    The template can leave an extra blank row after the spacer. This removes
    that extra blank row while keeping the intended spacer row.
    """
    XL_LINE_NONE = -4142
    XL_CONTINUOUS = 1
    XL_MEDIUM = -4138

    try:
        used = output_ws.UsedRange
        max_row = min(int(used.Rows.Count) + int(used.Row) + 20, 200)
    except Exception:
        max_row = 200

    LEFT = list(range(1, 6))    # A:E
    RIGHT = list(range(6, 11))  # F:J
    ALL_COLS = list(range(1, 11))

    def cell_text(r, c):
        try:
            return clean_text(str(output_ws.Cells(r, c).Text))
        except Exception:
            try:
                return clean_text(output_ws.Cells(r, c).Value)
            except Exception:
                return ""

    def side_texts(r, cols):
        vals = []
        for c in cols:
            t = cell_text(r, c)
            if t:
                vals.append((c, t))
        return vals

    def has_alpha(r, cols):
        return any(any(ch.isalpha() for ch in t) for c, t in side_texts(r, cols))

    def has_time(r, cols):
        return any(re.fullmatch(r"\d{1,2}:\d{2}", t) for c, t in side_texts(r, cols))

    def row_is_blank(r, cols=ALL_COLS):
        return not bool(side_texts(r, cols))

    def find_group_number_cell(r, cols):
        for c in cols[:2] + cols:
            t = cell_text(r, c)
            if re.fullmatch(r"\d+", t):
                n = int(t)
                if 1 <= n <= 99:
                    return c, str(n)
        return None

    def side_has_only_group_and_zero(r, cols):
        gc = find_group_number_cell(r, cols)
        if not gc:
            return False

        if has_alpha(r, cols):
            return False

        group_col, group_num = gc

        for c, t in side_texts(r, cols):
            if c == group_col and t == group_num:
                continue
            if t in {"0", "E"}:
                continue
            return False

        return True

    def side_is_twosome_spacer_row(r, cols):
        return (
            side_has_only_group_and_zero(r, cols)
            and has_time(r - 2, cols)
            and has_alpha(r - 2, cols)
            and has_alpha(r - 1, cols)
        )

    def side_range(cols):
        return min(cols), max(cols)

    def clear_side_contents_and_borders(r, cols):
        c1, c2 = side_range(cols)
        try:
            rng = output_ws.Range(output_ws.Cells(r, c1), output_ws.Cells(r, c2))
            rng.ClearContents()
            for b in [7, 8, 9, 10, 11, 12]:
                rng.Borders(b).LineStyle = XL_LINE_NONE
        except Exception:
            pass

    def set_medium_bottom(r, cols):
        c1, c2 = side_range(cols)
        try:
            rng = output_ws.Range(output_ws.Cells(r, c1), output_ws.Cells(r, c2))
            rng.Borders(9).LineStyle = XL_CONTINUOUS
            rng.Borders(9).Weight = XL_MEDIUM
        except Exception:
            pass

    def move_group_up(r, cols):
        gc = find_group_number_cell(r, cols)
        if not gc:
            return
        group_col, group_num = gc
        try:
            output_ws.Cells(r - 1, group_col).Value = group_num
            output_ws.Cells(r, group_col).ClearContents()
        except Exception:
            pass

    spacer_rows = set()

    # First pass: turn the old third-player row into the desired blank spacer.
    for r in range(max_row, 10, -1):
        left_q = side_is_twosome_spacer_row(r, LEFT)
        right_q = side_is_twosome_spacer_row(r, RIGHT)

        if not left_q and not right_q:
            continue

        if left_q:
            move_group_up(r, LEFT)
            clear_side_contents_and_borders(r, LEFT)
            set_medium_bottom(r, LEFT)
            spacer_rows.add(r)

        if right_q:
            move_group_up(r, RIGHT)
            clear_side_contents_and_borders(r, RIGHT)
            set_medium_bottom(r, RIGHT)
            spacer_rows.add(r)

    # Second pass: delete the extra fully blank row after the intended spacer.
    # Example:
    #   row 9  time/player1
    #   row 10 group/player2
    #   row 11 blank spacer + bottom border  KEEP
    #   row 12 extra blank                 DELETE
    #   row 13 next time/player1
    rows_to_delete = []

    for r in range(max_row - 1, 10, -1):
        if r not in spacer_rows:
            continue

        extra_blank = r + 1

        if extra_blank > max_row:
            continue

        next_row = extra_blank + 1

        if row_is_blank(extra_blank, ALL_COLS) and (
            has_time(next_row, LEFT)
            or has_time(next_row, RIGHT)
            or has_alpha(next_row, LEFT)
            or has_alpha(next_row, RIGHT)
        ):
            rows_to_delete.append(extra_blank)

    # Delete bottom-up.
    for r in sorted(set(rows_to_delete), reverse=True):
        try:
            output_ws.Rows(r).Delete()
        except Exception:
            pass

    # Rebuild center divider only. Do not add horizontal borders under
    # the second-player/group-number row.
    try:
        used = output_ws.UsedRange
        final_max = min(int(used.Rows.Count) + int(used.Row) + 20, 200)

        center_rng = output_ws.Range(f"F8:F{final_max}")
        center_rng.Borders(7).LineStyle = XL_CONTINUOUS
        center_rng.Borders(7).Weight = XL_MEDIUM

    except Exception:
        pass



def compact_blank_twosome_rows_on_export(output_ws):
    """
    Export-only cleanup for twosome groups:
    If the third-player row of a group is blank but still has borders/formula
    remnants, clear its contents/borders so twosome groups take less visual space.

    This is intentionally conservative and only clears rows that have no content
    in either visual group area.
    """
    try:
        max_row = min(int(output_ws.UsedRange.Rows.Count) + int(output_ws.UsedRange.Row) + 5, 200)
    except Exception:
        max_row = 200

    def row_text(row_num, col_start, col_end):
        vals = []
        for col in range(col_start, col_end + 1):
            try:
                vals.append(clean_text(output_ws.Cells(row_num, col).Value))
            except Exception:
                pass
        return " ".join(v for v in vals if v)

    for row_num in range(8, max_row + 1):
        left_text = row_text(row_num, 1, 5)
        right_text = row_text(row_num, 6, 10)

        # Clear completely empty rows inside the pairing area, but do not
        # hide whole rows because the opposite side may still need them.
        if not left_text:
            try:
                output_ws.Range(f"A{row_num}:E{row_num}").ClearContents()
            except Exception:
                pass

        if not right_text:
            try:
                output_ws.Range(f"F{row_num}:J{row_num}").ClearContents()
            except Exception:
                pass


def remove_blank_left_slot_borders_on_export(output_ws):
    """
    Export-only cleanup for odd all-1-tee layouts.

    Desired final look:
      - Extra group appears on the right-side visual column.
      - Left side ends cleanly after its final real group.
      - Bottom border on the left remains directly under that last real group.
      - Center/right-card vertical border remains thick.
    """
    try:
        max_row = min(int(output_ws.UsedRange.Rows.Count) + int(output_ws.UsedRange.Row) + 5, 200)
    except Exception:
        max_row = 200

    def row_has_content(row_num, col_start, col_end):
        for col in range(col_start, col_end + 1):
            try:
                value = output_ws.Cells(row_num, col).Value
            except Exception:
                continue

            if clean_text(value):
                return True

        return False

    # Find the first row where the right side has the extra group but
    # the left side is blank. In the current layout this is the start of
    # the blank left-side slot opposite the extra right-side group.
    first_extra_right_row = None

    for row_num in range(8, max_row + 1):
        left_has = row_has_content(row_num, 1, 5)
        right_has = row_has_content(row_num, 6, 10)

        if right_has and not left_has:
            first_extra_right_row = row_num
            break

    if first_extra_right_row is None:
        return

    # The left bottom border should sit immediately above the blank slot.
    left_bottom_row = first_extra_right_row - 1

    try:
        # Remove any leftover left-side blank-card borders below the final
        # real left group, but do not touch the bottom border row.
        if first_extra_right_row <= max_row:
            blank_left_rng = output_ws.Range(f"A{first_extra_right_row}:E{max_row}")
            for border_id in [7, 8, 9, 10, 11, 12]:
                blank_left_rng.Borders(border_id).LineStyle = -4142  # xlLineStyleNone

        # Restore the bottom line under the final real left-side group.
        left_bottom_rng = output_ws.Range(f"A{left_bottom_row}:E{left_bottom_row}")
        left_bottom_rng.Borders(9).LineStyle = 1   # xlContinuous
        left_bottom_rng.Borders(9).Weight = -4138  # xlMedium

        # Restore the center divider / left edge of the right-side extra group.
        # Excel border ids: 7 = left edge.
        right_extra_rng = output_ws.Range(f"F{first_extra_right_row}:F{max_row}")
        right_extra_rng.Borders(7).LineStyle = 1   # xlContinuous
        right_extra_rng.Borders(7).Weight = -4138  # xlMedium

        # Also keep the right-card top/bottom borders intact where content exists.
        for row_num in range(first_extra_right_row, max_row + 1):
            if row_has_content(row_num, 6, 10):
                output_ws.Range(f"F{row_num}:J{row_num}").Borders(7).LineStyle = 1
                output_ws.Range(f"F{row_num}:J{row_num}").Borders(7).Weight = -4138

    except Exception as exc:
        print(f"WARNING: Could not clean odd-column export borders: {exc}")


def rewrite_export_group_numbers_for_all_one_tee(output_ws, group_count):
    """
    Export-only safety fix for full-field all-1-tee layouts.

    If there are 36 groups, the visual layout should be:
      left:  1-18
      right: 19-36

    This rewrites visible group numbers by finding time rows on each visual side.
    """
    try:
        group_count = int(group_count)
    except Exception:
        return

    if group_count <= 0:
        return

    left_count = group_count // 2
    right_count = group_count - left_count

    def cell_text(r, c):
        try:
            return clean_text(str(output_ws.Cells(r, c).Text))
        except Exception:
            try:
                return clean_text(output_ws.Cells(r, c).Value)
            except Exception:
                return ""

    def has_time(r, c1, c2):
        for c in range(c1, c2 + 1):
            if re.fullmatch(r"\d{1,2}:\d{2}", cell_text(r, c)):
                return True
        return False

    def has_player_text(r, c1, c2):
        for c in range(c1, c2 + 1):
            t = cell_text(r, c)
            if t and any(ch.isalpha() for ch in t):
                return True
        return False

    def clear_group_number_area(start_row, side):
        cols = [1, 2] if side == "left" else [6, 7]

        for rr in [start_row, start_row + 1, start_row + 2]:
            for c in cols:
                try:
                    output_ws.Cells(rr, c).ClearContents()
                except Exception:
                    pass

    def set_group_number(start_row, side, value):
        target_row = start_row + 1
        target_col = 1 if side == "left" else 6

        clear_group_number_area(start_row, side)

        try:
            output_ws.Cells(target_row, target_col).Value = value
            output_ws.Cells(target_row, target_col).Font.Bold = True
            output_ws.Cells(target_row, target_col).Font.Italic = True
        except Exception:
            pass

    left_start_rows = []
    right_start_rows = []

    for r in range(8, 200):
        if has_time(r, 1, 5) and has_player_text(r, 1, 5):
            left_start_rows.append(r)

        if has_time(r, 6, 10) and has_player_text(r, 6, 10):
            right_start_rows.append(r)

    if not left_start_rows or not right_start_rows:
        return

    left_start_rows = left_start_rows[:left_count]
    right_start_rows = right_start_rows[:right_count]

    for idx, r in enumerate(left_start_rows, start=1):
        set_group_number(r, "left", idx)

    for idx, r in enumerate(right_start_rows, start=left_count + 1):
        set_group_number(r, "right", idx)

    print(
        f"Rewrote visual group numbers: "
        f"left 1-{len(left_start_rows)}, "
        f"right {left_count + 1}-{left_count + len(right_start_rows)}"
    )


def trim_export_to_group_count(output_ws, group_count):
    """
    Export-only safety cleanup:
    Clear and hide everything after the final real parsed group.
    """
    if not group_count:
        return

    try:
        group_count = int(group_count)
    except Exception:
        return

    if group_count <= 0:
        return

    def cell_text(r, c):
        try:
            return clean_text(str(output_ws.Cells(r, c).Text))
        except Exception:
            try:
                return clean_text(output_ws.Cells(r, c).Value)
            except Exception:
                return ""

    last_group_row = None

    for r in range(8, 201):
        for c in range(1, 11):
            if cell_text(r, c) == str(group_count):
                last_group_row = r

    if last_group_row is None:
        print(f"WARNING: Could not find final group {group_count} on exported Sheet1.")
        return

    # Keep final group's spacer/border row only.
    keep_through = min(last_group_row + 1, 200)

    try:
        if keep_through < 200:
            clear_rng = output_ws.Range(f"A{keep_through + 1}:J200")
            clear_rng.ClearContents()
            output_ws.Rows(f"{keep_through + 1}:200").Hidden = True

        print(
            f"Export trim: parsed {group_count} groups; "
            f"final group row {last_group_row}; cleared/hid rows {keep_through + 1}:200"
        )
    except Exception as exc:
        print(f"WARNING: Could not trim exported rows to group count: {exc}")





def rebuild_standard_round12_wave_board_from_rows(output_ws, parsed_rows):
    """
    Export-only rebuild for normal Round 1 / Round 2 AM or PM waves.

    Layout per group:
      Row 1: tee time + player 1 + score
      Row 2: player 2 + score
      Row 3: group number + player 3 + score
      Row 4: full-height blank spacer row with bottom border

    Visual layout:
      Left column  = 10 Tee starters
      Right column = 1 Tee starters

    Group numbering:
      1 Tee groups are always numbered first, even though they appear right.
      10 Tee groups continue after the 1 Tee groups.
      Round 2 keeps parsed/JSON group numbers when present.
    """
    if not parsed_rows:
        return False

    try:
        round_num = int(parsed_rows[0][10])
        wave_value = clean_text(parsed_rows[0][11]).upper()
    except Exception:
        return False

    if round_num not in [1, 2]:
        return False

    if wave_value in {"ALL", "FULL", "BOTH"}:
        return False

    # This rebuild is for normal three-player wave sheets.
    # Pure twosome/full-field layouts still use their own direct rebuild.
    XL_LINE_NONE = -4142
    XL_CONTINUOUS = 1
    XL_MEDIUM = -4138
    XL_UNDERLINE_NONE = -4142

    tee1_rows = [row for row in parsed_rows if str(row[2]) == "1"]
    tee10_rows = [row for row in parsed_rows if str(row[2]) == "10"]

    if not tee1_rows and not tee10_rows:
        return False

    # Round 1/2: use parsed row group numbers from the source-of-truth map.
    # Do not recalculate by visual side.
    group_numbers = {}

    for row in parsed_rows:
        if clean_text(row[1]):
            group_numbers[id(row)] = row[1]

    if not group_numbers:
        g = 1
        for row in parsed_rows:
            group_numbers[id(row)] = g
            g += 1

    def clear_area():
        try:
            rng = output_ws.Range("A8:J200")
            rng.ClearContents()
            for b in [7, 8, 9, 10, 11, 12]:
                rng.Borders(b).LineStyle = XL_LINE_NONE
        except Exception:
            pass

    def border_top(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(8).LineStyle = XL_CONTINUOUS
            rng.Borders(8).Weight = XL_MEDIUM
        except Exception:
            pass

    def border_bottom(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(9).LineStyle = XL_CONTINUOUS
            rng.Borders(9).Weight = XL_MEDIUM
        except Exception:
            pass

    def border_left(r1, r2, col):
        try:
            rng = output_ws.Range(output_ws.Cells(r1, col), output_ws.Cells(r2, col))
            rng.Borders(7).LineStyle = XL_CONTINUOUS
            rng.Borders(7).Weight = XL_MEDIUM
        except Exception:
            pass

    def write_cell(r, c, value, bold=True, italic=False, underline=False):
        try:
            cell = output_ws.Cells(r, c)
            cell.Value = value
            cell.Font.Bold = bool(bold)
            cell.Font.Italic = bool(italic)
            cell.Font.Underline = 2 if underline else XL_UNDERLINE_NONE
            cell.ShrinkToFit = True
            cell.ShrinkToFit = True
        except Exception:
            pass

    def score_text(score):
        score = clean_text(score)
        if not score:
            return ""
        up = score.upper()
        if up in {"E", "WD", "CUT", "DQ", "ERROR"}:
            return "WD" if up in {"W/D", "WITHDREW", "WITHDRAWN"} else up
        if re.fullmatch(r"[+-]\d+", score):
            return score
        if re.fullmatch(r"\d+", score):
            n = int(score)
            return f"+{n}" if n > 0 else "E"
        return score

    def set_height(row_num, height=15):
        try:
            output_ws.Rows(row_num).RowHeight = height
        except Exception:
            pass

    def write_side(rows, start_row, side):
        if side == "left":
            time_col, group_col, name_col, score_col = 1, 1, 3, 4
            c1, c2 = 1, 5
        else:
            time_col, group_col, name_col, score_col = 6, 6, 8, 9
            c1, c2 = 6, 10

        row_num = start_row

        for row in rows:
            tee_time = clean_text(row[3])
            p1, s1 = clean_text(row[4]), score_text(row[5])
            p2, s2 = clean_text(row[6]), score_text(row[7])
            p3, s3 = clean_text(row[8]), score_text(row[9])
            gnum = group_numbers.get(id(row), clean_text(row[1]))

            # 4 full-height rows.
            for rr in [row_num, row_num + 1, row_num + 2, row_num + 3]:
                set_height(rr, 15)

            border_top(row_num, c1, c2)

            # Row 1: tee time + player 1 + score.
            write_cell(row_num, time_col, tee_time, bold=True, underline=True)
            if p1:
                write_cell(row_num, name_col, p1, bold=True)
            if s1:
                write_cell(row_num, score_col, s1, bold=True)

            # Row 2: player 2 + score.
            if p2:
                write_cell(row_num + 1, name_col, p2, bold=True)
            if s2:
                write_cell(row_num + 1, score_col, s2, bold=True)

            # Row 3: group number + player 3 + score.
            write_cell(row_num + 2, group_col, gnum, bold=True, italic=True)
            if p3:
                write_cell(row_num + 2, name_col, p3, bold=True)
            if s3:
                write_cell(row_num + 2, score_col, s3, bold=True)

            # Row 4: blank spacer with bottom border.
            border_bottom(row_num + 3, c1, c2)

            row_num += 4

        return row_num

    clear_area()

    start_row = 9

    left_end = write_side(tee10_rows, start_row, "left")
    right_end = write_side(tee1_rows, start_row, "right")

    final_row = max(left_end, right_end)

    border_left(7, min(final_row + 1, 200), 6)

    try:
        output_ws.Range("C7").Value = "10 TEE" if tee10_rows else "1 TEE"
        output_ws.Range("H7").Value = "1 TEE" if tee1_rows else "10 TEE"

        if final_row + 1 <= 200:
            output_ws.Range(f"A{final_row + 1}:J200").ClearContents()
            output_ws.Rows(f"{final_row + 1}:200").Hidden = True
    except Exception:
        pass

    print(
        f"Rebuilt standard Round {round_num} {wave_value} wave board directly from parsed rows: "
        f"10 Tee left={len(tee10_rows)}, 1 Tee right={len(tee1_rows)}."
    )

    return True


def rebuild_weekend_standard_board_from_rows(output_ws, parsed_rows):
    """
    Export-only rebuild for Round 3 / Final boards that are not pure twosomes.

    Left column = 10 Tee starters.
    Right column = 1 Tee starters.
    Weekend group numbers: 1 Tee gets groups 1..N first, 10 Tee continues.
    """
    if not parsed_rows:
        return False

    try:
        round_num = int(parsed_rows[0][10])
    except Exception:
        return False

    if round_num < 3:
        return False

    # Pure twosome fields should use the existing twosome board builder.
    if all(not clean_text(row[8]) for row in parsed_rows):
        return False

    XL_LINE_NONE = -4142
    XL_CONTINUOUS = 1
    XL_MEDIUM = -4138
    XL_UNDERLINE_NONE = -4142

    tee1_rows = [row for row in parsed_rows if str(row[2]) == "1"]
    tee10_rows = [row for row in parsed_rows if str(row[2]) == "10"]

    # Weekend group numbers: 1 Tee first, then 10 Tee.
    group_numbers = {}
    group_num = 1

    for row in tee1_rows:
        group_numbers[id(row)] = group_num
        group_num += 1

    for row in tee10_rows:
        group_numbers[id(row)] = group_num
        group_num += 1

    def clear_area():
        try:
            rng = output_ws.Range("A8:J200")
            rng.ClearContents()
            for b in [7, 8, 9, 10, 11, 12]:
                rng.Borders(b).LineStyle = XL_LINE_NONE
        except Exception:
            pass

    def border_top(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(8).LineStyle = XL_CONTINUOUS
            rng.Borders(8).Weight = XL_MEDIUM
        except Exception:
            pass

    def border_bottom(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(9).LineStyle = XL_CONTINUOUS
            rng.Borders(9).Weight = XL_MEDIUM
        except Exception:
            pass

    def border_left(r1, r2, col):
        try:
            rng = output_ws.Range(output_ws.Cells(r1, col), output_ws.Cells(r2, col))
            rng.Borders(7).LineStyle = XL_CONTINUOUS
            rng.Borders(7).Weight = XL_MEDIUM
        except Exception:
            pass

    def write_cell(r, c, value, bold=True, italic=False, underline=False):
        try:
            cell = output_ws.Cells(r, c)
            cell.Value = value
            cell.Font.Bold = bool(bold)
            cell.Font.Italic = bool(italic)
            cell.Font.Underline = 2 if underline else XL_UNDERLINE_NONE
            cell.ShrinkToFit = True
            cell.ShrinkToFit = True
        except Exception:
            pass

    def score_text(score):
        score = clean_text(score)
        if not score:
            return ""
        up = score.upper()
        if up in {"E", "WD", "W/D", "WITHDREW", "WITHDRAWN", "CUT", "DQ"}:
            return "WD" if up in {"W/D", "WITHDREW", "WITHDRAWN"} else up
        if re.fullmatch(r"[+-]\d+", score):
            return score
        if re.fullmatch(r"\d+", score):
            n = int(score)
            return f"+{n}" if n > 0 else "E"
        return score

    def set_height(row_num, height):
        try:
            output_ws.Rows(row_num).RowHeight = height
        except Exception:
            pass

    def write_side(rows, start_row, side):
        if side == "left":
            time_col, group_col, name_col, score_col = 1, 1, 3, 4
            c1, c2 = 1, 5
        else:
            time_col, group_col, name_col, score_col = 6, 6, 8, 9
            c1, c2 = 6, 10

        row_num = start_row

        for row in rows:
            tee_time = clean_text(row[3])
            p1, s1 = clean_text(row[4]), score_text(row[5])
            p2, s2 = clean_text(row[6]), score_text(row[7])
            p3, s3 = clean_text(row[8]), score_text(row[9])
            gnum = group_numbers.get(id(row), clean_text(row[1]))

            # Standard weekend block: 4 full-height rows.
            for rr in [row_num, row_num + 1, row_num + 2, row_num + 3]:
                set_height(rr, 15)

            border_top(row_num, c1, c2)

            # Row 1: tee time + player 1.
            write_cell(row_num, time_col, tee_time, bold=True, underline=True)
            if p1:
                write_cell(row_num, name_col, p1, bold=True)
            if s1:
                write_cell(row_num, score_col, s1, bold=True)

            # Row 2: player 2.
            if p2:
                write_cell(row_num + 1, name_col, p2, bold=True)
            if s2:
                write_cell(row_num + 1, score_col, s2, bold=True)

            # Row 3: group number + player 3 if present. For a twosome,
            # this row still exists and carries only the group number.
            write_cell(row_num + 2, group_col, gnum, bold=True, italic=True)
            if p3:
                write_cell(row_num + 2, name_col, p3, bold=True)
            if s3:
                write_cell(row_num + 2, score_col, s3, bold=True)

            # Row 4: full-height blank spacer with bottom border.
            border_bottom(row_num + 3, c1, c2)

            row_num += 4

        return row_num

    clear_area()

    start_row = 9

    left_end = write_side(tee10_rows, start_row, "left")
    right_end = write_side(tee1_rows, start_row, "right")
    final_row = max(left_end, right_end)

    border_left(7, min(final_row + 1, 200), 6)

    try:
        output_ws.Range("C7").Value = "10 TEE" if tee10_rows else "1 TEE"
        output_ws.Range("H7").Value = "1 TEE" if tee1_rows else "10 TEE"

        if final_row + 1 <= 200:
            output_ws.Range(f"A{final_row + 1}:J200").ClearContents()
            output_ws.Rows(f"{final_row + 1}:200").Hidden = True
    except Exception:
        pass

    print(
        f"Rebuilt weekend standard board directly from parsed rows: "
        f"10 Tee left={len(tee10_rows)}, 1 Tee right={len(tee1_rows)}."
    )

    return True


def rebuild_twosome_board_from_rows(output_ws, parsed_rows):
    """
    Export-only rebuild for twosome layouts.

    This writes the finished twosome board directly from parsed_rows and does
    not trust the formula body.

    Layout per group:
      Row 1: Tee time
      Row 2: Player 1 + score
      Row 3: Group number + Player 2 + score
      Row 4: blank spacer row, height 6.5, bottom border

    No rows are deleted.
    """
    if not parsed_rows:
        return False

    # Row structure:
    # 0 Key, 1 Group, 2 Tee, 3 Time,
    # 4 Player1, 5 Score1, 6 Player2, 7 Score2, 8 Player3, 9 Score3...
    all_twosomes = all(not clean_text(row[8]) for row in parsed_rows)

    try:
        wave_value = clean_text(parsed_rows[0][11]).upper()
    except Exception:
        wave_value = ""

    full_field_wave = wave_value in {"ALL", "FULL", "BOTH"}

    # AM/PM waves should stay on the original Excel template layout.
    if not all_twosomes or not full_field_wave:
        return False

    XL_LINE_NONE = -4142
    XL_CONTINUOUS = 1
    XL_MEDIUM = -4138
    XL_UNDERLINE_NONE = -4142

    group_count = len(parsed_rows)

    if group_count <= 0:
        return False

    # Split evenly; if odd, extra goes right.
    left_count = group_count // 2

    left_rows = parsed_rows[:left_count]
    right_rows = parsed_rows[left_count:]

    def clear_area():
        try:
            rng = output_ws.Range("A8:J200")
            rng.ClearContents()
            for b in [7, 8, 9, 10, 11, 12]:
                rng.Borders(b).LineStyle = XL_LINE_NONE
        except Exception:
            pass

    def set_medium_top(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(8).LineStyle = XL_CONTINUOUS
            rng.Borders(8).Weight = XL_MEDIUM
        except Exception:
            pass

    def set_medium_bottom(row_num, c1, c2):
        try:
            rng = output_ws.Range(output_ws.Cells(row_num, c1), output_ws.Cells(row_num, c2))
            rng.Borders(9).LineStyle = XL_CONTINUOUS
            rng.Borders(9).Weight = XL_MEDIUM
        except Exception:
            pass

    def set_medium_left(r1, r2, col):
        try:
            rng = output_ws.Range(output_ws.Cells(r1, col), output_ws.Cells(r2, col))
            rng.Borders(7).LineStyle = XL_CONTINUOUS
            rng.Borders(7).Weight = XL_MEDIUM
        except Exception:
            pass

    def write_cell(r, c, value, bold=True, italic=False, underline=False):
        try:
            cell = output_ws.Cells(r, c)
            cell.Value = value
            cell.Font.Bold = bool(bold)
            cell.Font.Italic = bool(italic)
            cell.Font.Underline = 2 if underline else XL_UNDERLINE_NONE
            cell.ShrinkToFit = True
            cell.ShrinkToFit = True
        except Exception:
            pass

    def format_export_score(score):
        score = clean_text(score)

        if not score:
            return ""

        score_upper = score.upper()

        if score_upper in {"E", "WD", "W/D", "WITHDREW", "WITHDRAWN", "CUT", "DQ"}:
            return score_upper

        if re.fullmatch(r"[+-]\d+", score):
            return score

        if re.fullmatch(r"\d+", score):
            if int(score) > 0:
                return f"+{int(score)}"
            return "E"

        return score

    def set_row_height(row_num, height):
        try:
            output_ws.Rows(row_num).RowHeight = height
        except Exception:
            pass

    def write_side(rows, start_group_num, start_row, side):
        if side == "left":
            time_col = 1
            group_col = 1
            name_col = 3
            score_col = 4
            c1, c2 = 1, 5
        else:
            time_col = 6
            group_col = 6
            name_col = 8
            score_col = 9
            c1, c2 = 6, 10

        row_num = start_row

        for offset, row in enumerate(rows):
            # Use the actual parsed group number.
            # Round 2 group numbers must carry over from the Round 1 JSON map,
            # even though tee times/order change.
            group_num = row[1] if clean_text(row[1]) else start_group_num + offset
            tee_time = clean_text(row[3])
            p1 = clean_text(row[4])
            s1 = format_export_score(row[5])
            p2 = clean_text(row[6])
            s2 = format_export_score(row[7])

            # Normal body rows.
            set_row_height(row_num, 15)
            set_row_height(row_num + 1, 15)
            set_row_height(row_num + 2, 15)

            # Top border before each group.
            set_medium_top(row_num, c1, c2)

            # Row 1: Time.
            write_cell(row_num, time_col, tee_time, bold=True, underline=True)

            # Row 2: Player 1 + score.
            write_cell(row_num + 1, name_col, p1, bold=True)
            if s1:
                write_cell(row_num + 1, score_col, s1, bold=True)

            # Row 3: Group number + Player 2 + score.
            write_cell(row_num + 2, group_col, group_num, bold=True, italic=True)
            write_cell(row_num + 2, name_col, p2, bold=True)
            if s2:
                write_cell(row_num + 2, score_col, s2, bold=True)

            # Row 4: blank spacer, short height, bottom border.
            set_row_height(row_num + 3, 6.5)
            set_medium_bottom(row_num + 3, c1, c2)

            row_num += 4

        return row_num

    clear_area()

    start_row = 9

    left_end = write_side(left_rows, 1, start_row, "left")
    right_end = write_side(right_rows, left_count + 1, start_row, "right")

    final_row = max(left_end, right_end)

    # Center divider and header labels.
    set_medium_left(7, min(final_row + 1, 200), 6)

    try:
        output_ws.Range("C7").Value = "1 TEE"
        output_ws.Range("H7").Value = "1 TEE"

        if final_row + 1 <= 200:
            output_ws.Range(f"A{final_row + 1}:J200").ClearContents()
            output_ws.Rows(f"{final_row + 1}:200").Hidden = True
    except Exception:
        pass

    print(
        f"Rebuilt twosome board directly from parsed rows using parsed group numbers "
        f"({group_count} groups)."
    )

    return True



def trim_center_divider_to_content(output_ws):
    """
    Export-only cleanup:
    Trim the center vertical divider so it does not hang too far below the board,
    but keep it through the final spacer/bottom-border row.
    """
    XL_LINE_NONE = -4142
    XL_CONTINUOUS = 1
    XL_MEDIUM = -4138

    def cell_text(r, c):
        try:
            return clean_text(str(output_ws.Cells(r, c).Text))
        except Exception:
            try:
                return clean_text(output_ws.Cells(r, c).Value)
            except Exception:
                return ""

    def row_has_content(r):
        for c in range(1, 11):
            if cell_text(r, c):
                return True
        return False

    last_content_row = 1

    for r in range(1, 201):
        if row_has_content(r):
            last_content_row = r

    # The visual layout has a blank spacer/bottom-border row after the last
    # text row. Keep the center divider through that spacer row.
    keep_through = min(last_content_row + 1, 200)

    try:
        if keep_through >= 7:
            keep_rng = output_ws.Range(f"F7:F{keep_through}")
            keep_rng.Borders(7).LineStyle = XL_CONTINUOUS
            keep_rng.Borders(7).Weight = XL_MEDIUM

        if keep_through + 1 <= 200:
            trim_rng = output_ws.Range(f"F{keep_through + 1}:F200")
            trim_rng.Borders(7).LineStyle = XL_LINE_NONE

        print(f"Trimmed center divider through row {keep_through}.")
    except Exception as exc:
        print(f"WARNING: Could not trim center divider: {exc}")



def force_export_title_with_year(output_ws, parsed_rows=None):
    """
    Export-only cleanup:
    Make title consistent across all layouts:
      YEAR TOURNAMENT NAME
    """
    if not parsed_rows:
        return

    try:
        season = clean_excel_int(parsed_rows[0][12], "")
    except Exception:
        season = ""

    try:
        current_title = clean_text(output_ws.Range("A3").Value)
    except Exception:
        return

    if not current_title:
        return

    if season and not current_title.startswith(str(season)):
        try:
            output_ws.Range("A3").Value = f"{season} {current_title}"
            print(f"Standardized export title: {season} {current_title}")
        except Exception:
            pass


def apply_export_print_settings(output_ws, group_count=None):
    """
    Export-only print setup:
      - portrait
      - centered horizontally
      - fit to 1 page wide x 1 page tall
      - smaller margins, especially for big fields / 36-group signature layouts
    """
    try:
        group_count = int(group_count or 0)
    except Exception:
        group_count = 0

    try:
        ps = output_ws.PageSetup

        # xlPortrait = 1
        ps.Orientation = 1

        # Fit everything to one printed page.
        ps.Zoom = False
        ps.FitToPagesWide = 1
        ps.FitToPagesTall = 1

        # Center horizontally on the page.
        ps.CenterHorizontally = True
        ps.CenterVertically = False

        excel = output_ws.Application

        if group_count >= 32:
            margin = excel.InchesToPoints(0.15)
            top_bottom = excel.InchesToPoints(0.20)
        else:
            margin = excel.InchesToPoints(0.25)
            top_bottom = excel.InchesToPoints(0.30)

        ps.LeftMargin = margin
        ps.RightMargin = margin
        ps.TopMargin = top_bottom
        ps.BottomMargin = top_bottom
        ps.HeaderMargin = excel.InchesToPoints(0.10)
        ps.FooterMargin = excel.InchesToPoints(0.10)

        try:
            used = output_ws.UsedRange
            last_row = min(int(used.Row) + int(used.Rows.Count) + 2, 200)
            ps.PrintArea = f"$A$1:$J${last_row}"
        except Exception:
            ps.PrintArea = "$A$1:$J$200"

        print("Applied export print settings: portrait, fit 1 page, centered horizontally, narrow margins.")

    except Exception as exc:
        print(f"WARNING: Could not apply export print settings: {exc}")


def fix_standard_template_headers_on_export(output_ws, parsed_rows):
    """
    Export-only cleanup for normal Round 1/2 AM/PM template layouts.
    """
    if not parsed_rows:
        return

    try:
        round_num = int(parsed_rows[0][10])
        wave_value = clean_text(parsed_rows[0][11]).upper()
    except Exception:
        return

    if round_num not in [1, 2]:
        return

    if wave_value in {"ALL", "FULL", "BOTH"}:
        return

    tees = sorted({str(row[2]) for row in parsed_rows if clean_text(row[2])})

    try:
        if "10" in tees and "1" in tees:
            output_ws.Range("C7").Value = "10 TEE"
            output_ws.Range("H7").Value = "1 TEE"
        elif "10" in tees:
            output_ws.Range("C7").Value = "10 TEE"
            output_ws.Range("H7").Value = "10 TEE"
        else:
            output_ws.Range("C7").Value = "1 TEE"
            output_ws.Range("H7").Value = "1 TEE"
    except Exception:
        pass


def export_sheet1_only_as_values(workbook, output_path, group_count=None, parsed_rows=None):
    try:
        workbook.Application.CalculateFullRebuild()
        workbook.Application.CalculateUntilAsyncQueriesDone()
    except Exception:
        pass

    """
    Export Sheet1 without using sheet1.Copy().

    Excel sometimes throws:
      "We couldn't copy this sheet."
    especially with macro-enabled workbooks or busy COM state.

    This creates a fresh workbook, copies Sheet1's used range values and formats,
    copies basic page/row/column layout, then saves as a clean .xlsx.
    """
    excel = workbook.Application

    excel_wait_ready(excel, seconds=0.75)

    source_ws = com_retry(
        lambda: workbook.Worksheets("Sheet1"),
        "Get Sheet1"
    )

    used = com_retry(
        lambda: source_ws.UsedRange,
        "Get Sheet1 used range"
    )

    first_row = int(used.Row)
    first_col = int(used.Column)
    row_count = int(used.Rows.Count)
    col_count = int(used.Columns.Count)

    last_row = first_row + row_count - 1
    last_col = first_col + col_count - 1

    output_wb = com_retry(
        lambda: excel.Workbooks.Add(),
        "Create output workbook"
    )

    output_ws = com_retry(
        lambda: output_wb.Worksheets(1),
        "Get output worksheet"
    )

    try:
        output_ws.Name = "Sheet1"
    except Exception:
        pass

    src_rng = source_ws.Range(
        source_ws.Cells(first_row, first_col),
        source_ws.Cells(last_row, last_col)
    )

    dst_rng = output_ws.Range(
        output_ws.Cells(first_row, first_col),
        output_ws.Cells(last_row, last_col)
    )

    # Copy formats first.
    com_retry(
        lambda: src_rng.Copy(),
        "Copy Sheet1 used range"
    )

    # -4122 = xlPasteFormats
    com_retry(
        lambda: dst_rng.PasteSpecial(Paste=-4122),
        "Paste Sheet1 formats"
    )

    try:
        excel.CutCopyMode = False
    except Exception:
        pass

    # Copy values only, preserving the calculated Sheet1 result and removing formulas.
    com_retry(
        lambda: setattr(dst_rng, "Value", src_rng.Value),
        "Paste Sheet1 values"
    )

    # Copy column widths.
    for col in range(first_col, last_col + 1):
        try:
            output_ws.Columns(col).ColumnWidth = source_ws.Columns(col).ColumnWidth
        except Exception:
            pass

    # Copy row heights and hidden state.
    for row in range(first_row, last_row + 1):
        try:
            output_ws.Rows(row).RowHeight = source_ws.Rows(row).RowHeight
            output_ws.Rows(row).Hidden = source_ws.Rows(row).Hidden
        except Exception:
            pass

    # Copy page setup basics.
    try:
        output_ws.PageSetup.Orientation = source_ws.PageSetup.Orientation
        output_ws.PageSetup.Zoom = source_ws.PageSetup.Zoom
        output_ws.PageSetup.FitToPagesWide = source_ws.PageSetup.FitToPagesWide
        output_ws.PageSetup.FitToPagesTall = source_ws.PageSetup.FitToPagesTall
        output_ws.PageSetup.LeftMargin = source_ws.PageSetup.LeftMargin
        output_ws.PageSetup.RightMargin = source_ws.PageSetup.RightMargin
        output_ws.PageSetup.TopMargin = source_ws.PageSetup.TopMargin
        output_ws.PageSetup.BottomMargin = source_ws.PageSetup.BottomMargin
        output_ws.PageSetup.HeaderMargin = source_ws.PageSetup.HeaderMargin
        output_ws.PageSetup.FooterMargin = source_ws.PageSetup.FooterMargin
    except Exception:
        pass

    # Copy print area if available.
    try:
        output_ws.PageSetup.PrintArea = source_ws.PageSetup.PrintArea
    except Exception:
        pass

    # Export-only cleanup.
    # Normal Round 1/2 AM/PM waves need the standard wave rebuild.
    # Round 3 / Final mixed threesomes/twosomes use weekend rebuild.
    # Pure full-field twosome layouts use the twosome rebuild.
    rebuilt_direct = rebuild_standard_round12_wave_board_from_rows(output_ws, parsed_rows or [])

    if not rebuilt_direct:
        rebuilt_direct = rebuild_weekend_standard_board_from_rows(output_ws, parsed_rows or [])

    if not rebuilt_direct:
        rebuilt_direct = rebuild_twosome_board_from_rows(output_ws, parsed_rows or [])

    if not rebuilt_direct:
        compact_signature_twosome_layout_on_export(output_ws)
        compact_blank_twosome_rows_on_export(output_ws)
        remove_blank_left_slot_borders_on_export(output_ws)

        # Rewrite visual group numbers after compaction so all-1-tee/twosome
        # layouts do not inherit leftover formula values.
        rewrite_export_group_numbers_for_all_one_tee(output_ws, group_count)

        # Hide leftover template rows after the final parsed group.
        trim_export_to_group_count(output_ws, group_count)

        # Normal Round 1/2 AM/PM should keep standard 1 Tee / 10 Tee headers.
        fix_standard_template_headers_on_export(output_ws, parsed_rows or [])

    # Delete any extra default sheets.
    while com_retry(lambda: output_wb.Worksheets.Count, "Get output sheet count") > 1:
        com_retry(
            lambda: output_wb.Worksheets(2).Delete(),
            "Delete extra output worksheet"
        )

    # Standardize title across all layouts.
    force_export_title_with_year(output_ws, parsed_rows or [])

    # Final export-only border cleanup.
    trim_center_divider_to_content(output_ws)

    # Apply final print settings to the exported workbook only.
    apply_export_print_settings(output_ws, group_count)

    if os.path.exists(output_path):
        os.remove(output_path)

    com_retry(
        lambda: output_wb.SaveAs(os.path.abspath(output_path), FileFormat=51),
        "Save exported workbook"
    )

    com_retry(
        lambda: output_wb.Close(SaveChanges=False),
        "Close exported workbook after save"
    )

    return output_path


def import_to_workbook(workbook_file):
    ensure_project_folders()

    if workbook_file is None or str(workbook_file).strip() == "":
        workbook_file = SETUP_WORKBOOK

    workbook_file = os.path.abspath(str(workbook_file))

    if not Path(workbook_file).exists():
        raise FileNotFoundError(f"Workbook not found: {workbook_file}")

    excel = get_excel_app()
    excel.Visible = True
    excel.DisplayAlerts = False
    excel.EnableEvents = False

    workbook = get_or_open_workbook(excel, workbook_file)

    season, tour_folder, tournament_slug, round_num, wave, override_url, leaderboard_url = (
        read_settings_from_excel(workbook)
    )

    rows, tournament_name = build_rows_from_pdf(
        season,
        tour_folder,
        tournament_slug,
        round_num,
        wave,
        override_url,
        leaderboard_url
    )

    print(f"Parsed {len(rows)} tee-time groups.")

    write_api_data_excel(workbook, rows)

    # Let Sheet1 formulas pull from API_Data.
    com_retry(lambda: excel.CalculateFullRebuild(), "Excel CalculateFullRebuild")

    # Then set title/subtitle/underlines after formulas calculate.
    update_title_subtitle_excel(workbook, tournament_name, round_num, wave)
    underline_sheet1_times_excel(workbook)

    # Recalculate one more time in case any linked formatting/text changed.
    com_retry(lambda: excel.CalculateFullRebuild(), "Excel CalculateFullRebuild")

    # Hide unused rows after Sheet1 has calculated but before exporting.
    cleanup_sheet1_unused_rows(workbook, group_count=len(rows))

    tournament_folder = os.path.join(
        FINISHED_FOLDER,
        safe_filename(tournament_name)
    )
    os.makedirs(tournament_folder, exist_ok=True)

    output_filename = (
        f"{safe_filename(tournament_name)}_"
        f"{round_label(round_num)}_"
        f"{wave.upper()}.xlsx"
    )
    output_path = os.path.join(tournament_folder, output_filename)

    exported_path = export_sheet1_only_as_values(workbook, output_path, group_count=len(rows), parsed_rows=rows)

    print(f"Exported Sheet1-only values workbook to: {exported_path}")

    # Leave the user with the finished tee sheet open.
    # Keep the setup workbook open so its Run Update button / macro stays functional.
    try:
        excel_wait_ready(excel, seconds=0.5)
        finished_wb = com_retry(
            lambda: excel.Workbooks.Open(os.path.abspath(exported_path)),
            "Open finished tee sheet"
        )
        com_retry(
            lambda: finished_wb.Activate(),
            "Activate finished tee sheet"
        )
        print("Opened finished tee sheet. Setup workbook was left open.")
    except Exception as exc:
        print(f"WARNING: Could not auto-open finished file: {exc}")

    print("Done.")


def parse_espn_aligned_tables(html):
    """
    ESPN golf leaderboards often render as split aligned tables:
      table A: POS / PLAYER
      table B: SCORE / TODAY / THRU / R1 / R2...
    This parser pairs rows by index so the SCORE column is pulled directly.
    """
    BeautifulSoup = ensure_bs4()
    soup = BeautifulSoup(html, "html.parser")

    tables = soup.find_all("table")
    parsed_tables = []

    for table in tables:
        rows = []

        for tr in table.find_all("tr"):
            cells = [
                clean_text(cell.get_text(" "))
                for cell in tr.find_all(["th", "td"])
            ]

            cells = [c for c in cells if c]

            if cells:
                rows.append(cells)

        if rows:
            parsed_tables.append(rows)

    name_tables = []
    score_tables = []

    for rows in parsed_tables:
        flat_all = " ".join(" ".join(r) for r in rows[:3]).upper()

        if "PLAYER" in flat_all:
            name_tables.append(rows)

        if "SCORE" in flat_all or "TODAY" in flat_all or "THRU" in flat_all:
            score_tables.append(rows)

    score_map = {}
    pair_count = min(len(name_tables), len(score_tables))

    for table_idx in range(pair_count):
        name_rows = name_tables[table_idx]
        score_rows = score_tables[table_idx]

        name_data = [
            r for r in name_rows
            if not any(c.upper() == "PLAYER" for c in r)
        ]

        score_header = None
        score_data = []

        for r in score_rows:
            joined = " ".join(r).upper()

            if "SCORE" in joined and score_header is None:
                score_header = [c.upper() for c in r]
                continue

            if any(c.upper() in ["SCORE", "TODAY", "THRU"] for c in r):
                continue

            score_data.append(r)

        score_col = 0

        if score_header and "SCORE" in score_header:
            score_col = score_header.index("SCORE")

        rows_to_pair = min(len(name_data), len(score_data))

        for i in range(rows_to_pair):
            name_cells = name_data[i]
            score_cells = score_data[i]

            player_name = ""

            for cell in name_cells:
                cell_clean = clean_text(cell)

                if re.fullmatch(r"T?\d+", cell_clean, re.I):
                    continue

                key = normalize_player_name(cell_clean)

                if len(key.split()) >= 2:
                    player_name = cell_clean
                    break

            if not player_name:
                continue

            score = ""

            if score_col < len(score_cells):
                possible_score = clean_text(score_cells[score_col]).upper()

                if re.fullmatch(r"[+-]\d+|E", possible_score):
                    score = possible_score

            if not score:
                for cell in score_cells:
                    possible_score = clean_text(cell).upper()

                    if re.fullmatch(r"[+-]\d+|E", possible_score):
                        score = possible_score
                        break

            if player_name and score:
                score_map[normalize_player_name(player_name)] = normalize_score_value(score)

    return score_map


def fetch_leaderboard_scores(leaderboard_url, player_names):
    """
    Returns {normalized_player_name: score} from an ESPN leaderboard page.
    Preferred strategy: pair ESPN's split PLAYER and SCORE tables by row.
    """
    if not leaderboard_url:
        return {}

    print(f"Leaderboard URL: {leaderboard_url}")

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    try:
        response = requests.get(
            leaderboard_url,
            timeout=30,
            headers=headers
        )
        response.raise_for_status()
    except Exception as exc:
        print(f"WARNING: Could not download leaderboard scores: {exc}")
        return {}

    html = response.text

    unique_players = {
        normalize_player_name(p)
        for p in player_names
        if normalize_player_name(p)
    }

    full_score_map = {}

    try:
        full_score_map.update(parse_espn_aligned_tables(html))
        print(f"Parsed {len(full_score_map)} ESPN leaderboard rows from aligned tables.")
    except Exception as exc:
        print(f"WARNING: ESPN aligned-table parser failed: {exc}")

    score_map = {}

    for player in player_names:
        key = normalize_player_name(player)

        if key in full_score_map:
            score_map[key] = normalize_score_value(full_score_map[key])

    if len(score_map) < len(unique_players) and full_score_map:
        for player in player_names:
            key = normalize_player_name(player)

            if not key or key in score_map:
                continue

            best_name = None
            best_score_value = 0.0

            for candidate_name in full_score_map.keys():
                sim = similarity_score(key, candidate_name)

                if sim > best_score_value:
                    best_name = candidate_name
                    best_score_value = sim

            if best_name and best_score_value >= 0.86:
                score_map[key] = normalize_score_value(full_score_map[best_name])
                print(
                    f"Fuzzy matched score: {player} -> "
                    f"{best_name} = {full_score_map[best_name]} "
                    f"({best_score_value:.2f})"
                )

    if len(score_map) < len(unique_players):
        fallback_map = {}
        fallback_map.update(
            extract_scores_from_json_like_text(
                html,
                player_names
            )
        )
        fallback_map.update(
            extract_scores_from_html_tables(
                html,
                player_names
            )
        )
        fallback_map = add_fuzzy_score_matches(
            fallback_map,
            html,
            player_names
        )

        for key, value in fallback_map.items():
            if key not in score_map:
                score_map[key] = normalize_score_value(value)

    matched = len(score_map)
    wanted = len(unique_players)

    print(f"Matched leaderboard scores for {matched} of {wanted} players.")

    if matched < wanted:
        missing = []

        for player in player_names:
            key = normalize_player_name(player)

            if key and key not in score_map:
                missing.append(player)

        if missing:
            debug_missing_path = os.path.join(
                DATA_FOLDER,
                "espn_missing_score_matches.txt"
            )

            try:
                with open(debug_missing_path, "w", encoding="utf-8") as f:
                    f.write("\\n".join(missing))

                print(f"Saved missing-score list to: {debug_missing_path}")
            except Exception:
                pass

    if matched == 0:
        debug_path = os.path.join(
            DATA_FOLDER,
            "espn_leaderboard_debug.html"
        )

        try:
            with open(debug_path, "w", encoding="utf-8") as f:
                f.write(html)

            print(f"Saved ESPN debug HTML to: {debug_path}")
        except Exception:
            pass

    return score_map


if __name__ == "__main__":
    if len(sys.argv) >= 2:
        import_to_workbook(sys.argv[1])
    else:
        import_to_workbook(SETUP_WORKBOOK)
